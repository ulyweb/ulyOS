/* SINGLE SOURCE OF TRUTH for the version. tools/build.mjs reads APP_VERSION from here for the <title>, the output file name and the stale-version audit;
   every version shown on the page (topbar chip, footer, splash, About, status bar, exports, ledger) is filled from these two values at boot.
   On EVERY shipped change: bump APP_VERSION and prepend a CHANGELOG row. Notes must not contain a single quote or a double quote. */
var APP_VERSION = '2.4';
var CHANGELOG = [
  { v: '2.4', d: '2026-10-09', n: [
    'Key Generator: the text field now shows its live length in characters next to the quality tag (also for a pattern used as the base).'] },
  { v: '2.3', d: '2026-10-09', n: [
    'Fortify Password: the live line under the password box now shows the length in characters next to the estimated strength.'] },
  { v: '2.2', d: '2026-10-09', n: [
    'Key Generator: clearer text mixing. The dropdown now asks How should your text be mixed in? with plain-language options, a live example of the result shape and a hint in the base field.',
    'New optional checkbox: fold my text into the entropy pool (off by default). Only a domain-separated SHA-256 hash enters the pool; it adds 0 trusted bits and cannot weaken the output. Purge reseeds the pool.',
    'Entropy Sources shows a YOUR TEXT card; command palette entries for every text-mixing mode; new core tests.'] },
  { v: '2.1', d: '2026-10-09', n: [
    'Settings: choose the opening page (Fortify a password, Key generator, Entropy sources, Guided tour, or Home banner only as in v2.0). Default is Fortify a password.',
    'The status HUD now shows on load for every opening page except Home banner only.',
    'Single-source version and this changelog; the topbar chip, footer, tab title, About and exports all read from it.',
    'The audit ledger now records every session open and every version change.'] },
  { v: '2.0', d: '2026-10-08', n: [
    'Rebuilt in the Dashboard-Telemetry standard: welcome splash, boot bar, glass panels, command palette and a hash-chained audit ledger.',
    'Mixed-entropy password fortifier and key generator with trusted-bit accounting; own QR encoder, pattern lock input, EFF passphrase wordlist.',
    'No CDN scripts; the only outbound request is the Contact Admin message you send.'] }
];

/* ===================== SYSTEM VAULT CORE (no DOM) =====================
   Entropy rules enforced here:
   - every random byte = crypto.getRandomValues  XOR  H(jitter-pool || counter)   (XOR can never be weaker than the CSPRNG)
   - one unbiased sampler (rejection sampling) for every choice
   - Math.random is never used for anything in this module
   - trusted bits are summed from the REAL choice space of each CSPRNG decision; retained user material counts 0 */

/* ---------- synchronous SHA-256 (so mixing + ledger work on file:// where crypto.subtle may be absent) ---------- */
var SHA_K = (function () {
  var out = new Uint32Array(64), n = 0;
  for (var c = 2; n < 64; c++) {
    var p = true;
    for (var d = 2; d * d <= c; d++) if (c % d === 0) { p = false; break; }
    if (p) { var r = Math.cbrt(c); out[n++] = Math.floor((r - Math.floor(r)) * 4294967296) >>> 0; }
  }
  return out;
})();
var SHA_H0 = (function () {
  var out = new Uint32Array(8), n = 0;
  for (var c = 2; n < 8; c++) {
    var p = true;
    for (var d = 2; d * d <= c; d++) if (c % d === 0) { p = false; break; }
    if (p) { var r = Math.sqrt(c); out[n++] = Math.floor((r - Math.floor(r)) * 4294967296) >>> 0; }
  }
  return out;
})();
function sha256(bytes) {
  if (typeof bytes === 'string') bytes = new TextEncoder().encode(bytes);
  var l = bytes.length, total = (((l + 9 + 63) >> 6) << 6), buf = new Uint8Array(total);
  buf.set(bytes); buf[l] = 0x80;
  var dv = new DataView(buf.buffer);
  dv.setUint32(total - 8, Math.floor(l / 536870912), false);
  dv.setUint32(total - 4, (l << 3) >>> 0, false);
  var H = new Uint32Array(SHA_H0), w = new Uint32Array(64);
  for (var off = 0; off < total; off += 64) {
    for (var i = 0; i < 16; i++) w[i] = dv.getUint32(off + i * 4, false);
    for (i = 16; i < 64; i++) {
      var a = w[i - 15], b = w[i - 2];
      var s0 = ((a >>> 7) | (a << 25)) ^ ((a >>> 18) | (a << 14)) ^ (a >>> 3);
      var s1 = ((b >>> 17) | (b << 15)) ^ ((b >>> 19) | (b << 13)) ^ (b >>> 10);
      w[i] = (w[i - 16] + s0 + w[i - 7] + s1) >>> 0;
    }
    var A = H[0], B = H[1], C = H[2], D = H[3], E = H[4], F = H[5], G = H[6], Hh = H[7];
    for (i = 0; i < 64; i++) {
      var S1 = ((E >>> 6) | (E << 26)) ^ ((E >>> 11) | (E << 21)) ^ ((E >>> 25) | (E << 7));
      var ch = (E & F) ^ (~E & G);
      var t1 = (Hh + S1 + ch + SHA_K[i] + w[i]) >>> 0;
      var S0 = ((A >>> 2) | (A << 30)) ^ ((A >>> 13) | (A << 19)) ^ ((A >>> 22) | (A << 10));
      var mj = (A & B) ^ (A & C) ^ (B & C);
      var t2 = (S0 + mj) >>> 0;
      Hh = G; G = F; F = E; E = (D + t1) >>> 0; D = C; C = B; B = A; A = (t1 + t2) >>> 0;
    }
    H[0] += A; H[1] += B; H[2] += C; H[3] += D; H[4] += E; H[5] += F; H[6] += G; H[7] += Hh;
  }
  var out = new Uint8Array(32), ov = new DataView(out.buffer);
  for (i = 0; i < 8; i++) ov.setUint32(i * 4, H[i], false);
  return out;
}
function toHex(u8) { var s = ''; for (var i = 0; i < u8.length; i++) s += (u8[i] < 16 ? '0' : '') + u8[i].toString(16); return s; }
function sha256hex(x) { return toHex(sha256(x)); }

/* ---------- mixed entropy pool ---------- */
function EntropyMixer() {
  var g = (typeof globalThis !== 'undefined' ? globalThis : window);
  this.cr = g.crypto;
  this.ok = !!(this.cr && this.cr.getRandomValues);
  this.digest = new Uint8Array(32);            /* running pool digest of jitter sources */
  this.ctr = 0;
  this.buf = new Uint8Array(0); this.bufPos = 0;
  this.pend = [];                              /* un-folded jitter samples */
  this.stats = { csprng: 0, pointer: 0, key: 0, timing: 0, subtle: 0, user: 0, folds: 0, draws: 0 };
  this.enabled = { pointer: true, key: true, timing: true };
  this._seedTiming();
}
EntropyMixer.prototype._now = function () {
  return (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
};
EntropyMixer.prototype._seedTiming = function () {
  /* a handful of high-resolution timing deltas from a tiny busy loop; defence-in-depth only */
  if (!this.enabled.timing) return;
  var s = [], t0 = this._now();
  for (var i = 0; i < 16; i++) { var x = 0; for (var j = 0; j < 200 + i * 13; j++) x ^= j * 31; var t = this._now(); s.push(Math.floor((t - t0) * 1e6) & 0xffff); t0 = t; }
  this.jitter('timing', s);
};
EntropyMixer.prototype.jitter = function (src, vals) {
  if (src !== 'timing' && this.enabled[src] === false) return;
  for (var i = 0; i < vals.length; i++) this.pend.push(vals[i] & 0xffff);
  this.pend.push(Math.floor(this._now() * 1000) & 0xffff);
  this.stats[src] = (this.stats[src] || 0) + vals.length;
  if (this.pend.length >= 32) this._fold();
};
EntropyMixer.prototype._fold = function () {
  var p = this.pend, inb = new Uint8Array(32 + p.length * 2);
  inb.set(this.digest);
  for (var i = 0; i < p.length; i++) { inb[32 + i * 2] = p[i] >> 8; inb[33 + i * 2] = p[i] & 255; }
  this.digest = sha256(inb); this.pend = []; this.stats.folds++;
};
EntropyMixer.prototype.addBytes = function (src, u8) {   /* e.g. crypto.subtle digest results */
  var inb = new Uint8Array(32 + u8.length); inb.set(this.digest); inb.set(u8, 32);
  this.digest = sha256(inb); this.stats[src] = (this.stats[src] || 0) + u8.length; this.stats.folds++;
};
/* Fold the user's own text into the pool as an EXTRA source. Only a domain-separated SHA-256 of it enters the pool (the text is not kept).
   It adds 0 trusted bits (an attacker is assumed to know or guess it) and cannot weaken output: every byte is still CSPRNG XOR SHA-256(pool || counter).
   The pre-drawn buffer is dropped so the very next draw already depends on the fold. */
EntropyMixer.prototype.addText = function (src, text) {
  this.addBytes(src, sha256(new TextEncoder().encode('SystemVault|userfold|v1|' + String(text))));
  this.buf = new Uint8Array(0); this.bufPos = 0;
};
/* Replace the pool digest with fresh CSPRNG output so no password-derived state survives a purge. */
EntropyMixer.prototype.reseed = function () {
  if (!this.ok) return; var f = new Uint8Array(32); this.cr.getRandomValues(f);
  this.digest = sha256(f); this.pend = []; this.buf = new Uint8Array(0); this.bufPos = 0; this.stats.folds++;
};
EntropyMixer.prototype.fill = function (n) {
  if (!this.ok) throw new Error('No CSPRNG available (crypto.getRandomValues). Refusing to generate.');
  var out = new Uint8Array(n);
  for (var o = 0; o < n; o += 65536) this.cr.getRandomValues(out.subarray(o, Math.min(n, o + 65536)));
  this.stats.csprng += n;
  /* XOR with an independent counter-mode hash stream of the jitter pool */
  var i = 0;
  while (i < n) {
    var blk = new Uint8Array(32 + 8 + 4);
    blk.set(this.digest); new DataView(blk.buffer).setUint32(32, Math.floor(this.ctr / 4294967296), false);
    new DataView(blk.buffer).setUint32(36, this.ctr >>> 0, false);
    new DataView(blk.buffer).setUint32(40, Math.floor(this._now() * 1000) >>> 0, false);
    this.ctr++;
    var m = sha256(blk);
    for (var k = 0; k < 32 && i < n; k++, i++) out[i] ^= m[k];
  }
  this.stats.draws += n;
  return out;
};
EntropyMixer.prototype._u32 = function () {
  if (this.bufPos + 4 > this.buf.length) { this.buf = this.fill(512); this.bufPos = 0; }
  var b = this.buf, p = this.bufPos; this.bufPos += 4;
  return ((b[p] << 24) | (b[p + 1] << 16) | (b[p + 2] << 8) | b[p + 3]) >>> 0;
};
/* unbiased integer in [0,n): reject draws >= floor(2^32/n)*n */
EntropyMixer.prototype.int = function (n) {
  if (n <= 1) return 0;
  var lim = 4294967296 - (4294967296 % n), x;
  do { x = this._u32(); } while (x >= lim);
  return x % n;
};
EntropyMixer.prototype.pick = function (arr) { return arr[this.int(arr.length)]; };
EntropyMixer.prototype.shuffle = function (arr) {      /* Fisher-Yates, in place, unbiased */
  for (var i = arr.length - 1; i > 0; i--) { var j = this.int(i + 1), t = arr[i]; arr[i] = arr[j]; arr[j] = t; }
  return arr;
};
EntropyMixer.prototype.wipe = function () { this.buf = new Uint8Array(0); this.bufPos = 0; };

/* ---------- character pools / configurable character sets ---------- */
var GROUP_DEFS = [
  { id: 'lower', cls: 'lower', on: 1, label: 'Lowercase', chars: 'abcdefghijklmnopqrstuvwxyz' },
  { id: 'upper', cls: 'upper', on: 1, label: 'Uppercase', chars: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' },
  { id: 'digit', cls: 'digit', on: 1, label: 'Digits', chars: '0123456789' },
  { id: 'braces', cls: 'sym', on: 1, label: 'Braces', chars: '()[]{}' },
  { id: 'punct', cls: 'sym', on: 1, label: 'Punctuation', chars: '.,:;' },
  { id: 'dashes', cls: 'sym', on: 1, label: 'Dashes & slashes', chars: '-_/|' },
  { id: 'math', cls: 'sym', on: 1, label: 'Math & marks', chars: '<>*+!?=' },
  { id: 'logo', cls: 'sym', on: 1, label: 'Logograms', chars: '#$%&@^~' },
  { id: 'quotes', cls: 'sym', on: 0, label: 'Quotes', chars: '"\'`' },
  { id: 'ext', cls: 'sym', on: 0, label: 'Extended (Latin-1)', chars: (function () { var s = ''; for (var i = 0xA1; i <= 0xFF; i++) if (i !== 0xAD) s += String.fromCharCode(i); return s; })() }
];
var AMBIG = 'Il1O0o|';
/* cfg: { groups:{id:bool}, custom:'chars', exclude:'chars', noAmbig:bool }  ->  { lower, upper, digit, sym }
   Pools are DE-DUPLICATED (a duplicated symbol would be drawn more often = biased) and exclusions apply everywhere. */
function buildCharset(cfg) {
  cfg = cfg || {}; var on = cfg.groups || {}, ex = {}, seen = {}, out = { lower: '', upper: '', digit: '', sym: '' };
  Array.from(cfg.exclude || '').forEach(function (c) { ex[c] = 1; });
  if (cfg.noAmbig) AMBIG.split('').forEach(function (c) { ex[c] = 1; });
  function take(c, cls) { if (ex[c] || seen[c]) return; seen[c] = 1; out[cls] += c; }
  GROUP_DEFS.forEach(function (g) { var enabled = on[g.id] === undefined ? !!g.on : !!on[g.id]; if (enabled) g.chars.split('').forEach(function (c) { take(c, g.cls); }); });
  Array.from(cfg.custom || '').forEach(function (c) { if (c.length === 1 && c > ' ' && c !== '\u007f') take(c, classOf(c)); });   /* single BMP code units only; no spaces/controls */
  return out;
}
var POOLS = buildCharset({});
function poolsFor(arg) { return buildCharset(arg && typeof arg === 'object' ? arg : { noAmbig: !!arg }); }
function poolString(p) { return p.lower + p.upper + p.digit + p.sym; }
function classOf(c) {
  if (c >= 'a' && c <= 'z') return 'lower'; if (c >= 'A' && c <= 'Z') return 'upper';
  if (c >= '0' && c <= '9') return 'digit'; return 'sym';
}
var LG2 = Math.log2;
/* log2 of the number of length-L strings over `pools` that contain at least one char of EVERY class (exact inclusion-exclusion) */
function log2ClassCovered(L, pools) {
  var sizes = Object.keys(pools).map(function (k) { return pools[k].length; }), tot = 0, N = sizes.length;
  for (var mask = 0; mask < (1 << N); mask++) {
    var rem = 0, bits = 0;
    for (var i = 0; i < N; i++) if (mask & (1 << i)) bits++; else rem += sizes[i];
    tot += (bits % 2 ? -1 : 1) * Math.pow(rem, L);
  }
  return tot > 0 ? LG2(tot) : 0;
}

/* ---------- dictionaries (injected by build: EFF_WORDS[], COMMON_PW[]) ---------- */
var DICT = { words: [], common: [], commonRank: null, wordSet: null };
function initDicts(words, common) {
  DICT.words = words; DICT.common = common;
  DICT.commonRank = Object.create(null);
  for (var i = 0; i < common.length; i++) if (!(common[i] in DICT.commonRank)) DICT.commonRank[common[i]] = i + 1;
  DICT.wordSet = Object.create(null);
  words.forEach(function (w) { DICT.wordSet[w] = 1; });
  common.forEach(function (w) { if (/^[a-z]{3,}$/.test(w)) DICT.wordSet[w] = 1; });
}

/* ---------- weak-password analysis (offline, in memory) ---------- */
var LEET = { '@': 'a', '4': 'a', '3': 'e', '1': 'i', '!': 'i', '0': 'o', '$': 's', '5': 's', '7': 't', '8': 'b', '9': 'g' };
var KB_ROWS = ['qwertyuiop', 'asdfghjkl', 'zxcvbnm', '1234567890', '1qaz2wsx3edc', 'qazwsxedc'];
function deleet(s) { return s.toLowerCase().split('').map(function (c) { return LEET[c] || c; }).join(''); }
function hasWalk(s) {
  s = s.toLowerCase();
  for (var r = 0; r < KB_ROWS.length; r++) {
    var row = KB_ROWS[r], rev = row.split('').reverse().join('');
    for (var i = 0; i + 4 <= row.length; i++) {
      var sub = row.substr(i, 4), sr = rev.substr(i, 4);
      if (s.indexOf(sub) >= 0) return sub; if (s.indexOf(sr) >= 0) return sr;
    }
  }
  return null;
}
function isSeq(s) {   /* ascending/descending run of letters or digits, len>=3 */
  if (s.length < 3) return false;
  var d = s.charCodeAt(1) - s.charCodeAt(0); if (Math.abs(d) !== 1) return false;
  for (var i = 1; i < s.length; i++) if (s.charCodeAt(i) - s.charCodeAt(i - 1) !== d) return false;
  return true;
}
function wordSplit(low) {   /* min-bits split of a lowercase letter run into dictionary words; returns {bits,words} or null */
  var n = low.length, best = new Array(n + 1).fill(null); best[0] = { bits: 0, words: [] };
  for (var i = 1; i <= n; i++) for (var j = Math.max(0, i - 24); j < i; j++) {
    if (!best[j] || i - j < 3) continue;
    var w = low.slice(j, i); if (!DICT.wordSet[w]) continue;
    var rk = DICT.commonRank[w], b = rk ? LG2(rk + 1) : LG2(DICT.words.length);
    var cand = { bits: best[j].bits + b, words: best[j].words.concat(w) };
    if (!best[i] || cand.bits < best[i].bits) best[i] = cand;
  }
  return best[n];
}
function rankBucket(r) { return r <= 100 ? 'top 100' : r <= 1000 ? 'top 1,000' : 'top 10,000'; }
function analyze(pw) {
  var res = { len: pw.length, classes: {}, tokens: [], weak: [], estBits: 0, naiveBits: 0, rank: 0, label: 'EMPTY', pct: 0 };
  if (!pw) return res;
  var poolSize = 0, cls = {};
  pw.split('').forEach(function (c) { cls[classOf(c)] = 1; });
  res.classes = cls;
  Object.keys(cls).forEach(function (k) { poolSize += POOLS[k].length; });
  res.naiveBits = pw.length * LG2(Math.max(2, poolSize));
  var low = pw.toLowerCase(), est = 0, weak = res.weak;
  function W(id, sev, msg) { weak.push({ id: id, sev: sev, msg: msg }); }
  /* 1. whole-password common-list check, with trivial variations */
  var rank = DICT.commonRank[low] || 0, varBits = 0;
  if (!rank) {
    var base = deleet(pw).replace(/[^a-z]+$/g, '').replace(/^[^a-z]+/g, '');
    var r2 = DICT.commonRank[base] || DICT.commonRank[base.replace(/[^a-z]/g, '')] || 0;
    if (r2) { rank = r2; varBits = 2 + Math.max(0, pw.length - base.length) * 3.3 + (pw !== low ? 1 : 0); }
  } else varBits = (pw !== low ? 1.5 : 0);
  if (rank) { res.rank = rank; W('common', 'crit', 'Matches the embedded top-' + DICT.common.length + ' common-password list (' + rankBucket(rank) + ') or a trivial variation of it.'); }
  /* 2. token model */
  var toks = pw.match(/[A-Za-z]+|\d+|[^A-Za-z\d]+/g) || [];
  var hasLeetSub = false;
  toks.forEach(function (t) {
    var type = /^[A-Za-z]/.test(t) ? 'word' : /^\d/.test(t) ? 'digits' : 'symbols', bits;
    if (type === 'word') {
      var lw = t.toLowerCase(), sp = t.length >= 3 ? wordSplit(lw) : null;
      var caseBits = t === lw ? 0 : (t === t.toUpperCase() ? 1 : (t[0] === t[0].toUpperCase() && t.slice(1) === lw.slice(1) ? 1 : Math.min(t.length, 6)));
      if (sp) { bits = sp.bits + caseBits; type = sp.words.length > 1 ? 'words' : 'word'; if (sp.words.length > 1) W('multiword', 'warn', 'Built from ' + sp.words.length + ' dictionary words.'); else W('dictword', 'warn', 'Contains a dictionary word.'); }
      else bits = t.length * 4.7;
    } else if (type === 'digits') {
      if (/^(19|20)\d\d$/.test(t)) { bits = 7; W('year', 'warn', 'Contains a year.'); }
      else if (isSeq(t)) { bits = 4; W('seq', 'crit', 'Contains a digit sequence.'); }
      else if (/^(\d)\1+$/.test(t)) { bits = 4; W('repeat', 'crit', 'Contains a repeated digit run.'); }
      else bits = t.length * 3.32;
    } else {
      bits = t.length === 1 ? 3 : t.length * 4.5;
    }
    res.tokens.push({ type: type, text: t, bits: Math.round(bits * 10) / 10 });
    est += bits;
  });
  if (/[@$!0-9]/.test(pw) && /[A-Za-z]/.test(pw) && deleet(pw) !== low && DICT.wordSet && wordSplit(deleet(pw).replace(/[^a-z]/g, '')) ) hasLeetSub = true;
  if (hasLeetSub && /[@$]/.test(pw)) W('leet', 'warn', 'Predictable character substitutions (@, $, 0, 3 ...). Crackers try these first.');
  var walk = hasWalk(pw); if (walk) W('walk', 'crit', 'Contains a keyboard walk (4+ adjacent keys).');
  if (/(.)\1{2,}/.test(pw)) W('repeat', 'warn', 'Repeated characters.');
  if (/^[A-Za-z][a-z]+\d{1,4}[!@#$.?]?$/.test(pw)) W('pattern', 'warn', 'Classic "Word + digits + symbol" shape: the first pattern attackers try.');
  if (/(spring|summer|autumn|fall|winter)(19|20)\d\d/i.test(pw)) W('season', 'crit', 'Season + year pattern.');
  if (pw.length < 12) W('short', pw.length < 8 ? 'crit' : 'warn', 'Only ' + pw.length + ' characters. Aim for 14+.');
  if (Object.keys(cls).length < 3) W('classes', 'warn', 'Uses only ' + Object.keys(cls).length + ' character class(es).');
  est += 0; /* token model already sums */
  if (rank) est = Math.min(est, LG2(rank + 1) + varBits);
  est = Math.min(est, res.naiveBits);
  res.estBits = Math.max(1, Math.round(est * 10) / 10);
  res.label = res.estBits < 28 ? 'CRITICAL' : res.estBits < 40 ? 'WEAK' : res.estBits < 60 ? 'FAIR' : res.estBits < 80 ? 'GOOD' : 'STRONG';
  res.pct = Math.max(2, Math.min(100, Math.round(res.estBits / 1.28)));
  return res;
}

/* ---------- generation ---------- */
function binomLog2(n, k) { var s = 0; for (var i = 0; i < k; i++) s += LG2((n - i) / (i + 1)); return s; }
function genFromPools(R, L, pools) {   /* L chars, rejection-sampled until every NON-EMPTY class is present; exact bits */
  var cl = Object.keys(pools).filter(function (k) { return pools[k].length; }), sub = {};
  cl.forEach(function (k) { sub[k] = pools[k]; });
  var all = cl.map(function (k) { return pools[k]; }).join('').split('');
  if (!all.length) throw new Error('The character set is empty. Enable at least one group.');
  L = Math.max(L, cl.length); var out, ok, tries = 0;
  do {
    out = []; for (var i = 0; i < L; i++) out.push(R.pick(all));
    var s = out.join('');
    ok = cl.every(function (k) { return pools[k].split('').some(function (c) { return s.indexOf(c) >= 0; }); });
    if (++tries > 1000) throw new Error('class-coverage rejection loop exceeded');
  } while (!ok);
  return { text: out.join(''), bits: log2ClassCovered(L, sub), pool: all.length, classes: cl.length };
}
function genPassword(R, L, opt) {
  opt = opt || {}; var pools = poolsFor(opt.charset || opt.noAmbig);
  var r = genFromPools(R, Math.max(4, L), pools);
  return { text: r.text, trustedBits: r.bits, pool: r.pool, steps: [{ label: r.text.length + ' chars over a ' + r.pool + '-symbol pool, ' + r.classes + ' class(es) required', bits: r.bits }] };
}
function genPassphrase(R, n, sep, opt) {
  opt = opt || {}; var W = [], bits = 0, steps = [], pools = poolsFor(opt.charset || opt.noAmbig);
  for (var i = 0; i < n; i++) W.push(R.pick(DICT.words));
  bits += n * LG2(DICT.words.length); steps.push({ label: n + ' words from ' + DICT.words.length + '-word list', bits: n * LG2(DICT.words.length) });
  if (opt.cap) W = W.map(function (w) { return w[0].toUpperCase() + w.slice(1); });
  var out = W.join(sep);
  if (opt.num && pools.digit.length) { var d = R.pick(pools.digit.split('')); out += sep === ' ' ? ' ' + d : d; bits += LG2(pools.digit.length); steps.push({ label: 'random digit suffix', bits: LG2(pools.digit.length) }); }
  if (opt.sym && pools.sym.length) { var sy = R.pick(pools.sym.split('')); out += sy; bits += LG2(pools.sym.length); steps.push({ label: 'random symbol suffix', bits: LG2(pools.sym.length) }); }
  return { text: out, trustedBits: bits, steps: steps };
}
function bitsToTime(bits, rate) {
  var secs = Math.pow(2, bits - 1) / rate;     /* average = half the keyspace */
  if (secs < 1) return '< 1 second';
  var units = [['second', 60], ['minute', 60], ['hour', 24], ['day', 365.25], ['year', 1e3], ['thousand years', 1e3], ['million years', 1e3], ['billion years', 1e3]];
  var v = secs, name = 'second';
  for (var i = 0; i < units.length; i++) { name = units[i][0]; if (v < units[i][1] || i === units.length - 1) break; v /= units[i][1]; }
  if (name === 'billion years' && v > 1e6) return '> 10^' + Math.floor(Math.log10(v * 1e9)) + ' years';
  return (v < 10 ? v.toFixed(1) : Math.round(v).toLocaleString('en-US')) + ' ' + name + (Math.round(v) === 1 && name.slice(-1) !== 's' ? '' : (name.slice(-1) === 's' ? '' : 's'));
}
var LEETMAP = { a: ['@', '4'], e: ['3'], i: ['1', '!'], o: ['0'], s: ['$', '5'], t: ['7'], l: ['1'], b: ['8'], g: ['9'] };

/* Fortify: turn a weak password into a stronger one.  mode: echo | shape | fresh.  floor = min TRUSTED bits.
   opt.charset (see buildCharset) limits every character the vault itself writes; characters kept from the input that the set does not allow are re-drawn. */
function fortify(R, pw, mode, floor, opt) {
  opt = opt || {}; floor = floor || 80;
  var pools = poolsFor(opt.charset || opt.noAmbig), ALL = poolString(pools).split(''), steps = [], bits = 0;
  if (!ALL.length) throw new Error('The character set is empty. Enable at least one group.');
  var ALLSTR = ALL.join(''), allowed = {}; ALL.forEach(function (c) { allowed[c] = 1; });
  function poolOf(k) { return pools[k].length ? pools[k] : ALLSTR; }
  function add(label, b) { bits += b; steps.push({ label: label, bits: Math.round(b * 10) / 10 }); }
  var an = analyze(pw), chars, retained = 0;
  if (mode === 'fresh' || !pw) {
    var L = Math.max(14, Math.ceil(floor / LG2(ALL.length)) + 1), g = genFromPools(R, L, pools);
    return finish(g.text.split(''), g.bits, [{ label: g.text.length + ' fresh chars over a ' + g.pool + '-symbol pool, ' + g.classes + ' class(es) required (nothing carried over)', bits: Math.round(g.bits * 10) / 10 }], 0);
  }
  if (mode === 'shape') {
    chars = pw.split('').map(function (c) { return R.pick(poolOf(classOf(c)).split('')); });
    var sb = pw.split('').reduce(function (a, c) { return a + LG2(poolOf(classOf(c)).length); }, 0);
    add('shape kept (length ' + pw.length + ', class layout); every character re-drawn', sb);
  } else {   /* echo */
    chars = pw.split('');
    retained = an.estBits;
    /* 0) anything the character set does not allow is re-drawn from the allowed pool */
    var bad = 0, bb = 0;
    chars = chars.map(function (c) { if (allowed[c]) return c; bad++; bb += LG2(ALL.length); return R.pick(ALL); });
    if (bad) add(bad + ' char(s) outside the allowed character set re-drawn', bb);
    /* a) re-draw digit and symbol runs: they are the weakest, most guessable part */
    var redraw = 0, rb = 0;
    chars = chars.map(function (c) { var k = classOf(c); if (k === 'digit' || k === 'sym') { redraw++; rb += LG2(poolOf(k).length); return R.pick(poolOf(k).split('')); } return c; });
    if (redraw) add(redraw + ' digit/symbol chars re-drawn', rb);
    /* b) hardening: case-flip or leet-substitute a random third of the letters (only to allowed characters) */
    function optsFor(c) { var lo = c.toLowerCase(), f = c === lo ? c.toUpperCase() : lo; return [f].concat(LEETMAP[lo] || []).filter(function (x) { return allowed[x]; }); }
    var idx = []; chars.forEach(function (c, i) { if ((classOf(c) === 'lower' || classOf(c) === 'upper') && optsFor(c).length) idx.push(i); });
    var kk = Math.min(idx.length, Math.max(1, Math.floor(idx.length / 3)));
    if (idx.length) {
      var pickedIdx = [], pool = idx.slice(), ob = 0;
      for (var i = 0; i < kk; i++) { var j = R.int(pool.length); pickedIdx.push(pool.splice(j, 1)[0]); }
      add('choose ' + kk + ' of ' + idx.length + ' letters to alter', binomLog2(idx.length, kk));
      pickedIdx.forEach(function (p) { var opts = optsFor(chars[p]); chars[p] = R.pick(opts); ob += LG2(opts.length); });
      add('pick case-flip / look-alike for each altered letter', ob);
    }
    /* c) insert two random chars at random positions */
    for (var q = 0; q < 2; q++) {
      var pos = R.int(chars.length + 1), ch = R.pick(ALL);
      chars.splice(pos, 0, ch); add('insert 1 random char at 1 of ' + (chars.length) + ' positions', LG2(chars.length) + LG2(ALL.length));
    }
  }
  return finish(chars, bits, steps, retained);

  function finish(chs, b0, st, ret) {
    bits = b0; steps = st;
    /* ensure every NON-EMPTY class is present (counted conservatively: position + char) */
    ['lower', 'upper', 'digit', 'sym'].forEach(function (k) {
      if (!pools[k].length) return;
      if (!chs.some(function (c) { return classOf(c) === k; })) {
        var pos = R.int(chs.length + 1), ch = R.pick(pools[k].split(''));
        chs.splice(pos, 0, ch); add('add missing ' + k + ' class char', LG2(chs.length) + LG2(pools[k].length));
      }
    });
    /* random tail until the trusted-bit floor is met */
    var tail = 0;
    while (bits < floor && chs.length < 128) { chs.push(R.pick(ALL)); bits += LG2(ALL.length); tail++; }
    if (tail) steps.push({ label: tail + '-char random tail to reach the ' + floor + '-bit floor', bits: Math.round(tail * LG2(ALL.length) * 10) / 10 });
    return { text: chs.join(''), trustedBits: Math.round(bits * 10) / 10, retainedBits: Math.round(ret * 10) / 10, steps: steps, analysis: an, floor: floor, mode: mode, pool: ALL.length };
  }
}

/* similarity of output to input: share of the input's letters that survive in order (case/leet-insensitive) */
function similarity(a, b) {
  var x = deleet(a).replace(/[^a-z]/g, ''), y = deleet(b).replace(/[^a-z]/g, ''); if (!x) return 0;
  var m = x.length, n = y.length, prev = new Array(n + 1).fill(0), cur;
  for (var i = 1; i <= m; i++) { cur = [0]; for (var j = 1; j <= n; j++) cur[j] = x[i - 1] === y[j - 1] ? prev[j - 1] + 1 : Math.max(prev[j], cur[j - 1]); prev = cur; }
  return prev[n] / m;
}

/* byte-level randomness sanity check (NOT a certification): monobit + runs on n bytes */
function randomnessSanity(R, n) {
  var b = R.fill(n || 4096), ones = 0, total = b.length * 8, runs = 1, last = -1;
  for (var i = 0; i < b.length; i++) for (var k = 7; k >= 0; k--) { var bit = (b[i] >> k) & 1; ones += bit; if (last >= 0 && bit !== last) runs++; last = bit; }
  var pi = ones / total, zMono = (ones - total / 2) / Math.sqrt(total / 4);
  var expRuns = 2 * total * pi * (1 - pi) + 1, zRuns = (runs - expRuns) / (2 * Math.sqrt(2 * total) * pi * (1 - pi));
  return { bits: total, ones: ones, zMono: zMono, zRuns: zRuns, pass: Math.abs(zMono) < 4 && Math.abs(zRuns) < 4 };
}

/* Chi-square-free helper used by tests */
if (typeof module !== 'undefined') module.exports = { buildCharset, GROUP_DEFS, poolString, rankBucket, sha256, sha256hex, EntropyMixer, initDicts, analyze, fortify, genPassword, genPassphrase, similarity, randomnessSanity, bitsToTime, POOLS, poolsFor, log2ClassCovered, DICT, classOf, wordSplit, toHex };

/* generated by tools/mkdata.mjs : EFF large wordlist (7776) + SecLists 10k-most-common (10001) */
var EFF_WORDS = "abacus abdomen abdominal abide abiding ability ablaze able abnormal abrasion abrasive abreast abridge abroad abruptly absence absentee absently absinthe absolute absolve abstain abstract absurd accent acclaim acclimate accompany account accuracy accurate accustom acetone achiness aching acid acorn acquaint acquire acre acrobat acronym acting action activate activator active activism activist activity actress acts acutely acuteness aeration aerobics aerosol aerospace afar affair affected affecting affection affidavit affiliate affirm affix afflicted affluent afford affront aflame afloat aflutter afoot afraid afterglow afterlife aftermath aftermost afternoon aged ageless agency agenda agent aggregate aghast agile agility aging agnostic agonize agonizing agony agreeable agreeably agreed agreeing agreement aground ahead ahoy aide aids aim ajar alabaster alarm albatross album alfalfa algebra algorithm alias alibi alienable alienate aliens alike alive alkaline alkalize almanac almighty almost aloe aloft aloha alone alongside aloof alphabet alright although altitude alto aluminum alumni always amaretto amaze amazingly amber ambiance ambiguity ambiguous ambition ambitious ambulance ambush amendable amendment amends amenity amiable amicably amid amigo amino amiss ammonia ammonium amnesty amniotic among amount amperage ample amplifier amplify amply amuck amulet amusable amused amusement amuser amusing anaconda anaerobic anagram anatomist anatomy anchor anchovy ancient android anemia anemic aneurism anew angelfish angelic anger angled angler angles angling angrily angriness anguished angular animal animate animating animation animator anime animosity ankle annex annotate announcer annoying annually annuity anointer another answering antacid antarctic anteater antelope antennae anthem anthill anthology antibody antics antidote antihero antiquely antiques antiquity antirust antitoxic antitrust antiviral antivirus antler antonym antsy anvil anybody anyhow anymore anyone anyplace anything anytime anyway anywhere aorta apache apostle appealing appear appease appeasing appendage appendix appetite appetizer applaud applause apple appliance applicant applied apply appointee appraisal appraiser apprehend approach approval approve apricot april apron aptitude aptly aqua aqueduct arbitrary arbitrate ardently area arena arguable arguably argue arise armadillo armband armchair armed armful armhole arming armless armoire armored armory armrest army aroma arose around arousal arrange array arrest arrival arrive arrogance arrogant arson art ascend ascension ascent ascertain ashamed ashen ashes ashy aside askew asleep asparagus aspect aspirate aspire aspirin astonish astound astride astrology astronaut astronomy astute atlantic atlas atom atonable atop atrium atrocious atrophy attach attain attempt attendant attendee attention attentive attest attic attire attitude attractor attribute atypical auction audacious audacity audible audibly audience audio audition augmented august authentic author autism autistic autograph automaker automated automatic autopilot available avalanche avatar avenge avenging avenue average aversion avert aviation aviator avid avoid await awaken award aware awhile awkward awning awoke awry axis babble babbling babied baboon backache backboard backboned backdrop backed backer backfield backfire backhand backing backlands backlash backless backlight backlit backlog backpack backpedal backrest backroom backshift backside backslid backspace backspin backstab backstage backtalk backtrack backup backward backwash backwater backyard bacon bacteria bacterium badass badge badland badly badness baffle baffling bagel bagful baggage bagged baggie bagginess bagging baggy bagpipe baguette baked bakery bakeshop baking balance balancing balcony balmy balsamic bamboo banana banish banister banjo bankable bankbook banked banker banking banknote bankroll banner bannister banshee banter barbecue barbed barbell barber barcode barge bargraph barista baritone barley barmaid barman barn barometer barrack barracuda barrel barrette barricade barrier barstool bartender barterer bash basically basics basil basin basis basket batboy batch bath baton bats battalion battered battering battery batting battle bauble bazooka blabber bladder blade blah blame blaming blanching blandness blank blaspheme blasphemy blast blatancy blatantly blazer blazing bleach bleak bleep blemish blend bless blighted blimp bling blinked blinker blinking blinks blip blissful blitz blizzard bloated bloating blob blog bloomers blooming blooper blot blouse blubber bluff bluish blunderer blunt blurb blurred blurry blurt blush blustery boaster boastful boasting boat bobbed bobbing bobble bobcat bobsled bobtail bodacious body bogged boggle bogus boil bok bolster bolt bonanza bonded bonding bondless boned bonehead boneless bonelike boney bonfire bonnet bonsai bonus bony boogeyman boogieman book boondocks booted booth bootie booting bootlace bootleg boots boozy borax boring borough borrower borrowing boss botanical botanist botany botch both bottle bottling bottom bounce bouncing bouncy bounding boundless bountiful bovine boxcar boxer boxing boxlike boxy breach breath breeches breeching breeder breeding breeze breezy brethren brewery brewing briar bribe brick bride bridged brigade bright brilliant brim bring brink brisket briskly briskness bristle brittle broadband broadcast broaden broadly broadness broadside broadways broiler broiling broken broker bronchial bronco bronze bronzing brook broom brought browbeat brownnose browse browsing bruising brunch brunette brunt brush brussels brute brutishly bubble bubbling bubbly buccaneer bucked bucket buckle buckshot buckskin bucktooth buckwheat buddhism buddhist budding buddy budget buffalo buffed buffer buffing buffoon buggy bulb bulge bulginess bulgur bulk bulldog bulldozer bullfight bullfrog bullhorn bullion bullish bullpen bullring bullseye bullwhip bully bunch bundle bungee bunion bunkbed bunkhouse bunkmate bunny bunt busboy bush busily busload bust busybody buzz cabana cabbage cabbie cabdriver cable caboose cache cackle cacti cactus caddie caddy cadet cadillac cadmium cage cahoots cake calamari calamity calcium calculate calculus caliber calibrate calm caloric calorie calzone camcorder cameo camera camisole camper campfire camping campsite campus canal canary cancel candied candle candy cane canine canister cannabis canned canning cannon cannot canola canon canopener canopy canteen canyon capable capably capacity cape capillary capital capitol capped capricorn capsize capsule caption captivate captive captivity capture caramel carat caravan carbon cardboard carded cardiac cardigan cardinal cardstock carefully caregiver careless caress caretaker cargo caring carless carload carmaker carnage carnation carnival carnivore carol carpenter carpentry carpool carport carried carrot carrousel carry cartel cartload carton cartoon cartridge cartwheel carve carving carwash cascade case cash casing casino casket cassette casually casualty catacomb catalog catalyst catalyze catapult cataract catatonic catcall catchable catcher catching catchy caterer catering catfight catfish cathedral cathouse catlike catnap catnip catsup cattail cattishly cattle catty catwalk caucasian caucus causal causation cause causing cauterize caution cautious cavalier cavalry caviar cavity cedar celery celestial celibacy celibate celtic cement census ceramics ceremony certainly certainty certified certify cesarean cesspool chafe chaffing chain chair chalice challenge chamber chamomile champion chance change channel chant chaos chaperone chaplain chapped chaps chapter character charbroil charcoal charger charging chariot charity charm charred charter charting chase chasing chaste chastise chastity chatroom chatter chatting chatty cheating cheddar cheek cheer cheese cheesy chef chemicals chemist chemo cherisher cherub chess chest chevron chevy chewable chewer chewing chewy chief chihuahua childcare childhood childish childless childlike chili chill chimp chip chirping chirpy chitchat chivalry chive chloride chlorine choice chokehold choking chomp chooser choosing choosy chop chosen chowder chowtime chrome chubby chuck chug chummy chump chunk churn chute cider cilantro cinch cinema cinnamon circle circling circular circulate circus citable citadel citation citizen citric citrus city civic civil clad claim clambake clammy clamor clamp clamshell clang clanking clapped clapper clapping clarify clarinet clarity clash clasp class clatter clause clavicle claw clay clean clear cleat cleaver cleft clench clergyman clerical clerk clever clicker client climate climatic cling clinic clinking clip clique cloak clobber clock clone cloning closable closure clothes clothing cloud clover clubbed clubbing clubhouse clump clumsily clumsy clunky clustered clutch clutter coach coagulant coastal coaster coasting coastland coastline coat coauthor cobalt cobbler cobweb cocoa coconut cod coeditor coerce coexist coffee cofounder cognition cognitive cogwheel coherence coherent cohesive coil coke cola cold coleslaw coliseum collage collapse collar collected collector collide collie collision colonial colonist colonize colony colossal colt coma come comfort comfy comic coming comma commence commend comment commerce commode commodity commodore common commotion commute commuting compacted compacter compactly compactor companion company compare compel compile comply component composed composer composite compost composure compound compress comprised computer computing comrade concave conceal conceded concept concerned concert conch concierge concise conclude concrete concur condense condiment condition condone conducive conductor conduit cone confess confetti confidant confident confider confiding configure confined confining confirm conflict conform confound confront confused confusing confusion congenial congested congrats congress conical conjoined conjure conjuror connected connector consensus consent console consoling consonant constable constant constrain constrict construct consult consumer consuming contact container contempt contend contented contently contents contest context contort contour contrite control contusion convene convent copartner cope copied copier copilot coping copious copper copy coral cork cornball cornbread corncob cornea corned corner cornfield cornflake cornhusk cornmeal cornstalk corny coronary coroner corporal corporate corral correct corridor corrode corroding corrosive corsage corset cortex cosigner cosmetics cosmic cosmos cosponsor cost cottage cotton couch cough could countable countdown counting countless country county courier covenant cover coveted coveting coyness cozily coziness cozy crabbing crabgrass crablike crabmeat cradle cradling crafter craftily craftsman craftwork crafty cramp cranberry crane cranial cranium crank crate crave craving crawfish crawlers crawling crayfish crayon crazed crazily craziness crazy creamed creamer creamlike crease creasing creatable create creation creative creature credible credibly credit creed creme creole crepe crept crescent crested cresting crestless crevice crewless crewman crewmate crib cricket cried crier crimp crimson cringe cringing crinkle crinkly crisped crisping crisply crispness crispy criteria critter croak crock crook croon crop cross crouch crouton crowbar crowd crown crucial crudely crudeness cruelly cruelness cruelty crumb crummiest crummy crumpet crumpled cruncher crunching crunchy crusader crushable crushed crusher crushing crust crux crying cryptic crystal cubbyhole cube cubical cubicle cucumber cuddle cuddly cufflink culinary culminate culpable culprit cultivate cultural culture cupbearer cupcake cupid cupped cupping curable curator curdle cure curfew curing curled curler curliness curling curly curry curse cursive cursor curtain curtly curtsy curvature curve curvy cushy cusp cussed custard custodian custody customary customer customize customs cut cycle cyclic cycling cyclist cylinder cymbal cytoplasm cytoplast dab dad daffodil dagger daily daintily dainty dairy daisy dallying dance dancing dandelion dander dandruff dandy danger dangle dangling daredevil dares daringly darkened darkening darkish darkness darkroom darling darn dart darwinism dash dastardly data datebook dating daughter daunting dawdler dawn daybed daybreak daycare daydream daylight daylong dayroom daytime dazzler dazzling deacon deafening deafness dealer dealing dealmaker dealt dean debatable debate debating debit debrief debtless debtor debug debunk decade decaf decal decathlon decay deceased deceit deceiver deceiving december decency decent deception deceptive decibel decidable decimal decimeter decipher deck declared decline decode decompose decorated decorator decoy decrease decree dedicate dedicator deduce deduct deed deem deepen deeply deepness deface defacing defame default defeat defection defective defendant defender defense defensive deferral deferred defiance defiant defile defiling define definite deflate deflation deflator deflected deflector defog deforest defraud defrost deftly defuse defy degraded degrading degrease degree dehydrate deity dejected delay delegate delegator delete deletion delicacy delicate delicious delighted delirious delirium deliverer delivery delouse delta deluge delusion deluxe demanding demeaning demeanor demise democracy democrat demote demotion demystify denatured deniable denial denim denote dense density dental dentist denture deny deodorant deodorize departed departure depict deplete depletion deplored deploy deport depose depraved depravity deprecate depress deprive depth deputize deputy derail deranged derby derived desecrate deserve deserving designate designed designer designing deskbound desktop deskwork desolate despair despise despite destiny destitute destruct detached detail detection detective detector detention detergent detest detonate detonator detoxify detract deuce devalue deviancy deviant deviate deviation deviator device devious devotedly devotee devotion devourer devouring devoutly dexterity dexterous diabetes diabetic diabolic diagnoses diagnosis diagram dial diameter diaper diaphragm diary dice dicing dictate dictation dictator difficult diffused diffuser diffusion diffusive dig dilation diligence diligent dill dilute dime diminish dimly dimmed dimmer dimness dimple diner dingbat dinghy dinginess dingo dingy dining dinner diocese dioxide diploma dipped dipper dipping directed direction directive directly directory direness dirtiness disabled disagree disallow disarm disarray disaster disband disbelief disburse discard discern discharge disclose discolor discount discourse discover discuss disdain disengage disfigure disgrace dish disinfect disjoin disk dislike disliking dislocate dislodge disloyal dismantle dismay dismiss dismount disobey disorder disown disparate disparity dispatch dispense dispersal dispersed disperser displace display displease disposal dispose disprove dispute disregard disrupt dissuade distance distant distaste distill distinct distort distract distress district distrust ditch ditto ditzy dividable divided dividend dividers dividing divinely diving divinity divisible divisibly division divisive divorcee dizziness dizzy doable docile dock doctrine document dodge dodgy doily doing dole dollar dollhouse dollop dolly dolphin domain domelike domestic dominion dominoes donated donation donator donor donut doodle doorbell doorframe doorknob doorman doormat doornail doorpost doorstep doorstop doorway doozy dork dormitory dorsal dosage dose dotted doubling douche dove down dowry doze drab dragging dragonfly dragonish dragster drainable drainage drained drainer drainpipe dramatic dramatize drank drapery drastic draw dreaded dreadful dreadlock dreamboat dreamily dreamland dreamless dreamlike dreamt dreamy drearily dreary drench dress drew dribble dried drier drift driller drilling drinkable drinking dripping drippy drivable driven driver driveway driving drizzle drizzly drone drool droop drop-down dropbox dropkick droplet dropout dropper drove drown drowsily drudge drum dry dubbed dubiously duchess duckbill ducking duckling ducktail ducky duct dude duffel dugout duh duke duller dullness duly dumping dumpling dumpster duo dupe duplex duplicate duplicity durable durably duration duress during dusk dust dutiful duty duvet dwarf dweeb dwelled dweller dwelling dwindle dwindling dynamic dynamite dynasty dyslexia dyslexic each eagle earache eardrum earflap earful earlobe early earmark earmuff earphone earpiece earplugs earring earshot earthen earthlike earthling earthly earthworm earthy earwig easeful easel easiest easily easiness easing eastbound eastcoast easter eastward eatable eaten eatery eating eats ebay ebony ebook ecard eccentric echo eclair eclipse ecologist ecology economic economist economy ecosphere ecosystem edge edginess edging edgy edition editor educated education educator eel effective effects efficient effort eggbeater egging eggnog eggplant eggshell egomaniac egotism egotistic either eject elaborate elastic elated elbow eldercare elderly eldest electable election elective elephant elevate elevating elevation elevator eleven elf eligible eligibly eliminate elite elitism elixir elk ellipse elliptic elm elongated elope eloquence eloquent elsewhere elude elusive elves email embargo embark embassy embattled embellish ember embezzle emblaze emblem embody embolism emboss embroider emcee emerald emergency emission emit emote emoticon emotion empathic empathy emperor emphases emphasis emphasize emphatic empirical employed employee employer emporium empower emptier emptiness empty emu enable enactment enamel enchanted enchilada encircle enclose enclosure encode encore encounter encourage encroach encrust encrypt endanger endeared endearing ended ending endless endnote endocrine endorphin endorse endowment endpoint endurable endurance enduring energetic energize energy enforced enforcer engaged engaging engine engorge engraved engraver engraving engross engulf enhance enigmatic enjoyable enjoyably enjoyer enjoying enjoyment enlarged enlarging enlighten enlisted enquirer enrage enrich enroll enslave ensnare ensure entail entangled entering entertain enticing entire entitle entity entomb entourage entrap entree entrench entrust entryway entwine enunciate envelope enviable enviably envious envision envoy envy enzyme epic epidemic epidermal epidermis epidural epilepsy epileptic epilogue epiphany episode equal equate equation equator equinox equipment equity equivocal eradicate erasable erased eraser erasure ergonomic errand errant erratic error erupt escalate escalator escapable escapade escapist escargot eskimo esophagus espionage espresso esquire essay essence essential establish estate esteemed estimate estimator estranged estrogen etching eternal eternity ethanol ether ethically ethics euphemism evacuate evacuee evade evaluate evaluator evaporate evasion evasive even everglade evergreen everybody everyday everyone evict evidence evident evil evoke evolution evolve exact exalted example excavate excavator exceeding exception excess exchange excitable exciting exclaim exclude excluding exclusion exclusive excretion excretory excursion excusable excusably excuse exemplary exemplify exemption exerciser exert exes exfoliate exhale exhaust exhume exile existing exit exodus exonerate exorcism exorcist expand expanse expansion expansive expectant expedited expediter expel expend expenses expensive expert expire expiring explain expletive explicit explode exploit explore exploring exponent exporter exposable expose exposure express expulsion exquisite extended extending extent extenuate exterior external extinct extortion extradite extras extrovert extrude extruding exuberant fable fabric fabulous facebook facecloth facedown faceless facelift faceplate faceted facial facility facing facsimile faction factoid factor factsheet factual faculty fade fading failing falcon fall false falsify fame familiar family famine famished fanatic fancied fanciness fancy fanfare fang fanning fantasize fantastic fantasy fascism fastball faster fasting fastness faucet favorable favorably favored favoring favorite fax feast federal fedora feeble feed feel feisty feline felt-tip feminine feminism feminist feminize femur fence fencing fender ferment fernlike ferocious ferocity ferret ferris ferry fervor fester festival festive festivity fetal fetch fever fiber fiction fiddle fiddling fidelity fidgeting fidgety fifteen fifth fiftieth fifty figment figure figurine filing filled filler filling film filter filth filtrate finale finalist finalize finally finance financial finch fineness finer finicky finished finisher finishing finite finless finlike fiscally fit five flaccid flagman flagpole flagship flagstick flagstone flail flakily flaky flame flammable flanked flanking flannels flap flaring flashback flashbulb flashcard flashily flashing flashy flask flatbed flatfoot flatly flatness flatten flattered flatterer flattery flattop flatware flatworm flavored flavorful flavoring flaxseed fled fleshed fleshy flick flier flight flinch fling flint flip flirt float flock flogging flop floral florist floss flounder flyable flyaway flyer flying flyover flypaper foam foe fog foil folic folk follicle follow fondling fondly fondness fondue font food fool footage football footbath footboard footer footgear foothill foothold footing footless footman footnote footpad footpath footprint footrest footsie footsore footwear footwork fossil foster founder founding fountain fox foyer fraction fracture fragile fragility fragment fragrance fragrant frail frame framing frantic fraternal frayed fraying frays freckled freckles freebase freebee freebie freedom freefall freehand freeing freeload freely freemason freeness freestyle freeware freeway freewill freezable freezing freight french frenzied frenzy frequency frequent fresh fretful fretted friction friday fridge fried friend frighten frightful frigidity frigidly frill fringe frisbee frisk fritter frivolous frolic from front frostbite frosted frostily frosting frostlike frosty froth frown frozen fructose frugality frugally fruit frustrate frying gab gaffe gag gainfully gaining gains gala gallantly galleria gallery galley gallon gallows gallstone galore galvanize gambling game gaming gamma gander gangly gangrene gangway gap garage garbage garden gargle garland garlic garment garnet garnish garter gas gatherer gathering gating gauging gauntlet gauze gave gawk gazing gear gecko geek geiger gem gender generic generous genetics genre gentile gentleman gently gents geography geologic geologist geology geometric geometry geranium gerbil geriatric germicide germinate germless germproof gestate gestation gesture getaway getting getup giant gibberish giblet giddily giddiness giddy gift gigabyte gigahertz gigantic giggle giggling giggly gigolo gilled gills gimmick girdle giveaway given giver giving gizmo gizzard glacial glacier glade gladiator gladly glamorous glamour glance glancing glandular glare glaring glass glaucoma glazing gleaming gleeful glider gliding glimmer glimpse glisten glitch glitter glitzy gloater gloating gloomily gloomy glorified glorifier glorify glorious glory gloss glove glowing glowworm glucose glue gluten glutinous glutton gnarly gnat goal goatskin goes goggles going goldfish goldmine goldsmith golf goliath gonad gondola gone gong good gooey goofball goofiness goofy google goon gopher gore gorged gorgeous gory gosling gossip gothic gotten gout gown grab graceful graceless gracious gradation graded grader gradient grading gradually graduate graffiti grafted grafting grain granddad grandkid grandly grandma grandpa grandson granite granny granola grant granular grape graph grapple grappling grasp grass gratified gratify grating gratitude gratuity gravel graveness graves graveyard gravitate gravity gravy gray grazing greasily greedily greedless greedy green greeter greeting grew greyhound grid grief grievance grieving grievous grill grimace grimacing grime griminess grimy grinch grinning grip gristle grit groggily groggy groin groom groove grooving groovy grope ground grouped grout grove grower growing growl grub grudge grudging grueling gruffly grumble grumbling grumbly grumpily grunge grunt guacamole guidable guidance guide guiding guileless guise gulf gullible gully gulp gumball gumdrop gumminess gumming gummy gurgle gurgling guru gush gusto gusty gutless guts gutter guy guzzler gyration habitable habitant habitat habitual hacked hacker hacking hacksaw had haggler haiku half halogen halt halved halves hamburger hamlet hammock hamper hamster hamstring handbag handball handbook handbrake handcart handclap handclasp handcraft handcuff handed handful handgrip handgun handheld handiness handiwork handlebar handled handler handling handmade handoff handpick handprint handrail handsaw handset handsfree handshake handstand handwash handwork handwoven handwrite handyman hangnail hangout hangover hangup hankering hankie hanky haphazard happening happier happiest happily happiness happy harbor hardcopy hardcore hardcover harddisk hardened hardener hardening hardhat hardhead hardiness hardly hardness hardship hardware hardwired hardwood hardy harmful harmless harmonica harmonics harmonize harmony harness harpist harsh harvest hash hassle haste hastily hastiness hasty hatbox hatchback hatchery hatchet hatching hatchling hate hatless hatred haunt haven hazard hazelnut hazily haziness hazing hazy headache headband headboard headcount headdress headed header headfirst headgear heading headlamp headless headlock headphone headpiece headrest headroom headscarf headset headsman headstand headstone headway headwear heap heat heave heavily heaviness heaving hedge hedging heftiness hefty helium helmet helper helpful helping helpless helpline hemlock hemstitch hence henchman henna herald herbal herbicide herbs heritage hermit heroics heroism herring herself hertz hesitancy hesitant hesitate hexagon hexagram hubcap huddle huddling huff hug hula hulk hull human humble humbling humbly humid humiliate humility humming hummus humongous humorist humorless humorous humpback humped humvee hunchback hundredth hunger hungrily hungry hunk hunter hunting huntress huntsman hurdle hurled hurler hurling hurray hurricane hurried hurry hurt husband hush husked huskiness hut hybrid hydrant hydrated hydration hydrogen hydroxide hyperlink hypertext hyphen hypnoses hypnosis hypnotic hypnotism hypnotist hypnotize hypocrisy hypocrite ibuprofen ice iciness icing icky icon icy idealism idealist idealize ideally idealness identical identify identity ideology idiocy idiom idly igloo ignition ignore iguana illicitly illusion illusive image imaginary imagines imaging imbecile imitate imitation immature immerse immersion imminent immobile immodest immorally immortal immovable immovably immunity immunize impaired impale impart impatient impeach impeding impending imperfect imperial impish implant implement implicate implicit implode implosion implosive imply impolite important importer impose imposing impotence impotency impotent impound imprecise imprint imprison impromptu improper improve improving improvise imprudent impulse impulsive impure impurity iodine iodize ion ipad iphone ipod irate irk iron irregular irrigate irritable irritably irritant irritate islamic islamist isolated isolating isolation isotope issue issuing italicize italics item itinerary itunes ivory ivy jab jackal jacket jackknife jackpot jailbird jailbreak jailer jailhouse jalapeno jam janitor january jargon jarring jasmine jaundice jaunt java jawed jawless jawline jaws jaybird jaywalker jazz jeep jeeringly jellied jelly jersey jester jet jiffy jigsaw jimmy jingle jingling jinx jitters jittery job jockey jockstrap jogger jogging john joining jokester jokingly jolliness jolly jolt jot jovial joyfully joylessly joyous joyride joystick jubilance jubilant judge judgingly judicial judiciary judo juggle juggling jugular juice juiciness juicy jujitsu jukebox july jumble jumbo jump junction juncture june junior juniper junkie junkman junkyard jurist juror jury justice justifier justify justly justness juvenile kabob kangaroo karaoke karate karma kebab keenly keenness keep keg kelp kennel kept kerchief kerosene kettle kick kiln kilobyte kilogram kilometer kilowatt kilt kimono kindle kindling kindly kindness kindred kinetic kinfolk king kinship kinsman kinswoman kissable kisser kissing kitchen kite kitten kitty kiwi kleenex knapsack knee knelt knickers knoll koala kooky kosher krypton kudos kung labored laborer laboring laborious labrador ladder ladies ladle ladybug ladylike lagged lagging lagoon lair lake lance landed landfall landfill landing landlady landless landline landlord landmark landmass landmine landowner landscape landside landslide language lankiness lanky lantern lapdog lapel lapped lapping laptop lard large lark lash lasso last latch late lather latitude latrine latter latticed launch launder laundry laurel lavender lavish laxative lazily laziness lazy lecturer left legacy legal legend legged leggings legible legibly legislate lego legroom legume legwarmer legwork lemon lend length lens lent leotard lesser letdown lethargic lethargy letter lettuce level leverage levers levitate levitator liability liable liberty librarian library licking licorice lid life lifter lifting liftoff ligament likely likeness likewise liking lilac lilly lily limb limeade limelight limes limit limping limpness line lingo linguini linguist lining linked linoleum linseed lint lion lip liquefy liqueur liquid lisp list litigate litigator litmus litter little livable lived lively liver livestock lividly living lizard lubricant lubricate lucid luckily luckiness luckless lucrative ludicrous lugged lukewarm lullaby lumber luminance luminous lumpiness lumping lumpish lunacy lunar lunchbox luncheon lunchroom lunchtime lung lurch lure luridness lurk lushly lushness luster lustfully lustily lustiness lustrous lusty luxurious luxury lying lyrically lyricism lyricist lyrics macarena macaroni macaw mace machine machinist magazine magenta maggot magical magician magma magnesium magnetic magnetism magnetize magnifier magnify magnitude magnolia mahogany maimed majestic majesty majorette majority makeover maker makeshift making malformed malt mama mammal mammary mammogram manager managing manatee mandarin mandate mandatory mandolin manger mangle mango mangy manhandle manhole manhood manhunt manicotti manicure manifesto manila mankind manlike manliness manly manmade manned mannish manor manpower mantis mantra manual many map marathon marauding marbled marbles marbling march mardi margarine margarita margin marigold marina marine marital maritime marlin marmalade maroon married marrow marry marshland marshy marsupial marvelous marxism mascot masculine mashed mashing massager masses massive mastiff matador matchbook matchbox matcher matching matchless material maternal maternity math mating matriarch matrimony matrix matron matted matter maturely maturing maturity mauve maverick maximize maximum maybe mayday mayflower moaner moaning mobile mobility mobilize mobster mocha mocker mockup modified modify modular modulator module moisten moistness moisture molar molasses mold molecular molecule molehill mollusk mom monastery monday monetary monetize moneybags moneyless moneywise mongoose mongrel monitor monkhood monogamy monogram monologue monopoly monorail monotone monotype monoxide monsieur monsoon monstrous monthly monument moocher moodiness moody mooing moonbeam mooned moonlight moonlike moonlit moonrise moonscape moonshine moonstone moonwalk mop morale morality morally morbidity morbidly morphine morphing morse mortality mortally mortician mortified mortify mortuary mosaic mossy most mothball mothproof motion motivate motivator motive motocross motor motto mountable mountain mounted mounting mourner mournful mouse mousiness moustache mousy mouth movable move movie moving mower mowing much muck mud mug mulberry mulch mule mulled mullets multiple multiply multitask multitude mumble mumbling mumbo mummified mummify mummy mumps munchkin mundane municipal muppet mural murkiness murky murmuring muscular museum mushily mushiness mushroom mushy music musket muskiness musky mustang mustard muster mustiness musty mutable mutate mutation mute mutilated mutilator mutiny mutt mutual muzzle myself myspace mystified mystify myth nacho nag nail name naming nanny nanometer nape napkin napped napping nappy narrow nastily nastiness national native nativity natural nature naturist nautical navigate navigator navy nearby nearest nearly nearness neatly neatness nebula nebulizer nectar negate negation negative neglector negligee negligent negotiate nemeses nemesis neon nephew nerd nervous nervy nest net neurology neuron neurosis neurotic neuter neutron never next nibble nickname nicotine niece nifty nimble nimbly nineteen ninetieth ninja nintendo ninth nuclear nuclei nucleus nugget nullify number numbing numbly numbness numeral numerate numerator numeric numerous nuptials nursery nursing nurture nutcase nutlike nutmeg nutrient nutshell nuttiness nutty nuzzle nylon oaf oak oasis oat obedience obedient obituary object obligate obliged oblivion oblivious oblong obnoxious oboe obscure obscurity observant observer observing obsessed obsession obsessive obsolete obstacle obstinate obstruct obtain obtrusive obtuse obvious occultist occupancy occupant occupier occupy ocean ocelot octagon octane october octopus ogle oil oink ointment okay old olive olympics omega omen ominous omission omit omnivore onboard oncoming ongoing onion online onlooker only onscreen onset onshore onslaught onstage onto onward onyx oops ooze oozy opacity opal open operable operate operating operation operative operator opium opossum opponent oppose opposing opposite oppressed oppressor opt opulently osmosis other otter ouch ought ounce outage outback outbid outboard outbound outbreak outburst outcast outclass outcome outdated outdoors outer outfield outfit outflank outgoing outgrow outhouse outing outlast outlet outline outlook outlying outmatch outmost outnumber outplayed outpost outpour output outrage outrank outreach outright outscore outsell outshine outshoot outsider outskirts outsmart outsource outspoken outtakes outthink outward outweigh outwit oval ovary oven overact overall overarch overbid overbill overbite overblown overboard overbook overbuilt overcast overcoat overcome overcook overcrowd overdraft overdrawn overdress overdrive overdue overeager overeater overexert overfed overfeed overfill overflow overfull overgrown overhand overhang overhaul overhead overhear overheat overhung overjoyed overkill overlabor overlaid overlap overlay overload overlook overlord overlying overnight overpass overpay overplant overplay overpower overprice overrate overreach overreact override overripe overrule overrun overshoot overshot oversight oversized oversleep oversold overspend overstate overstay overstep overstock overstuff oversweet overtake overthrow overtime overtly overtone overture overturn overuse overvalue overview overwrite owl oxford oxidant oxidation oxidize oxidizing oxygen oxymoron oyster ozone paced pacemaker pacific pacifier pacifism pacifist pacify padded padding paddle paddling padlock pagan pager paging pajamas palace palatable palm palpable palpitate paltry pampered pamperer pampers pamphlet panama pancake pancreas panda pandemic pang panhandle panic panning panorama panoramic panther pantomime pantry pants pantyhose paparazzi papaya paper paprika papyrus parabola parachute parade paradox paragraph parakeet paralegal paralyses paralysis paralyze paramedic parameter paramount parasail parasite parasitic parcel parched parchment pardon parish parka parking parkway parlor parmesan parole parrot parsley parsnip partake parted parting partition partly partner partridge party passable passably passage passcode passenger passerby passing passion passive passivism passover passport password pasta pasted pastel pastime pastor pastrami pasture pasty patchwork patchy paternal paternity path patience patient patio patriarch patriot patrol patronage patronize pauper pavement paver pavestone pavilion paving pawing payable payback paycheck payday payee payer paying payment payphone payroll pebble pebbly pecan pectin peculiar peddling pediatric pedicure pedigree pedometer pegboard pelican pellet pelt pelvis penalize penalty pencil pendant pending penholder penknife pennant penniless penny penpal pension pentagon pentagram pep perceive percent perch percolate perennial perfected perfectly perfume periscope perish perjurer perjury perkiness perky perm peroxide perpetual perplexed persecute persevere persuaded persuader pesky peso pessimism pessimist pester pesticide petal petite petition petri petroleum petted petticoat pettiness petty petunia phantom phobia phoenix phonebook phoney phonics phoniness phony phosphate photo phrase phrasing placard placate placidly plank planner plant plasma plaster plastic plated platform plating platinum platonic platter platypus plausible plausibly playable playback player playful playgroup playhouse playing playlist playmaker playmate playoff playpen playroom playset plaything playtime plaza pleading pleat pledge plentiful plenty plethora plexiglas pliable plod plop plot plow ploy pluck plug plunder plunging plural plus plutonium plywood poach pod poem poet pogo pointed pointer pointing pointless pointy poise poison poker poking polar police policy polio polish politely polka polo polyester polygon polygraph polymer poncho pond pony popcorn pope poplar popper poppy popsicle populace popular populate porcupine pork porous porridge portable portal portfolio porthole portion portly portside poser posh posing possible possibly possum postage postal postbox postcard posted poster posting postnasal posture postwar pouch pounce pouncing pound pouring pout powdered powdering powdery power powwow pox praising prance prancing pranker prankish prankster prayer praying preacher preaching preachy preamble precinct precise precision precook precut predator predefine predict preface prefix preflight preformed pregame pregnancy pregnant preheated prelaunch prelaw prelude premiere premises premium prenatal preoccupy preorder prepaid prepay preplan preppy preschool prescribe preseason preset preshow president presoak press presume presuming preteen pretended pretender pretense pretext pretty pretzel prevail prevalent prevent preview previous prewar prewashed prideful pried primal primarily primary primate primer primp princess print prior prism prison prissy pristine privacy private privatize prize proactive probable probably probation probe probing probiotic problem procedure process proclaim procreate procurer prodigal prodigy produce product profane profanity professed professor profile profound profusely progeny prognosis program progress projector prologue prolonged promenade prominent promoter promotion prompter promptly prone prong pronounce pronto proofing proofread proofs propeller properly property proponent proposal propose props prorate protector protegee proton prototype protozoan protract protrude proud provable proved proven provided provider providing province proving provoke provoking provolone prowess prowler prowling proximity proxy prozac prude prudishly prune pruning pry psychic public publisher pucker pueblo pug pull pulmonary pulp pulsate pulse pulverize puma pumice pummel punch punctual punctuate punctured pungent punisher punk pupil puppet puppy purchase pureblood purebred purely pureness purgatory purge purging purifier purify purist puritan purity purple purplish purposely purr purse pursuable pursuant pursuit purveyor pushcart pushchair pusher pushiness pushing pushover pushpin pushup pushy putdown putt puzzle puzzling pyramid pyromania python quack quadrant quail quaintly quake quaking qualified qualifier qualify quality qualm quantum quarrel quarry quartered quarterly quarters quartet quench query quicken quickly quickness quicksand quickstep quiet quill quilt quintet quintuple quirk quit quiver quizzical quotable quotation quote rabid race racing racism rack racoon radar radial radiance radiantly radiated radiation radiator radio radish raffle raft rage ragged raging ragweed raider railcar railing railroad railway raisin rake raking rally ramble rambling ramp ramrod ranch rancidity random ranged ranger ranging ranked ranking ransack ranting rants rare rarity rascal rash rasping ravage raven ravine raving ravioli ravishing reabsorb reach reacquire reaction reactive reactor reaffirm ream reanalyze reappear reapply reappoint reapprove rearrange rearview reason reassign reassure reattach reawake rebalance rebate rebel rebirth reboot reborn rebound rebuff rebuild rebuilt reburial rebuttal recall recant recapture recast recede recent recess recharger recipient recital recite reckless reclaim recliner reclining recluse reclusive recognize recoil recollect recolor reconcile reconfirm reconvene recopy record recount recoup recovery recreate rectal rectangle rectified rectify recycled recycler recycling reemerge reenact reenter reentry reexamine referable referee reference refill refinance refined refinery refining refinish reflected reflector reflex reflux refocus refold reforest reformat reformed reformer reformist refract refrain refreeze refresh refried refueling refund refurbish refurnish refusal refuse refusing refutable refute regain regalia regally reggae regime region register registrar registry regress regretful regroup regular regulate regulator rehab reheat rehire rehydrate reimburse reissue reiterate rejoice rejoicing rejoin rekindle relapse relapsing relatable related relation relative relax relay relearn release relenting reliable reliably reliance reliant relic relieve relieving relight relish relive reload relocate relock reluctant rely remake remark remarry rematch remedial remedy remember reminder remindful remission remix remnant remodeler remold remorse remote removable removal removed remover removing rename renderer rendering rendition renegade renewable renewably renewal renewed renounce renovate renovator rentable rental rented renter reoccupy reoccur reopen reorder repackage repacking repaint repair repave repaying repayment repeal repeated repeater repent rephrase replace replay replica reply reporter repose repossess repost repressed reprimand reprint reprise reproach reprocess reproduce reprogram reps reptile reptilian repugnant repulsion repulsive repurpose reputable reputably request require requisite reroute rerun resale resample rescuer reseal research reselect reseller resemble resend resent reset reshape reshoot reshuffle residence residency resident residual residue resigned resilient resistant resisting resize resolute resolved resonant resonate resort resource respect resubmit result resume resupply resurface resurrect retail retainer retaining retake retaliate retention rethink retinal retired retiree retiring retold retool retorted retouch retrace retract retrain retread retreat retrial retrieval retriever retry return retying retype reunion reunite reusable reuse reveal reveler revenge revenue reverb revered reverence reverend reversal reverse reversing reversion revert revisable revise revision revisit revivable revival reviver reviving revocable revoke revolt revolver revolving reward rewash rewind rewire reword rework rewrap rewrite rhyme ribbon ribcage rice riches richly richness rickety ricotta riddance ridden ride riding rifling rift rigging rigid rigor rimless rimmed rind rink rinse rinsing riot ripcord ripeness ripening ripping ripple rippling riptide rise rising risk risotto ritalin ritzy rival riverbank riverbed riverboat riverside riveter riveting roamer roaming roast robbing robe robin robotics robust rockband rocker rocket rockfish rockiness rocking rocklike rockslide rockstar rocky rogue roman romp rope roping roster rosy rotten rotting rotunda roulette rounding roundish roundness roundup roundworm routine routing rover roving royal rubbed rubber rubbing rubble rubdown ruby ruckus rudder rug ruined rule rumble rumbling rummage rumor runaround rundown runner running runny runt runway rupture rural ruse rush rust rut sabbath sabotage sacrament sacred sacrifice sadden saddlebag saddled saddling sadly sadness safari safeguard safehouse safely safeness saffron saga sage sagging saggy said saint sake salad salami salaried salary saline salon saloon salsa salt salutary salute salvage salvaging salvation same sample sampling sanction sanctity sanctuary sandal sandbag sandbank sandbar sandblast sandbox sanded sandfish sanding sandlot sandpaper sandpit sandstone sandstorm sandworm sandy sanitary sanitizer sank santa sapling sappiness sappy sarcasm sarcastic sardine sash sasquatch sassy satchel satiable satin satirical satisfied satisfy saturate saturday sauciness saucy sauna savage savanna saved savings savior savor saxophone say scabbed scabby scalded scalding scale scaling scallion scallop scalping scam scandal scanner scanning scant scapegoat scarce scarcity scarecrow scared scarf scarily scariness scarring scary scavenger scenic schedule schematic scheme scheming schilling schnapps scholar science scientist scion scoff scolding scone scoop scooter scope scorch scorebook scorecard scored scoreless scorer scoring scorn scorpion scotch scoundrel scoured scouring scouting scouts scowling scrabble scraggly scrambled scrambler scrap scratch scrawny screen scribble scribe scribing scrimmage script scroll scrooge scrounger scrubbed scrubber scruffy scrunch scrutiny scuba scuff sculptor sculpture scurvy scuttle secluded secluding seclusion second secrecy secret sectional sector secular securely security sedan sedate sedation sedative sediment seduce seducing segment seismic seizing seldom selected selection selective selector self seltzer semantic semester semicolon semifinal seminar semisoft semisweet senate senator send senior senorita sensation sensitive sensitize sensually sensuous sepia september septic septum sequel sequence sequester series sermon serotonin serpent serrated serve service serving sesame sessions setback setting settle settling setup sevenfold seventeen seventh seventy severity shabby shack shaded shadily shadiness shading shadow shady shaft shakable shakily shakiness shaking shaky shale shallot shallow shame shampoo shamrock shank shanty shape shaping share sharpener sharper sharpie sharply sharpness shawl sheath shed sheep sheet shelf shell shelter shelve shelving sherry shield shifter shifting shiftless shifty shimmer shimmy shindig shine shingle shininess shining shiny ship shirt shivering shock shone shoplift shopper shopping shoptalk shore shortage shortcake shortcut shorten shorter shorthand shortlist shortly shortness shorts shortwave shorty shout shove showbiz showcase showdown shower showgirl showing showman shown showoff showpiece showplace showroom showy shrank shrapnel shredder shredding shrewdly shriek shrill shrimp shrine shrink shrivel shrouded shrubbery shrubs shrug shrunk shucking shudder shuffle shuffling shun shush shut shy siamese siberian sibling siding sierra siesta sift sighing silenced silencer silent silica silicon silk silliness silly silo silt silver similarly simile simmering simple simplify simply sincere sincerity singer singing single singular sinister sinless sinner sinuous sip siren sister sitcom sitter sitting situated situation sixfold sixteen sixth sixties sixtieth sixtyfold sizable sizably size sizing sizzle sizzling skater skating skedaddle skeletal skeleton skeptic sketch skewed skewer skid skied skier skies skiing skilled skillet skillful skimmed skimmer skimming skimpily skincare skinhead skinless skinning skinny skintight skipper skipping skirmish skirt skittle skydiver skylight skyline skype skyrocket skyward slab slacked slacker slacking slackness slacks slain slam slander slang slapping slapstick slashed slashing slate slather slaw sled sleek sleep sleet sleeve slept sliceable sliced slicer slicing slick slider slideshow sliding slighted slighting slightly slimness slimy slinging slingshot slinky slip slit sliver slobbery slogan sloped sloping sloppily sloppy slot slouching slouchy sludge slug slum slurp slush sly small smartly smartness smasher smashing smashup smell smelting smile smilingly smirk smite smith smitten smock smog smoked smokeless smokiness smoking smoky smolder smooth smother smudge smudgy smuggler smuggling smugly smugness snack snagged snaking snap snare snarl snazzy sneak sneer sneeze sneezing snide sniff snippet snipping snitch snooper snooze snore snoring snorkel snort snout snowbird snowboard snowbound snowcap snowdrift snowdrop snowfall snowfield snowflake snowiness snowless snowman snowplow snowshoe snowstorm snowsuit snowy snub snuff snuggle snugly snugness speak spearfish spearhead spearman spearmint species specimen specked speckled specks spectacle spectator spectrum speculate speech speed spellbind speller spelling spendable spender spending spent spew sphere spherical sphinx spider spied spiffy spill spilt spinach spinal spindle spinner spinning spinout spinster spiny spiral spirited spiritism spirits spiritual splashed splashing splashy splatter spleen splendid splendor splice splicing splinter splotchy splurge spoilage spoiled spoiler spoiling spoils spoken spokesman sponge spongy sponsor spoof spookily spooky spool spoon spore sporting sports sporty spotless spotlight spotted spotter spotting spotty spousal spouse spout sprain sprang sprawl spray spree sprig spring sprinkled sprinkler sprint sprite sprout spruce sprung spry spud spur sputter spyglass squabble squad squall squander squash squatted squatter squatting squeak squealer squealing squeamish squeegee squeeze squeezing squid squiggle squiggly squint squire squirt squishier squishy stability stabilize stable stack stadium staff stage staging stagnant stagnate stainable stained staining stainless stalemate staleness stalling stallion stamina stammer stamp stand stank staple stapling starboard starch stardom stardust starfish stargazer staring stark starless starlet starlight starlit starring starry starship starter starting startle startling startup starved starving stash state static statistic statue stature status statute statutory staunch stays steadfast steadier steadily steadying steam steed steep steerable steering steersman stegosaur stellar stem stench stencil step stereo sterile sterility sterilize sterling sternness sternum stew stick stiffen stiffly stiffness stifle stifling stillness stilt stimulant stimulate stimuli stimulus stinger stingily stinging stingray stingy stinking stinky stipend stipulate stir stitch stock stoic stoke stole stomp stonewall stoneware stonework stoning stony stood stooge stool stoop stoplight stoppable stoppage stopped stopper stopping stopwatch storable storage storeroom storewide storm stout stove stowaway stowing straddle straggler strained strainer straining strangely stranger strangle strategic strategy stratus straw stray streak stream street strength strenuous strep stress stretch strewn stricken strict stride strife strike striking strive striving strobe strode stroller strongbox strongly strongman struck structure strudel struggle strum strung strut stubbed stubble stubbly stubborn stucco stuck student studied studio study stuffed stuffing stuffy stumble stumbling stump stung stunned stunner stunning stunt stupor sturdily sturdy styling stylishly stylist stylized stylus suave subarctic subatomic subdivide subdued subduing subfloor subgroup subheader subject sublease sublet sublevel sublime submarine submerge submersed submitter subpanel subpar subplot subprime subscribe subscript subsector subside subsiding subsidize subsidy subsoil subsonic substance subsystem subtext subtitle subtly subtotal subtract subtype suburb subway subwoofer subzero succulent such suction sudden sudoku suds sufferer suffering suffice suffix suffocate suffrage sugar suggest suing suitable suitably suitcase suitor sulfate sulfide sulfite sulfur sulk sullen sulphate sulphuric sultry superbowl superglue superhero superior superjet superman supermom supernova supervise supper supplier supply support supremacy supreme surcharge surely sureness surface surfacing surfboard surfer surgery surgical surging surname surpass surplus surprise surreal surrender surrogate surround survey survival survive surviving survivor sushi suspect suspend suspense sustained sustainer swab swaddling swagger swampland swan swapping swarm sway swear sweat sweep swell swept swerve swifter swiftly swiftness swimmable swimmer swimming swimsuit swimwear swinger swinging swipe swirl switch swivel swizzle swooned swoop swoosh swore sworn swung sycamore sympathy symphonic symphony symptom synapse syndrome synergy synopses synopsis synthesis synthetic syrup system t-shirt tabasco tabby tableful tables tablet tableware tabloid tackiness tacking tackle tackling tacky taco tactful tactical tactics tactile tactless tadpole taekwondo tag tainted take taking talcum talisman tall talon tamale tameness tamer tamper tank tanned tannery tanning tantrum tapeless tapered tapering tapestry tapioca tapping taps tarantula target tarmac tarnish tarot tartar tartly tartness task tassel taste tastiness tasting tasty tattered tattle tattling tattoo taunt tavern thank that thaw theater theatrics thee theft theme theology theorize thermal thermos thesaurus these thesis thespian thicken thicket thickness thieving thievish thigh thimble thing think thinly thinner thinness thinning thirstily thirsting thirsty thirteen thirty thong thorn those thousand thrash thread threaten threefold thrift thrill thrive thriving throat throbbing throng throttle throwaway throwback thrower throwing thud thumb thumping thursday thus thwarting thyself tiara tibia tidal tidbit tidiness tidings tidy tiger tighten tightly tightness tightrope tightwad tigress tile tiling till tilt timid timing timothy tinderbox tinfoil tingle tingling tingly tinker tinkling tinsel tinsmith tint tinwork tiny tipoff tipped tipper tipping tiptoeing tiptop tiring tissue trace tracing track traction tractor trade trading tradition traffic tragedy trailing trailside train traitor trance tranquil transfer transform translate transpire transport transpose trapdoor trapeze trapezoid trapped trapper trapping traps trash travel traverse travesty tray treachery treading treadmill treason treat treble tree trekker tremble trembling tremor trench trend trespass triage trial triangle tribesman tribunal tribune tributary tribute triceps trickery trickily tricking trickle trickster tricky tricolor tricycle trident tried trifle trifocals trillion trilogy trimester trimmer trimming trimness trinity trio tripod tripping triumph trivial trodden trolling trombone trophy tropical tropics trouble troubling trough trousers trout trowel truce truck truffle trump trunks trustable trustee trustful trusting trustless truth try tubby tubeless tubular tucking tuesday tug tuition tulip tumble tumbling tummy turban turbine turbofan turbojet turbulent turf turkey turmoil turret turtle tusk tutor tutu tux tweak tweed tweet tweezers twelve twentieth twenty twerp twice twiddle twiddling twig twilight twine twins twirl twistable twisted twister twisting twisty twitch twitter tycoon tying tyke udder ultimate ultimatum ultra umbilical umbrella umpire unabashed unable unadorned unadvised unafraid unaired unaligned unaltered unarmored unashamed unaudited unawake unaware unbaked unbalance unbeaten unbend unbent unbiased unbitten unblended unblessed unblock unbolted unbounded unboxed unbraided unbridle unbroken unbuckled unbundle unburned unbutton uncanny uncapped uncaring uncertain unchain unchanged uncharted uncheck uncivil unclad unclaimed unclamped unclasp uncle unclip uncloak unclog unclothed uncoated uncoiled uncolored uncombed uncommon uncooked uncork uncorrupt uncounted uncouple uncouth uncover uncross uncrown uncrushed uncured uncurious uncurled uncut undamaged undated undaunted undead undecided undefined underage underarm undercoat undercook undercut underdog underdone underfed underfeed underfoot undergo undergrad underhand underline underling undermine undermost underpaid underpass underpay underrate undertake undertone undertook undertow underuse underwear underwent underwire undesired undiluted undivided undocked undoing undone undrafted undress undrilled undusted undying unearned unearth unease uneasily uneasy uneatable uneaten unedited unelected unending unengaged unenvied unequal unethical uneven unexpired unexposed unfailing unfair unfasten unfazed unfeeling unfiled unfilled unfitted unfitting unfixable unfixed unflawed unfocused unfold unfounded unframed unfreeze unfrosted unfrozen unfunded unglazed ungloved unglue ungodly ungraded ungreased unguarded unguided unhappily unhappy unharmed unhealthy unheard unhearing unheated unhelpful unhidden unhinge unhitched unholy unhook unicorn unicycle unified unifier uniformed uniformly unify unimpeded uninjured uninstall uninsured uninvited union uniquely unisexual unison unissued unit universal universe unjustly unkempt unkind unknotted unknowing unknown unlaced unlatch unlawful unleaded unlearned unleash unless unleveled unlighted unlikable unlimited unlined unlinked unlisted unlit unlivable unloaded unloader unlocked unlocking unlovable unloved unlovely unloving unluckily unlucky unmade unmanaged unmanned unmapped unmarked unmasked unmasking unmatched unmindful unmixable unmixed unmolded unmoral unmovable unmoved unmoving unnamable unnamed unnatural unneeded unnerve unnerving unnoticed unopened unopposed unpack unpadded unpaid unpainted unpaired unpaved unpeeled unpicked unpiloted unpinned unplanned unplanted unpleased unpledged unplowed unplug unpopular unproven unquote unranked unrated unraveled unreached unread unreal unreeling unrefined unrelated unrented unrest unretired unrevised unrigged unripe unrivaled unroasted unrobed unroll unruffled unruly unrushed unsaddle unsafe unsaid unsalted unsaved unsavory unscathed unscented unscrew unsealed unseated unsecured unseeing unseemly unseen unselect unselfish unsent unsettled unshackle unshaken unshaved unshaven unsheathe unshipped unsightly unsigned unskilled unsliced unsmooth unsnap unsocial unsoiled unsold unsolved unsorted unspoiled unspoken unstable unstaffed unstamped unsteady unsterile unstirred unstitch unstopped unstuck unstuffed unstylish unsubtle unsubtly unsuited unsure unsworn untagged untainted untaken untamed untangled untapped untaxed unthawed unthread untidy untie until untimed untimely untitled untoasted untold untouched untracked untrained untreated untried untrimmed untrue untruth unturned untwist untying unusable unused unusual unvalued unvaried unvarying unveiled unveiling unvented unviable unvisited unvocal unwanted unwarlike unwary unwashed unwatched unweave unwed unwelcome unwell unwieldy unwilling unwind unwired unwitting unwomanly unworldly unworn unworried unworthy unwound unwoven unwrapped unwritten unzip upbeat upchuck upcoming upcountry update upfront upgrade upheaval upheld uphill uphold uplifted uplifting upload upon upper upright uprising upriver uproar uproot upscale upside upstage upstairs upstart upstate upstream upstroke upswing uptake uptight uptown upturned upward upwind uranium urban urchin urethane urgency urgent urging urologist urology usable usage useable used uselessly user usher usual utensil utility utilize utmost utopia utter vacancy vacant vacate vacation vagabond vagrancy vagrantly vaguely vagueness valiant valid valium valley valuables value vanilla vanish vanity vanquish vantage vaporizer variable variably varied variety various varmint varnish varsity varying vascular vaseline vastly vastness veal vegan veggie vehicular velcro velocity velvet vendetta vending vendor veneering vengeful venomous ventricle venture venue venus verbalize verbally verbose verdict verify verse version versus vertebrae vertical vertigo very vessel vest veteran veto vexingly viability viable vibes vice vicinity victory video viewable viewer viewing viewless viewpoint vigorous village villain vindicate vineyard vintage violate violation violator violet violin viper viral virtual virtuous virus visa viscosity viscous viselike visible visibly vision visiting visitor visor vista vitality vitalize vitally vitamins vivacious vividly vividness vixen vocalist vocalize vocally vocation voice voicing void volatile volley voltage volumes voter voting voucher vowed vowel voyage wackiness wad wafer waffle waged wager wages waggle wagon wake waking walk walmart walnut walrus waltz wand wannabe wanted wanting wasabi washable washbasin washboard washbowl washcloth washday washed washer washhouse washing washout washroom washstand washtub wasp wasting watch water waviness waving wavy whacking whacky wham wharf wheat whenever whiff whimsical whinny whiny whisking whoever whole whomever whoopee whooping whoops why wick widely widen widget widow width wieldable wielder wife wifi wikipedia wildcard wildcat wilder wildfire wildfowl wildland wildlife wildly wildness willed willfully willing willow willpower wilt wimp wince wincing wind wing winking winner winnings winter wipe wired wireless wiring wiry wisdom wise wish wisplike wispy wistful wizard wobble wobbling wobbly wok wolf wolverine womanhood womankind womanless womanlike womanly womb woof wooing wool woozy word work worried worrier worrisome worry worsening worshiper worst wound woven wow wrangle wrath wreath wreckage wrecker wrecking wrench wriggle wriggly wrinkle wrinkly wrist writing written wrongdoer wronged wrongful wrongly wrongness wrought xbox xerox yahoo yam yanking yapping yard yarn yeah yearbook yearling yearly yearning yeast yelling yelp yen yesterday yiddish yield yin yippee yo-yo yodel yoga yogurt yonder yoyo yummy zap zealous zebra zen zeppelin zero zestfully zesty zigzagged zipfile zipping zippy zips zit zodiac zombie zone zoning zookeeper zoologist zoology zoom".split(" ");
var COMMON_PW = "password\n123456\n12345678\n1234\nqwerty\n12345\ndragon\npussy\nbaseball\nfootball\nletmein\nmonkey\n696969\nabc123\nmustang\nmichael\nshadow\nmaster\njennifer\n111111\n2000\njordan\nsuperman\nharley\n1234567\nfuckme\nhunter\nfuckyou\ntrustno1\nranger\nbuster\nthomas\ntigger\nrobert\nsoccer\nfuck\nbatman\ntest\npass\nkiller\nhockey\ngeorge\ncharlie\nandrew\nmichelle\nlove\nsunshine\njessica\nasshole\n6969\npepper\ndaniel\naccess\n123456789\n654321\njoshua\nmaggie\nstarwars\nsilver\nwilliam\ndallas\nyankees\n123123\nashley\n666666\nhello\namanda\norange\nbiteme\nfreedom\ncomputer\nsexy\nthunder\nnicole\nginger\nheather\nhammer\nsummer\ncorvette\ntaylor\nfucker\naustin\n1111\nmerlin\nmatthew\n121212\ngolfer\ncheese\nprincess\nmartin\nchelsea\npatrick\nrichard\ndiamond\nyellow\nbigdog\nsecret\nasdfgh\nsparky\ncowboy\ncamaro\nanthony\nmatrix\nfalcon\niloveyou\nbailey\nguitar\njackson\npurple\nscooter\nphoenix\naaaaaa\nmorgan\ntigers\nporsche\nmickey\nmaverick\ncookie\nnascar\npeanut\njustin\n131313\nmoney\nhorny\nsamantha\npanties\nsteelers\njoseph\nsnoopy\nboomer\nwhatever\niceman\nsmokey\ngateway\ndakota\ncowboys\neagles\nchicken\ndick\nblack\nzxcvbn\nplease\nandrea\nferrari\nknight\nhardcore\nmelissa\ncompaq\ncoffee\nbooboo\nbitch\njohnny\nbulldog\nxxxxxx\nwelcome\njames\nplayer\nncc1701\nwizard\nscooby\ncharles\njunior\ninternet\nbigdick\nmike\nbrandy\ntennis\nblowjob\nbanana\nmonster\nspider\nlakers\nmiller\nrabbit\nenter\nmercedes\nbrandon\nsteven\nfender\njohn\nyamaha\ndiablo\nchris\nboston\ntiger\nmarine\nchicago\nrangers\ngandalf\nwinter\nbigtits\nbarney\nedward\nraiders\nporn\nbadboy\nblowme\nspanky\nbigdaddy\njohnson\nchester\nlondon\nmidnight\nblue\nfishing\n000000\nhannah\nslayer\n11111111\nrachel\nsexsex\nredsox\nthx1138\nasdf\nmarlboro\npanther\nzxcvbnm\narsenal\noliver\nqazwsx\nmother\nvictoria\n7777777\njasper\nangel\ndavid\nwinner\ncrystal\ngolden\nbutthead\nviking\njack\niwantu\nshannon\nmurphy\nangels\nprince\ncameron\ngirls\nmadison\nwilson\ncarlos\nhooters\nwillie\nstartrek\ncaptain\nmaddog\njasmine\nbutter\nbooger\nangela\ngolf\nlauren\nrocket\ntiffany\ntheman\ndennis\nliverpoo\nflower\nforever\ngreen\njackie\nmuffin\nturtle\nsophie\ndanielle\nredskins\ntoyota\njason\nsierra\nwinston\ndebbie\ngiants\npackers\nnewyork\njeremy\ncasper\nbubba\n112233\nsandra\nlovers\nmountain\nunited\ncooper\ndriver\ntucker\nhelpme\nfucking\npookie\nlucky\nmaxwell\n8675309\nbear\nsuckit\ngators\n5150\n222222\nshithead\nfuckoff\njaguar\nmonica\nfred\nhappy\nhotdog\ntits\ngemini\nlover\nxxxxxxxx\n777777\ncanada\nnathan\nvictor\nflorida\n88888888\nnicholas\nrosebud\nmetallic\ndoctor\ntrouble\nsuccess\nstupid\ntomcat\nwarrior\npeaches\napples\nfish\nqwertyui\nmagic\nbuddy\ndolphins\nrainbow\ngunner\n987654\nfreddy\nalexis\nbraves\ncock\n2112\n1212\ncocacola\nxavier\ndolphin\ntesting\nbond007\nmember\ncalvin\nvoodoo\n7777\nsamson\nalex\napollo\nfire\ntester\nwalter\nbeavis\nvoyager\npeter\nporno\nbonnie\nrush2112\nbeer\napple\nscorpio\njonathan\nskippy\nsydney\nscott\nred123\npower\ngordon\ntravis\nbeaver\nstar\njackass\nflyers\nboobs\n232323\nzzzzzz\nsteve\nrebecca\nscorpion\ndoggie\nlegend\nou812\nyankee\nblazer\nbill\nrunner\nbirdie\nbitches\n555555\nparker\ntopgun\nasdfasdf\nheaven\nviper\nanimal\n2222\nbigboy\n4444\narthur\nbaby\nprivate\ngodzilla\ndonald\nwilliams\nlifehack\nphantom\ndave\nrock\naugust\nsammy\ncool\nbrian\nplatinum\njake\nbronco\npaul\nmark\nfrank\nheka6w2\ncopper\nbilly\ncumshot\ngarfield\nwillow\ncunt\nlittle\ncarter\nslut\nalbert\n69696969\nkitten\nsuper\njordan23\neagle1\nshelby\namerica\n11111\njessie\nhouse\nfree\n123321\nchevy\nbullshit\nwhite\nbroncos\nhorney\nsurfer\nnissan\n999999\nsaturn\nairborne\nelephant\nmarvin\nshit\naction\nadidas\nqwert\nkevin\n1313\nexplorer\nwalker\npolice\nchristin\ndecember\nbenjamin\nwolf\nsweet\ntherock\nking\nonline\ndickhead\nbrooklyn\nteresa\ncricket\nsharon\ndexter\nracing\npenis\ngregory\n0000\nteens\nredwings\ndreams\nmichigan\nhentai\nmagnum\n87654321\nnothing\ndonkey\ntrinity\ndigital\n333333\nstella\ncartman\nguinness\n123abc\nspeedy\nbuffalo\nkitty\npimpin\neagle\neinstein\nkelly\nnelson\nnirvana\nvampire\nxxxx\nplayboy\nlouise\npumpkin\nsnowball\ntest123\ngirl\nsucker\nmexico\nbeatles\nfantasy\nford\ngibson\nceltic\nmarcus\ncherry\ncassie\n888888\nnatasha\nsniper\nchance\ngenesis\nhotrod\nreddog\nalexande\ncollege\njester\npassw0rd\nbigcock\nsmith\nlasvegas\ncarmen\nslipknot\n3333\ndeath\nkimberly\n1q2w3e\neclipse\n1q2w3e4r\nstanley\nsamuel\ndrummer\nhomer\nmontana\nmusic\naaaa\nspencer\njimmy\ncarolina\ncolorado\ncreative\nhello1\nrocky\ngoober\nfriday\nbollocks\nscotty\nabcdef\nbubbles\nhawaii\nfluffy\nmine\nstephen\nhorses\nthumper\n5555\npussies\ndarkness\nasdfghjk\npamela\nboobies\nbuddha\nvanessa\nsandman\nnaughty\ndouglas\nhonda\nmatt\nazerty\n6666\nshorty\nmoney1\nbeach\nloveme\n4321\nsimple\npoohbear\n444444\nbadass\ndestiny\nsarah\ndenise\nvikings\nlizard\nmelanie\nassman\nsabrina\nnintendo\nwater\ngood\nhoward\ntime\n123qwe\nnovember\nxxxxx\noctober\nleather\nbastard\nyoung\n101010\nextreme\nhard\npassword1\nvincent\npussy1\nlacrosse\nhotmail\nspooky\namateur\nalaska\nbadger\nparadise\nmaryjane\npoop\ncrazy\nmozart\nvideo\nrussell\nvagina\nspitfire\nanderson\nnorman\neric\ncherokee\ncougar\nbarbara\nlong\n420420\nfamily\nhorse\nenigma\nallison\nraider\nbrazil\nblonde\njones\n55555\ndude\ndrowssap\njeff\nschool\nmarshall\nlovely\n1qaz2wsx\njeffrey\ncaroline\nfranklin\nbooty\nmolly\nsnickers\nleslie\nnipples\ncourtney\ndiesel\nrocks\neminem\nwestside\nsuzuki\ndaddy\npassion\nhummer\nladies\nzachary\nfrankie\nelvis\nreggie\nalpha\nsuckme\nsimpson\npatricia\n147147\npirate\ntommy\nsemperfi\njupiter\nredrum\nfreeuser\nwanker\nstinky\nducati\nparis\nnatalie\nbabygirl\nbishop\nwindows\nspirit\npantera\nmonday\npatches\nbrutus\nhouston\nsmooth\npenguin\nmarley\nforest\ncream\n212121\nflash\nmaximus\nnipple\nbobby\nbradley\nvision\npokemon\nchampion\nfireman\nindian\nsoftball\npicard\nsystem\nclinton\ncobra\nenjoy\nlucky1\nclaire\nclaudia\nboogie\ntimothy\nmarines\nsecurity\ndirty\nadmin\nwildcats\npimp\ndancer\nhardon\nveronica\nfucked\nabcd1234\nabcdefg\nironman\nwolverin\nremember\ngreat\nfreepass\nbigred\nsquirt\njustice\nfrancis\nhobbes\nkermit\npearljam\nmercury\ndomino\n9999\ndenver\nbrooke\nrascal\nhitman\nmistress\nsimon\ntony\nbbbbbb\nfriend\npeekaboo\nnaked\nbudlight\nelectric\nsluts\nstargate\nsaints\nbondage\nbrittany\nbigman\nzombie\nswimming\nduke\nqwerty1\nbabes\nscotland\ndisney\nrooster\nbrenda\nmookie\nswordfis\ncandy\nduncan\nolivia\nhunting\nblink182\nalicia\n8888\nsamsung\nbubba1\nwhore\nvirginia\ngeneral\npassport\naaaaaaaa\nerotic\nliberty\narizona\njesus\nabcd\nnewport\nskipper\nrolltide\nballs\nhappy1\ngalore\nchrist\nweasel\n242424\nwombat\ndigger\nclassic\nbulldogs\npoopoo\naccord\npopcorn\nturkey\njenny\namber\nbunny\nmouse\n007007\ntitanic\nliverpool\ndreamer\neverton\nfriends\nchevelle\ncarrie\ngabriel\npsycho\nnemesis\nburton\npontiac\nconnor\neatme\nlickme\nroland\ncumming\nmitchell\nireland\nlincoln\narnold\nspiderma\npatriots\ngoblue\ndevils\neugene\nempire\nasdfg\ncardinal\nbrown\nshaggy\nfroggy\nqwer\nkawasaki\nkodiak\npeople\nphpbb\nlight\n54321\nkramer\nchopper\nhooker\nhoney\nwhynot\nlesbian\nlisa\nbaxter\nadam\nsnake\nteen\nncc1701d\nqqqqqq\nairplane\nbritney\navalon\nsandy\nsugar\nsublime\nstewart\nwildcat\nraven\nscarface\nelizabet\n123654\ntrucks\nwolfpack\npervert\nlawrence\nraymond\nredhead\namerican\nalyssa\nbambam\nmovie\nwoody\nshaved\nsnowman\ntiger1\nchicks\nraptor\n1969\nstingray\nshooter\nfrance\nstars\nmadmax\nkristen\nsports\njerry\n789456\ngarcia\nsimpsons\nlights\nryan\nlooking\nchronic\nalison\nhahaha\npackard\nhendrix\nperfect\nservice\nspring\nsrinivas\nspike\nkatie\n252525\noscar\nbrother\nbigmac\nsuck\nsingle\ncannon\ngeorgia\npopeye\ntattoo\ntexas\nparty\nbullet\ntaurus\nsailor\nwolves\npanthers\njapan\nstrike\nflowers\npussycat\nchris1\nloverboy\nberlin\nsticky\nmarina\ntarheels\nfisher\nrussia\nconnie\nwolfgang\ntesttest\nmature\nbass\ncatch22\njuice\nmichael1\nnigger\n159753\nwomen\nalpha1\ntrooper\nhawkeye\nhead\nfreaky\ndodgers\npakistan\nmachine\npyramid\nvegeta\nkatana\nmoose\ntinker\ncoyote\ninfinity\ninside\npepsi\nletmein1\nbang\ncontrol\nhercules\nmorris\njames1\ntickle\noutlaw\nbrowns\nbillybob\npickle\ntest1\nmichele\nantonio\nsucks\npavilion\nchangeme\ncaesar\nprelude\ntanner\nadrian\ndarkside\nbowling\nwutang\nsunset\nrobbie\nalabama\ndanger\nzeppelin\njuan\nrusty\npppppp\nnick\n2001\nping\ndarkstar\nmadonna\nqwe123\nbigone\ncasino\ncheryl\ncharlie1\nmmmmmm\nintegra\nwrangler\napache\ntweety\nqwerty12\nbobafett\nsimone\nnone\nbusiness\nsterling\ntrevor\ntransam\ndustin\nharvey\nengland\n2323\nseattle\nssssss\nrose\nharry\nopenup\npandora\npussys\ntrucker\nwallace\nindigo\nstorm\nmalibu\nweed\nreview\nbabydoll\ndoggy\ndilbert\npegasus\njoker\ncatfish\nflipper\nvalerie\nherman\nfuckit\ndetroit\nkenneth\ncheyenne\nbruins\nstacey\nsmoke\njoey\nseven\nmarino\nfetish\nxfiles\nwonder\nstinger\npizza\nbabe\npretty\nstealth\nmanutd\ngracie\ngundam\ncessna\nlonghorn\npresario\nmnbvcxz\nwicked\nmustang1\nvictory\n21122112\nshelly\nawesome\nathena\nq1w2e3r4\nhelp\nholiday\nknicks\nstreet\nredneck\n12341234\ncasey\ngizmo\nscully\ndragon1\ndevildog\ntriumph\neddie\nbluebird\nshotgun\npeewee\nronnie\nangel1\ndaisy\nspecial\nmetallica\nmadman\ncountry\nimpala\nlennon\nroscoe\nomega\naccess14\nenterpri\nmiranda\nsearch\nsmitty\nblizzard\nunicorn\ntight\nrick\nronald\nasdf1234\nharrison\ntrigger\ntruck\ndanny\nhome\nwinnie\nbeauty\nthailand\n1234567890\ncadillac\ncastle\ntyler\nbobcat\nbuddy1\nsunny\nstones\nasian\nfreddie\nchuck\nbutt\nloveyou\nnorton\nhellfire\nhotsex\nindiana\nshort\npanzer\nlonewolf\ntrumpet\ncolors\nblaster\n12121212\nfireball\nlogan\nprecious\naaron\nelaine\njungle\natlanta\ngold\ncorona\ncurtis\nnikki\npolaris\ntimber\ntheone\nballer\nchipper\norlando\nisland\nskyline\ndragons\ndogs\nbenson\nlicker\ngoldie\nengineer\nkong\npencil\nbasketba\nopen\nhornet\nworld\nlinda\nbarbie\nchan\nfarmer\nvalentin\nwetpussy\nindians\nlarry\nredman\nfoobar\ntravel\nmorpheus\nbernie\ntarget\n141414\nhotstuff\nphotos\nlaura\nsavage\nholly\nrocky1\nfuck_inside\ndollar\nturbo\ndesign\nnewton\nhottie\nmoon\n202020\nblondes\n4128\nlestat\navatar\nfuture\ngoforit\nrandom\nabgrtyu\njjjjjj\ncancer\nq1w2e3\nsmiley\ngoldberg\nexpress\nvirgin\nzipper\nwrinkle1\nstone\nandy\nbabylon\ndong\npowers\nconsumer\ndudley\nmonkey1\nserenity\nsamurai\n99999999\nbigboobs\nskeeter\nlindsay\njoejoe\nmaster1\naaaaa\nchocolat\nchristia\nbirthday\nstephani\ntang\n1234qwer\nalfred\nball\n98765432\nmaria\nsexual\nmaxima\n77777777\nsampson\nbuckeye\nhighland\nkristin\nseminole\nreaper\nbassman\nnugget\nlucifer\nairforce\nnasty\nwatson\nwarlock\n2121\nphilip\nalways\ndodge\nchrissy\nburger\nbird\nsnatch\nmissy\npink\ngang\nmaddie\nholmes\nhuskers\npiglet\nphoto\njoanne\nhamilton\ndodger\npaladin\nchristy\nchubby\nbuckeyes\nhamlet\nabcdefgh\nbigfoot\nsunday\nmanson\ngoldfish\ngarden\ndeftones\nicecream\nblondie\nspartan\njulie\nharold\ncharger\nbrandi\nstormy\nsherry\npleasure\njuventus\nrodney\ngalaxy\nholland\nescort\nzxcvb\nplanet\njerome\nwesley\nblues\nsong\npeace\ndavid1\nncc1701e\n1966\n51505150\ncavalier\ngambit\nkaren\nsidney\nripper\noicu812\njamie\nsister\nmarie\nmartha\nnylons\naardvark\nnadine\nminnie\nwhiskey\nbing\nplastic\nanal\nbabylon5\nchang\nsavannah\nloser\nracecar\ninsane\nyankees1\nmememe\nhansolo\nchiefs\nfredfred\nfreak\nfrog\nsalmon\nconcrete\nyvonne\nzxcv\nshamrock\natlantis\nwarren\nwordpass\njulian\nmariah\nrommel\n1010\nharris\npredator\nsylvia\nmassive\ncats\nsammy1\nmister\nstud\nmarathon\nrubber\nding\ntrunks\ndesire\nmontreal\njustme\nfaster\nkathleen\nirish\n1999\nbertha\njessica1\nalpine\nsammie\ndiamonds\ntristan\n00000\nswinger\nshan\nstallion\npitbull\nletmein2\nroberto\nready\napril\npalmer\nming\nshadow1\naudrey\nchong\nclitoris\nwang\nshirley\nfuckers\njackoff\nbluesky\nsundance\nrenegade\nhollywoo\n151515\nbernard\nwolfman\nsoldier\npicture\npierre\nling\ngoddess\nmanager\nnikita\nsweety\ntitans\nhang\nfang\nficken\nniners\nbottom\nbubble\nhello123\nibanez\nwebster\nsweetpea\nstocking\n323232\ntornado\nlindsey\ncontent\nbruce\nbuck\naragorn\ngriffin\nchen\ncampbell\ntrojan\nchristop\nnewman\nwayne\ntina\nrockstar\nfather\ngeronimo\npascal\ncrimson\nbrooks\nhector\npenny\nanna\ngoogle\ncamera\nchandler\nfatcat\nlovelove\ncody\ncunts\nwaters\nstimpy\nfinger\ncindy\nwheels\nviper1\nlatin\nrobin\ngreenday\n987654321\ncreampie\nbrendan\nhiphop\nwilly\nsnapper\nfuntime\nduck\ntrombone\nadult\ncotton\ncookies\nkaiser\nmulder\nwestham\nlatino\njeep\nravens\naurora\ndrizzt\nmadness\nenergy\nkinky\n314159\nsophia\nstefan\nslick\nrocker\n55555555\nfreeman\nfrench\nmongoose\nspeed\ndddddd\nhong\nhenry\nhungry\nyang\ncatdog\ncheng\nghost\ngogogo\nrandy\ntottenha\ncurious\nbutterfl\nmission\njanuary\nsinger\nsherman\nshark\ntechno\nlancer\nlalala\nautumn\nchichi\norion\ntrixie\nclifford\ndelta\nbobbob\nbomber\nholden\nkang\nkiss\n1968\nspunky\nliquid\nmary\nbeagle\ngranny\nnetwork\nbond\nkkkkkk\nmillie\n1973\nbiggie\nbeetle\nteacher\nsusan\ntoronto\nanakin\ngenius\ndream\ncocks\ndang\nbush\nkarate\nsnakes\nbangkok\ncallie\nfuckyou2\npacific\ndaytona\nkelsey\ninfantry\nskywalke\nfoster\nfelix\nsailing\nraistlin\nvanhalen\nhuang\nherbert\njacob\nblackie\ntarzan\nstrider\nsherlock\nlang\ngong\nsang\ndietcoke\nultimate\ntree\nshai\nsprite\nting\nartist\nchai\nchao\ndevil\npython\nninja\nmisty\nytrewq\nsweetie\nsuperfly\n456789\ntian\njing\njesus1\nfreedom1\ndian\ndrpepper\npotter\nchou\ndarren\nhobbit\nviolet\nyong\nshen\nphillip\nmaurice\ngloria\nnolimit\nmylove\nbiscuit\nyahoo\nshasta\nsex4me\nsmoker\nsmile\npebbles\npics\nphilly\ntong\ntintin\nlesbians\nmarlin\ncactus\nfrank1\ntttttt\nchun\ndanni\nemerald\nshowme\npirates\nlian\ndogg\ncolleen\nxiao\nxian\ntazman\ntanker\npatton\ntoshiba\nrichie\nalberto\ngotcha\ngraham\ndillon\nrang\nemily\nkeng\njazz\nbigguy\nyuan\nwoman\ntomtom\nmarion\ngreg\nchaos\nfossil\nflight\nracerx\ntuan\ncreamy\nboss\nbobo\nmusicman\nwarcraft\nwindow\nblade\nshuang\nsheila\nshun\nlick\njian\nmicrosoft\nrong\nallen\nfeng\ngetsome\nsally\nquality\nkennedy\nmorrison\n1977\nbeng\nwwwwww\nyoyoyo\nzhang\nseng\nteddy\njoanna\nandreas\nharder\nluke\nqazxsw\nqian\ncong\nchuan\ndeng\nnang\nboeing\nkeeper\nwestern\nisabelle\n1963\nsubaru\nsheng\nthuglife\nteng\njiong\nmiao\nmartina\nmang\nmaniac\npussie\ntracey\na1b2c3\nclayton\nzhou\nzhuang\nxing\nstonecol\nsnow\nspyder\nliang\njiang\nmemphis\nregina\nceng\nmagic1\nlogitech\nchuang\ndark\nmillion\nblow\nsesame\nshao\npoison\ntitty\nterry\nkuan\nkuai\nkyle\nmian\nguan\nhamster\nguai\nferret\nflorence\ngeng\nduan\npang\nmaiden\nquan\nvelvet\nnong\nneng\nnookie\nbuttons\nbian\nbingo\nbiao\nzhong\nzeng\nxiong\nzhun\nying\nzong\nxuan\nzang\n0.0.000\nsuan\nshei\nshui\nsharks\nshang\nshua\nsmall\npeng\npian\npiao\nliao\nmeng\nmiami\nreng\nguang\ncang\nchange\nruan\ndiao\nluan\nlucas\nqing\nchui\nchuo\ncuan\nnuan\nning\nheng\nhuan\nkansas\nmuscle\nmonroe\nweng\nwhitney\n1passwor\nbluemoon\nzhui\nzhua\nxiang\nzheng\nzhen\nzhei\nzhao\nzhan\nyomama\nzhai\nzhuo\nzuan\ntarheel\nshou\nshuo\ntiao\nlady\nleonard\nleng\nkuang\njiao\n13579\nbasket\nqiao\nqiong\nqiang\nchuai\nnian\nniao\nniang\nhuai\n22222222\nbianca\nzhuan\nzhuai\nshuan\nshuai\nstardust\njumper\nmargaret\narchie\n66666666\n66668888\ncharlott\nforget\nqwertz\nbones\nhistory\nmilton\nwaterloo\n2002\nstuff\n11223344\noffice\noldman\npreston\ntrains\nmurray\nvertigo\n246810\nblack1\nswallow\nsmiles\nstandard\nalexandr\nparrot\nluther\nuser\nnicolas\n1976\nsurfing\npioneer\npete\nmasters\napple1\nasdasd\nauburn\nhannibal\nfrontier\npanama\nlucy\nbuffy\nbrianna\nwelcome1\nvette\nblue22\nshemale\n111222\nbaggins\ngroovy\nglobal\nturner\n181818\n1979\nblades\nspanking\nlife\nbyteme\nlobster\ncollins\ndawg\nhilton\njapanese\n1970\n1964\n2424\npolo\nmarkus\ncoco\ndeedee\nmikey\n1972\n171717\n1701\nstrip\njersey\ngreen1\ncapital\nsasha\nsadie\nputter\nvader\nseven7\nlester\nmarcel\nbanshee\ngrendel\ngilbert\ndicks\ndead\nhidden\niloveu\n1980\nsound\nledzep\nmichel\n147258\nfemale\nbugger\nbuffett\nbryan\nhell\nkristina\nmolson\n2020\nwookie\nsprint\nthanks\njericho\n102030\ngrace\nfuckin\nmandy\nranger1\ntrebor\ndeepthroat\nbonehead\nmolly1\nmirage\nmodels\n1984\n2468\nstuart\nshowtime\nsquirrel\npentium\nmario\nanime\ngator\npowder\ntwister\nconnect\nneptune\nbruno\nbutts\nengine\neatshit\nmustangs\nwoody1\nshogun\nseptembe\npooh\njimbo\nroger\nannie\nbacon\ncenter\nrussian\nsabine\ndamien\nmollie\nvoyeur\n2525\n363636\nleonardo\ncamel\nchair\ngermany\ngiant\nqqqq\nnudist\nbone\nsleepy\ntequila\nmegan\nfighter\ngarrett\ndominic\nobiwan\nmakaveli\nvacation\nwalnut\n1974\nladybug\ncantona\nccbill\nsatan\nrusty1\npasswor1\ncolumbia\nnapoleon\ndusty\nkissme\nmotorola\nwilliam1\n1967\nzzzz\nskater\nsmut\nplay\nmatthew1\nrobinson\nvalley\ncoolio\ndagger\nboner\nbull\nhorndog\njason1\nblake\npenguins\nrescue\ngriffey\n8j4ye3uz\ncaliforn\nchamps\nqwertyuiop\nportland\nqueen\ncolt45\nboat\nxxxxxxx\nxanadu\ntacoma\nmason\ncarpet\ngggggg\nsafety\npalace\nitalia\nstevie\npicturs\npicasso\nthongs\ntempest\nricardo\nroberts\nasd123\nhairy\nfoxtrot\ngary\nnimrod\nhotboy\n343434\n1111111\nasdfghjkl\ngoose\noverlord\nblood\nwood\nstranger\n454545\nshaolin\nsooners\nsocrates\nspiderman\npeanuts\nmaxine\nrogers\n13131313\nandrew1\nfilthy\ndonnie\nohyeah\nafrica\nnational\nkenny\nkeith\nmonique\nintrepid\njasmin\npickles\nassass\nfright\npotato\ndarwin\nhhhhhh\nkingdom\nweezer\n424242\npepsi1\nthroat\nromeo\ngerard\nlooker\npuppy\nbutch\nmonika\nsuzanne\nsweets\ntemple\nlaurie\njosh\nmegadeth\nanalsex\nnymets\nddddddd\nbigballs\nsupport\nstick\ntoday\ndown\noakland\noooooo\nqweasd\nchucky\nbridge\ncarrot\nchargers\ndiscover\ndookie\ncondor\nnight\nbutler\nhoover\nhorny1\nisabella\nsunrise\nsinner\njojo\nmegapass\nmartini\nassfuck\ngrateful\nffffff\nabigail\nesther\nmushroom\njanice\njamaica\nwright\nsims\nspace\nthere\ntimmy\n7654321\n77777\ncccccc\ngizmodo\nroxanne\nralph\ntractor\ncristina\ndance\nmypass\nhongkong\nhelena\n1975\nblue123\npissing\nthomas1\nredred\nrich\nbasketball\nattack\ncash\nsatan666\ndrunk\ndixie\ndublin\nbollox\nkingkong\nkatrina\nmiles\n1971\n22222\n272727\nsexx\npenelope\nthompson\nanything\nbbbb\nbattle\ngrizzly\npassat\nporter\ntracy\ndefiant\nbowler\nknickers\nmonitor\nwisdom\nwild\nslappy\nthor\nletsgo\nrobert1\nfeet\nrush\nbrownie\nhudson\n098765\nplaying\nplaytime\nlightnin\nmelvin\natomic\nbart\nhawk\ngoku\nglory\nllllll\nqwaszx\ncosmos\nbosco\nknights\nbentley\nbeast\nslapshot\nlewis\nassword\nfrosty\ngillian\nsara\ndumbass\nmallard\ndddd\ndeanna\nelwood\nwally\n159357\ntitleist\nangelo\naussie\nguest\ngolfing\ndoobie\nloveit\nchloe\nelliott\nwerewolf\nvipers\njanine\n1965\nblabla\nsurf\nsucking\ntardis\nserena\nshelley\nthegame\nlegion\nrebels\nfernando\nfast\ngerald\nsarah1\ndouble\nonelove\nloulou\ntoto\ncrash\nblackcat\n0007\ntacobell\nsoccer1\njedi\nmanuel\nmethod\nriver\nchase\nludwig\npoopie\nderrick\nboob\nbreast\nkittycat\nisabel\nbelly\npikachu\nthunder1\nthankyou\njose\nceleste\nceltics\nfrances\nfrogger\nscoobydo\nsabbath\ncoltrane\nbudman\nwillis\njackal\nbigger\nzzzzz\nsilvia\nsooner\nlicking\ngopher\ngeheim\nlonestar\nprimus\npooper\nnewpass\nbrasil\nheather1\nhusker\nelement\nmoomoo\nbeefcake\nzzzzzzzz\ntammy\nshitty\nsmokin\npersonal\njjjj\nanthony1\nanubis\nbackup\ngorilla\nfuckface\npainter\nlowrider\npunkrock\ntraffic\nclaude\ndaniela\ndale\ndelta1\nnancy\nboys\neasy\nkissing\nkelley\nwendy\ntheresa\namazon\nalan\nfatass\ndodgeram\ndingdong\nmalcolm\nqqqqqqqq\nbreasts\nboots\nhonda1\nspidey\npoker\ntemp\njohnjohn\nmiguel\n147852\narcher\nasshole1\ndogdog\ntricky\ncrusader\nweather\nsyracuse\nspankme\nspeaker\nmeridian\namadeus\nback\nharley1\nfalcons\ndorothy\nturkey50\nkenwood\nkeyboard\nilovesex\n1978\nblackman\nshazam\nshalom\nlickit\njimbob\nrichmond\nroller\ncarson\ncheck\nfatman\nfunny\ngarbage\nsandiego\nloving\nmagnus\ncooldude\nclover\nmobile\nbell\npayton\nplumber\ntexas1\ntool\ntopper\njenna\nmariners\nrebel\nharmony\ncaliente\ncelica\nfletcher\ngerman\ndiana\noxford\nosiris\norgasm\npunkin\nporsche9\ntuesday\nclose\nbreeze\nbossman\nkangaroo\nbillie\nlatinas\njudith\nastros\nscruffy\ndonna\nqwertyu\ndavis\nhearts\nkathy\njammer\njava\nspringer\nrhonda\nricky\n1122\ngoodtime\nchelsea1\nfreckles\nflyboy\ndoodle\ncity\nnebraska\nbootie\nkicker\nwebmaster\nvulcan\niverson\n191919\nblueeyes\nstoner\n321321\nfarside\nrugby\ndirector\npussy69\npower1\nbobbie\nhershey\nhermes\nmonopoly\nwest\nbirdman\nblessed\nblackjac\nsouthern\npeterpan\nthumbs\nlawyer\nmelinda\nfingers\nfuckyou1\nrrrrrr\na1b2c3d4\ncoke\nnicola\nbohica\nheart\nelvis1\nkids\nblacky\nstories\nsentinel\nsnake1\nphoebe\njesse\nrichard1\n1234abcd\nguardian\ncandyman\nfisting\nscarlet\ndildo\npancho\nmandingo\nlucky7\ncondom\nmunchkin\nbillyboy\nsummer1\nstudent\nsword\nskiing\nsergio\nsite\nsony\nthong\nrootbeer\nassassin\ncassidy\nfrederic\nfffff\nfitness\ngiovanni\nscarlett\ndurango\npostal\nachilles\ndawn\ndylan\nkisses\nwarriors\nimagine\nplymouth\ntopdog\nasterix\nhallo\ncameltoe\nfuckfuck\nbridget\neeeeee\nmouth\nweird\nwill\nsithlord\nsommer\ntoby\ntheking\njuliet\navenger\nbackdoor\ngoodbye\nchevrole\nfaith\nlorraine\ntrance\ncosworth\nbrad\nhouses\nhomers\neternity\nkingpin\nverbatim\nincubus\n1961\nblond\nzaphod\nshiloh\nspurs\nstation\njennie\nmaynard\nmighty\naliens\nhank\ncharly\nrunning\ndogman\nomega1\nprinter\naggies\nchocolate\ndeadhead\nhope\njavier\nbitch1\nstone55\npineappl\nthekid\nlizzie\nrockets\nashton\ncamels\nformula\nforrest\nrosemary\noracle\nrain\npussey\nporkchop\nabcde\nclancy\nnellie\nmystic\ninferno\nblackdog\nsteve1\npauline\nalexander\nalice\nalfa\ngrumpy\nflames\nscream\nlonely\npuffy\nproxy\nvalhalla\nunreal\ncynthia\nherbie\nengage\nyyyyyy\n010101\nsolomon\npistol\nmelody\nceleb\nflying\ngggg\nsantiago\nscottie\noakley\nportugal\na12345\nnewbie\nmmmm\nvenus\n1qazxsw2\nbeverly\nzorro\nwork\nwriter\nstripper\nsebastia\nspread\nphil\ntobias\nlinks\nmembers\nmetal\n1221\nandre\n565656\nfunfun\ntrojans\nagain\ncyber\nhurrican\nmoneys\n1x2zkg8w\nzeus\nthing\ntomato\nlion\natlantic\nceline\nusa123\ntrans\naccount\naaaaaaa\nhomerun\nhyperion\nkevin1\nblacks\n44444444\nskittles\nsean\nhastings\nfart\ngangbang\nfubar\nsailboat\nolder\noilers\ncraig\nconrad\nchurch\ndamian\ndean\nbroken\nbuster1\nhithere\nimmortal\nsticks\npilot\npeters\nlexmark\njerkoff\nmaryland\nanders\ncheers\npossum\ncolumbus\ncutter\nmuppet\nbeautiful\nstolen\nswordfish\nsport\nsonic\npeter1\njethro\nrockon\nasdfghj\npass123\npaper\npornos\nncc1701a\nbootys\nbuttman\nbonjour\nescape\n1960\nbecky\nbears\n362436\nspartans\ntinman\nthreesom\nlemons\nmaxmax\n1414\nbbbbb\ncamelot\nchad\nchewie\ngogo\nfusion\nsaint\ndilligaf\nnopass\nmyself\nhustler\nhunter1\nwhitey\nbeast1\nyesyes\nspank\nsmudge\npinkfloy\npatriot\nlespaul\nannette\nhammers\ncatalina\nfinish\nformula1\nsausage\nscooter1\norioles\noscar1\nover\ncolombia\ncramps\nnatural\neating\nexotic\niguana\nbella\nsuckers\nstrong\nsheena\nstart\nslave\npearl\ntopcat\nlancelot\nangelica\nmagelan\nracer\nramona\ncrunch\nbritish\nbutton\neileen\nsteph\n456123\nskinny\nseeking\nrockhard\nchief\nfilter\nfirst\nfreaks\nsakura\npacman\npoontang\ndalton\nnewlife\nhomer1\nklingon\nwatcher\nwalleye\ntasha\ntasty\nsinatra\nstarship\nsteel\nstarbuck\nponcho\namber1\ngonzo\ngrover\ncatherin\ncarol\ncandle\nfirefly\ngoblin\nscotch\ndiver\nusmc\nhuskies\neleven\nkentucky\nkitkat\nisrael\nbeckham\nbicycle\nyourmom\nstudio\ntara\n33333333\nshane\nsplash\njimmy1\nreality\n12344321\ncaitlin\nfocus\nsapphire\nmailman\nraiders1\nclark\nddddd\nhopper\nexcalibu\nmore\nwilbur\nillini\nimperial\nphillips\nlansing\nmaxx\ngothic\ngolfball\ncarlton\ncamille\nfacial\nfront242\nmacdaddy\nqwer1234\nvectra\ncowboys1\ncrazy1\ndannyboy\njane\nbetty\nbenny\nbennett\nleader\nmartinez\naquarius\nbarkley\nhayden\ncaught\nfranky\nffff\nfloyd\nsassy\npppp\npppppppp\nprodigy\nclarence\nnoodle\neatpussy\nvortex\nwanking\nbeatrice\nbilly1\nsiemens\npedro\nphillies\nresearch\ngroups\ncarolyn\nchevy1\ncccc\nfritz\ngggggggg\ndoughboy\ndracula\nnurses\nloco\nmadrid\nlollipop\ntrout\nutopia\nchrono\ncooler\nconner\nnevada\nwibble\nwerner\nsummit\nmarco\nmarilyn\n1225\nbabies\ncapone\nfugazi\npanda\nmama\nqazwsxed\npuppies\ntriton\n9876\ncommand\nnnnnnn\nernest\nmomoney\niforgot\nwolfie\nstudly\nshawn\nrenee\nalien\nhamburg\n81fukkc\n741852\ncatman\nchina\nforgot\ngagging\nscott1\ndrew\noregon\nqweqwe\ntrain\ncrazybab\ndaniel1\ncutlass\nbrothers\nholes\nheidi\nmothers\nmusic1\nwhat\nwalrus\n1957\nbigtime\nbike\nxtreme\nsimba\nssss\nrookie\nangie\nbathing\nfresh\nsanchez\nrotten\nmaestro\nluis\nlook\nturbo1\n99999\nbutthole\nhhhh\nelijah\nmonty\nbender\nyoda\nshania\nshock\nphish\nthecat\nrightnow\nreagan\nbaddog\nasia\ngreatone\ngateway1\nrandall\nabstr\nnapster\nbrian1\nbogart\nhigh\nhitler\nemma\nkill\nweaver\nwildfire\njackson1\nisaiah\n1981\nbelinda\nbeaner\nyoyo\n0.0.0.000\nsuper1\nselect\nsnuggles\nslutty\nsome\nphoenix1\ntechnics\ntoon\nraven1\nrayray\n123789\n1066\nalbion\ngreens\nfashion\ngesperrt\nsantana\npaint\npowell\ncredit\ndarling\nmystery\nbowser\nbottle\nbrucelee\nhehehe\nkelly1\nmojo\n1998\nbikini\nwoofwoof\nyyyy\nstrap\nsites\nspears\ntheodore\njulius\nrichards\namelia\ncentral\nf**k\nnyjets\npunisher\nusername\nvanilla\ntwisted\nbryant\nbrent\nbunghole\nhere\nelizabeth\nerica\nkimber\nviagra\nveritas\npony\npool\ntitts\nlabtec\nlifetime\njenny1\nmasterbate\nmayhem\nredbull\ngovols\ngremlin\n505050\ngmoney\nrupert\nrovers\ndiamond1\nlorenzo\ntrident\nabnormal\ndavidson\ndeskjet\ncuddles\nnice\nbristol\nkarina\nmilano\nvh5150\njarhead\n1982\nbigbird\nbizkit\nsixers\nslider\nstar69\nstarfish\npenetration\ntommy1\njohn316\nmeghan\nmichaela\nmarket\ngrant\ncaligula\ncarl\nflicks\nfilms\nmadden\nrailroad\ncosmo\ncthulhu\nbradford\nbr0d3r\nmilitary\nbearbear\nswedish\nspawn\npatrick1\npolly\nthese\ntodd\nreds\nanarchy\ngroove\nfranco\nfuckher\noooo\ntyrone\nvegas\nairbus\ncobra1\nchristine\nclips\ndelete\nduster\nkitty1\nmouse1\nmonkeys\njazzman\n1919\n262626\nswinging\nstroke\nstocks\nsting\npippen\nlabrador\njordan1\njustdoit\nmeatball\nfemales\nsaturday\npark\nvector\ncooter\ndefender\ndesert\ndemon\nnike\nbubbas\nbonkers\nenglish\nkahuna\nwildman\n4121\nsirius\nstatic\npiercing\nterror\nteenage\nleelee\nmarissa\nmicrosof\nmechanic\nrobotech\nrated\nhailey\nchaser\nsanders\nsalsero\nnuts\nmacross\nquantum\nrachael\ntsunami\nuniverse\ndaddy1\ncruise\nnguyen\nnewpass6\nnudes\nhellyeah\nvernon\n1959\nzaq12wsx\nstriker\nsixty\nsteele\nspice\nspectrum\nsmegma\nthumb\njjjjjjjj\nmellow\nastrid\ncancun\ncartoon\nsabres\nsamiam\npants\noranges\noklahoma\nlust\ncoleman\ndenali\nnude\nnoodles\nbuzz\nbrest\nhooter\nmmmmmmmm\nwarthog\nbloody\nblueblue\nzappa\nwolverine\nsniffing\nlance\njean\njjjjj\nharper\ncalico\nfreee\nrover\ndoor\npooter\ncloseup\nbonsai\nevelyn\nemily1\nkathryn\nkeystone\niiii\n1955\nyzerman\ntheboss\ntolkien\njill\nmegaman\nrasta\nbbbbbbbb\nbean\nhandsome\nhal9000\ngoofy\ngringo\ngofish\ngizmo1\nsamsam\nscuba\nonlyme\ntttttttt\ncorrado\nclown\nclapton\ndeborah\nboris\nbulls\nvivian\njayhawk\nbethany\nwwww\nsharky\nseeker\nssssssss\nsomethin\npillow\nthesims\nlighter\nlkjhgf\nmelissa1\nmarcius2\nbarry\nguiness\ngymnast\ncasey1\ngoalie\ngodsmack\ndoug\nlolo\nrangers1\npoppy\nabby\nclemson\nclipper\ndeeznuts\nnobody\nholly1\nelliot\neeee\nkingston\nmiriam\nbelle\nyosemite\nsucked\nsex123\nsexy69\npic\\'s\ntommyboy\nlamont\nmeat\nmasterbating\nmarianne\nmarc\ngretzky\nhappyday\nfrisco\nscratch\norchid\norange1\nmanchest\nquincy\nunbelievable\naberdeen\ndawson\nnathalie\nne1469\nboxing\nhill\nkorn\nintercourse\n161616\n1985\nziggy\nsupersta\nstoney\nsenior\namature\nbarber\nbabyboy\nbcfields\ngoliath\nhack\nhardrock\nchildren\nfrodo\nscout\nscrappy\nrosie\nqazqaz\ntracker\nactive\ncraving\ncommando\ncohiba\ndeep\ncyclone\ndana\nbubba69\nkatie1\nmpegs\nvsegda\njade\nirish1\nbetter\nsexy1\nsinclair\nsmelly\nsquerting\nlions\njokers\njeanette\njulia\njojojo\nmeathead\nashley1\ngroucho\ncheetah\nchamp\nfirefox\ngandalf1\npacker\nmagnolia\nlove69\ntyler1\ntyphoon\ntundra\nbobby1\nkenworth\nvillage\nvolley\nbeth\nwolf359\n0420\n000007\nswimmer\nskydive\nsmokes\npatty\npeugeot\npompey\nlegolas\nkristy\nredhot\nrodman\nredalert\nhaving\ngrapes\n4runner\ncarrera\nfloppy\ndollars\nou8122\nquattro\nadams\ncloud9\ndavids\nnofear\nbusty\nhomemade\nmmmmm\nwhisper\nvermont\nwebmaste\nwives\ninsertion\njayjay\nphilips\nphone\ntopher\ntongue\ntemptress\nmidget\nripken\nhavefun\ngretchen\ncanon\ncelebrity\nfive\ngetting\nghetto\ndirect\notto\nragnarok\ntrinidad\nusnavy\nconover\ncruiser\ndalshe\nnicole1\nbuzzard\nhottest\nkingfish\nmisfit\nmoore\nmilfnew\nwarlord\nwassup\nbigsexy\nblackhaw\nzippy\nshearer\ntights\nthursday\nkungfu\nlabia\njourney\nmeatloaf\nmarlene\nrider\narea51\nbatman1\nbananas\n636363\ncancel\nggggg\nparadox\nmack\nlynn\nqueens\nadults\naikido\ncigars\nnova\nhoosier\neeyore\nmoose1\nwarez\ninteracial\nstreaming\n313131\npertinant\npool6123\nmayday\nrivers\nrevenge\nanimated\nbanker\nbaddest\ngordon24\nccccc\nfortune\nfantasies\ntouching\naisan\ndeadman\nhomepage\nejaculation\nwhocares\niscool\njamesbon\n1956\n1pussy\nwomam\nsweden\nskidoo\nspock\nsssss\npetra\npepper1\npinhead\nmicron\nallsop\namsterda\narmy\naside\ngunnar\n666999\nchip\nfoot\nfowler\nfebruary\nface\nfletch\ngeorge1\nsapper\nscience\nsasha1\nluckydog\nlover1\nmagick\npopopo\npublic\nultima\nderek\ncypress\nbooker\nbusinessbabe\nbrandon1\nedwards\nexperience\nvulva\nvvvv\njabroni\nbigbear\nyummy\n010203\nsearay\nsecret1\nshowing\nsinbad\nsexxxx\nsoleil\nsoftware\npiccolo\nthirteen\nleopard\nlegacy\njensen\njustine\nmemorex\nmarisa\nmathew\nredwing\nrasputin\n134679\nanfield\ngreenbay\ngore\ncatcat\nfeather\nscanner\npa55word\ncontortionist\ndanzig\ndaisy1\nhores\nerik\nexodus\nvinnie\niiiiii\nzero\n1001\nsubway\ntank\nsecond\nsnapple\nsneakers\nsonyfuck\npicks\npoodle\ntest1234\ntheir\nllll\njunebug\njune\nmarker\nmellon\nronaldo\nroadkill\namanda1\nasdfjkl\nbeaches\ngreene\ngreat1\ncheerleaers\nforce\ndoitnow\nozzy\nmadeline\nradio\ntyson\nchristian\ndaphne\nboxster\nbrighton\nhousewifes\nemmanuel\nemerson\nkkkk\nmnbvcx\nmoocow\nvides\nwagner\njanet\n1717\nbigmoney\nblonds\n1000\nstorys\nstereo\n4545\n420247\nseductive\nsexygirl\nlesbean\nlive\njustin1\n124578\nanimals\nbalance\nhansen\ncabbage\ncanadian\ngangbanged\ndodge1\ndimas\nlori\nloud\nmalaka\npuss\nprobes\nadriana\ncoolman\ncrawford\ndante\nnacked\nhotpussy\nerotica\nkool\nmirror\nwearing\nimplants\nintruder\nbigass\nzenith\nwoohoo\nwomans\ntanya\ntango\nstacy\npisces\nlaguna\nkrystal\nmaxell\nandyod22\nbarcelon\nchainsaw\nchickens\nflash1\ndowntown\norgasms\nmagicman\nprofit\npusyy\npothead\ncoconut\nchuckie\ncontact\nclevelan\ndesigner\nbuilder\nbudweise\nhotshot\nhorizon\nhole\nexperienced\nmondeo\nwifes\n1962\nstrange\nstumpy\nsmiths\nsparks\nslacker\npiper\npitchers\npasswords\nlaptop\njeremiah\nallmine\nalliance\nbbbbbbb\nasscock\nhalflife\ngrandma\nhayley\n88888\ncecilia\nchacha\nsaratoga\nsandy1\nsantos\ndoogie\nnumber\npositive\nqwert40\ntransexual\ncrow\nclose-up\ndarrell\nbonita\nib6ub9\nvolvo\njacob1\niiiii\nbeastie\nsunnyday\nstoned\nsonics\nstarfire\nsnapon\npictuers\npepe\ntesting1\ntiberius\nlisalisa\nlesbain\nlitle\nretard\nripple\naustin1\nbadgirl\ngolfgolf\nflounder\ngarage\nroyals\ndragoon\ndickie\npasswor\nocean\nmajestic\npoppop\ntrailers\ndammit\nnokia\nbobobo\nbr549\nemmitt\nknock\nminime\nmikemike\nwhitesox\n1954\n3232\n353535\nseamus\nsolo\nsparkle\nsluttey\npictere\ntitten\nlback\n1024\nangelina\ngoodluck\ncharlton\nfingerig\ngallaries\ngoat\nruby\npassme\noasis\nlockerroom\nlogan1\nrainman\ntwins\ntreasure\nabsolutely\nclub\ncustom\ncyclops\nnipper\nbucket\nhomepage-\nhhhhh\nmomsuck\nindain\n2345\nbeerbeer\nbimmer\nsusanne\nstunner\nstevens\n456456\nshell\nsheba\ntootsie\ntiny\ntesterer\nreefer\nreally\n1012\nharcore\ngollum\n545454\nchico\ncaveman\ncarole\nfordf150\nfishes\ngaymen\nsaleen\ndoodoo\npa55w0rd\nlooney\npresto\nqqqqq\ncigar\nbogey\nbrewer\nhelloo\ndutch\nkamikaze\nmonte\nwasser\nvietnam\nvisa\njapanees\n0123\nswords\nslapper\npeach\njump\nmarvel\nmasterbaiting\nmarch\nredwood\nrolling\n1005\nametuer\nchiks\ncathy\ncallaway\nfucing\nsadie1\npanasoni\nmamas\nrace\nrambo\nunknown\nabsolut\ndeacon\ndallas1\nhousewife\nkristi\nkeywest\nkirsten\nkipper\nmorning\nwings\nidiot\n18436572\n1515\nbeating\nzxczxc\nsullivan\n303030\nshaman\nsparrow\nterrapin\njeffery\nmasturbation\nmick\nredfish\n1492\nangus\nbarrett\ngoirish\nhardcock\nfelicia\nforfun\ngalary\nfreeporn\nduchess\nolivier\nlotus\npornographic\nramses\npurdue\ntraveler\ncrave\nbrando\nenter1\nkillme\nmoneyman\nwelder\nwindsor\nwifey\nindon\nyyyyy\nstretch\ntaylor1\n4417\nshopping\npicher\npickup\nthumbnils\njohnboy\njets\njess\nmaureen\nanne\nameteur\namateurs\napollo13\nhambone\ngoldwing\n5050\ncharley\nsally1\ndoghouse\npadres\npounding\nquest\ntruelove\nunderdog\ntrader\ncrack\nclimber\nbolitas\nbravo\nhohoho\nmodel\nitalian\nbeanie\nberetta\nwrestlin\nstroker\ntabitha\nsherwood\nsexyman\njewels\njohannes\nmets\nmarcos\nrhino\nbdsm\nballoons\ngoodman\ngrils\nhappy123\nflamingo\ngames\nroute66\ndevo\ndino\noutkast\npaintbal\nmagpie\nllllllll\ntwilight\ncritter\nchristie\ncupcake\nnickel\nbullseye\nkrista\nknickerless\nmimi\nmurder\nvideoes\nbinladen\nxerxes\nslim\nslinky\npinky\npeterson\nthanatos\nmeister\nmenace\nripley\nretired\nalbatros\nballoon\nbank\ngoten\n5551212\ngetsdown\ndonuts\ndivorce\nnwo4life\nlord\nlost\nunderwear\ntttt\ncomet\ndeer\ndamnit\ndddddddd\ndeeznutz\nnasty1\nnonono\nnina\nenterprise\neeeee\nmisfit99\nmilkman\nvvvvvv\nisaac\n1818\nblueboy\nbeans\nbigbutt\nwyatt\ntech\nsolution\npoetry\ntoolman\nlaurel\njuggalo\njetski\nmeredith\nbarefoot\n50spanks\ngobears\nscandinavian\noriginal\ntruman\ncubbies\nnitram\nbriana\nebony\nkings\nwarner\nbilbo\nyumyum\nzzzzzzz\nstylus\n321654\nshannon1\nserver\nsecure\nsilly\nsquash\nstarman\nsteeler\nstaples\nphrases\ntechniques\nlaser\n135790\nallan\nbarker\nathens\ncbr600\nchemical\nfester\ngangsta\nfucku2\nfreeze\ngame\nsalvador\ndroopy\nobjects\npasswd\nlllll\nloaded\nlouis\nmanchester\nlosers\nvedder\nclit\nchunky\ndarkman\ndamage\nbuckshot\nbuddah\nboobed\nhenti\nhillary\nwebber\nwinter1\ningrid\nbigmike\nbeta\nzidane\ntalon\nslave1\npissoff\nperson\nthegreat\nliving\nlexus\nmatador\nreaders\nriley\nroberta\narmani\nashlee\ngoldstar\n5656\ncards\nfmale\nferris\nfuking\ngaston\nfucku\nggggggg\nsauron\ndiggler\npacers\nlooser\npounded\npremier\npulled\ntown\ntrisha\ntriangle\ncornell\ncollin\ncosmic\ndeeper\ndepeche\nnorway\nbright\nhelmet\nkristine\nkendall\nmustard\nmisty1\nwatch\njagger\nbertie\nberger\nword\n3x7pxr\nsilver1\nsmoking\nsnowboar\nsonny\npaula\npenetrating\nphotoes\nlesbens\nlambert\nlindros\nlillian\nroadking\nrockford\n1357\n143143\nasasas\ngoodboy\n898989\nchicago1\ncard\nferrari1\ngaleries\ngodfathe\ngawker\ngargoyle\ngangster\nrubble\nrrrr\nonetime\npussyman\npooppoop\ntrapper\ntwenty\nabraham\ncinder\ncompany\nnewcastl\nboricua\nbunny1\nboxer\nhotred\nhockey1\nhooper\nedward1\nevan\nkris\nmisery\nmoscow\nmilk\nmortgage\nbigtit\nshow\nsnoopdog\nthree\nlionel\nleanne\njoshua1\njuly\n1230\nassholes\ncedric\nfallen\nfarley\ngene\nfrisky\nsanity\nscript\ndivine\ndharma\nlucky13\nproperty\ntricia\nakira\ndesiree\nbroadway\nbutterfly\nhunt\nhotbox\nhootie\nheat\nhowdy\nearthlink\nkarma\nkiteboy\nmotley\nwestwood\n1988\nbert\nblackbir\nbiggles\nwrench\nworking\nwrestle\nslippery\npheonix\npenny1\npianoman\ntomorrow\nthedude\njenn\njonjon\njones1\nmattie\nmemory\nmicheal\nroadrunn\narrow\nattitude\nazzer\nseahawks\ndiehard\ndotcom\nlola\ntunafish\nchivas\ncinnamon\nclouds\ndeluxe\nnorthern\nnuclear\nnorth\nboom\nboobie\nhurley\nkrishna\nmomomo\nmodles\nvolume\n23232323\nbluedog\nwwwwwww\nzerocool\nyousuck\npluto\nlimewire\nlink\njoung\nmarcia\nawnyce\ngonavy\nhaha\nfilms+pic+galeries\nfabian\nfrancois\ngirsl\nfuckthis\ngirfriend\nrufus\ndrive\nuncencored\na123456\nairport\nclay\nchrisbln\ncombat\ncygnus\ncupoi\nnever\nnetscape\nbrett\nhhhhhhhh\neagles1\nelite\nknockers\nkendra\nmommy\n1958\ntazmania\nshonuf\npiano\npharmacy\nthedog\nlips\njillian\njenkins\nmidway\narsenal1\nanaconda\naustrali\ngromit\ngotohell\n787878\n66666\ncarmex2\ncamber\ngator1\nginger1\nfuzzy\nseadoo\ndorian\nlovesex\nrancid\nuuuuuu\n911911\nnature\nbulldog1\nhelen\nhealth\nheater\nhiggins\nkirk\nmonalisa\nmmmmmmm\nwhiteout\nvirtual\nventura\njamie1\njapanes\njames007\n2727\n2469\nblam\nbitchass\nbelieve\nzephyr\nstiffy\nsweet1\nsilent\nsouthpar\nspectre\ntigger1\ntekken\nlenny\nlakota\nlionking\njjjjjjj\nmedical\nmegatron\n1369\nhawaiian\ngymnastic\ngolfer1\ngunners\n7779311\n515151\nfamous\nglass\nscreen\nrudy\nroyal\nsanfran\ndrake\noptimus\npanther1\nlove1\nmail\nmaggie1\npudding\nvenice\naaron1\ndelphi\nniceass\nbounce\nbusted\nhouse1\nkiller1\nmiracle\nmomo\nmusashi\njammin\n2003\n234567\nwp2003wp\nsubmit\nsilence\nsssssss\nstate\nspikes\nsleeper\npasswort\ntoledo\nkume\nmedia\nmeme\nmedusa\nmantis\nremote\nreading\nreebok\n1017\nartemis\nhampton\nharry1\ncafc91\nfettish\nfriendly\noceans\noooooooo\nmango\nppppp\ntrainer\ntroy\nuuuu\n909090\ncross\ndeath1\nnews\nbullfrog\nhokies\nholyshit\neeeeeee\nmitch\njasmine1\n&amp\n&amp;\nsergeant\nspinner\nleon\njockey\nrecords\nright\nbabyblue\nhans\ngooner\n474747\ncheeks\ncars\ncandice\nfight\nglow\npass1234\nparola\nokokok\npablo\nmagical\nmajor\nramsey\nposeidon\n989898\nconfused\ncircle\ncrusher\ncubswin\nnnnn\nhollywood\nerin\nkotaku\nmilo\nmittens\nwhatsup\nvvvvv\niomega\ninsertions\nbengals\nbermuda\nbiit\nyellow1\n012345\nspike1\nsouth\nsowhat\npitures\npeacock\npecker\ntheend\njuliette\njimmie\nromance\naugusta\nhayabusa\nhawkeyes\ncastro\nflorian\ngeoffrey\ndolly\nlulu\nqaz123\nusarmy\ntwinkle\ncloud\nchuckles\ncold\nhounddog\nhover\nhothot\neuropa\nernie\nkenshin\nkojak\nmikey1\nwater1\n196969\nbecause\nwraith\nzebra\nwwwww\n33333\nsimon1\nspider1\nsnuffy\nphilippe\nthunderb\nteddy1\nlesley\nmarino13\nmaria1\nredline\nrenault\naloha\nantoine\nhandyman\ncerberus\ngamecock\ngobucks\nfreesex\nduffman\nooooo\npapa\nnuggets\nmagician\nlongbow\npreacher\nporno1\ncounty\nchrysler\ncontains\ndalejr\ndarius\ndarlene\ndell\nnavy\nbuffy1\nhedgehog\nhoosiers\nhoney1\nhott\nheyhey\neurope\ndutchess\neverest\nwareagle\nihateyou\nsunflowe\n3434\nsenators\nshag\nspoon\nsonoma\nstalker\npoochie\nterminal\nterefon\nlaurence\nmaradona\nmaryann\nmarty\nroman\n1007\n142536\nalibaba\namerica1\nbartman\nastro\ngoth\ncentury\nchicken1\ncheater\nfour\nghost1\npasspass\noral\nr2d2c3po\ncivic\ncicero\nmyxworld\nkkkkk\nmissouri\nwishbone\ninfiniti\njameson\n1a2b3c\n1qwerty\nwonderboy\nskip\nshojou\nstanford\nsparky1\nsmeghead\npoiuy\ntitanium\ntorres\nlantern\njelly\njeanne\nmeier\n1213\nbayern\nbasset\ngsxr750\ncattle\ncharlene\nfishing1\nfullmoon\ngilles\ndima\nobelix\npopo\nprissy\nramrod\nunique\nabsolute\nbummer\nhotone\ndynasty\nentry\nkonyor\nmissy1\nmoses\n282828\nyeah\nxyz123\nstop\n426hemi\n404040\nseinfeld\nsimmons\npingpong\nlazarus\nmatthews\nmarine1\nmanning\nrecovery\n12345a\nbeamer\nbabyface\ngreece\ngustav\n7007\ncharity\ncamilla\nccccccc\nfaggot\nfoxy\nfrozen\ngladiato\nduckie\ndogfood\nparanoid\npackers1\nlongjohn\nradical\ntuna\nclarinet\nclaudio\ncircus\ndanny1\nnovell\nnights\nbonbon\nkashmir\nkiki\nmortimer\nmodelsne\nmoondog\nmonaco\nvladimir\ninsert\n1953\nzxc123\nsupreme\n3131\nsexxx\nselena\nsoftail\npoipoi\npong\ntogether\nmars\nmartin1\nrogue\nalone\navalanch\naudia4\n55bgates\ncccccccc\nchick\ncame11\nfigaro\ngeneva\ndogboy\ndnsadm\ndipshit\nparadigm\nothello\noperator\nofficer\nmalone\npost\nrafael\nvalencia\ntripod\nchoice\nchopin\ncoucou\ncoach\ncocksuck\ncommon\ncreature\nborussia\nbook\nbrowning\nheritage\nhiziad\nhomerj\neight\nearth\nmillions\nmullet\nwhisky\njacques\nstore\n4242\nspeedo\nstarcraf\nskylar\nspaceman\npiggy\npierce\ntiger2\nlegos\nlala\njezebel\njudy\njoker1\nmazda\nbarton\nbaker\n727272\nchester1\nfishman\nfood\nrrrrrrrr\nsandwich\ndundee\nlumber\nmagazine\nradar\nppppppp\ntranny\naaliyah\nadmiral\ncomics\ncleo\ndelight\nbuttfuck\nhomeboy\neternal\nkilroy\nkellie\nkhan\nviolin\nwingman\nwalmart\nbigblue\nblaze\nbeemer\nbeowulf\nbigfish\nyyyyyyy\nwoodie\nyeahbaby\n0123456\ntbone\nstyle\nsyzygy\nstarter\nlemon\nlinda1\nmerlot\nmexican\n11235813\nanita\nbanner\nbangbang\nbadman\nbarfly\ngrease\ncarla\ncharles1\nffffffff\nscrew\ndoberman\ndiane\ndogshit\noverkill\ncounter\ncoolguy\nclaymore\ndemons\ndemo\nnomore\nnormal\nbrewster\nhhhhhhh\nhondas\niamgod\nenterme\neverett\nelectron\neastside\nkayla\nminimoni\nmybaby\nwildbill\nwildcard\nipswich\n200000\nbearcat\nzigzag\nyyyyyyyy\nxander\nsweetnes\n369369\nskyler\nskywalker\npigeon\npeyton\ntipper\nlilly\nasdf123\nalphabet\nasdzxc\nbabybaby\nbanane\nbarnes\nguyver\ngraphics\ngrand\nchinook\nflorida1\nflexible\nfuckinside\notis\nursitesux\ntototo\ntrust\ntower\nadam12\nchristma\ncorey\nchrome\nbuddie\nbombers\nbunker\nhippie\nkeegan\nmisfits\nvickie\n292929\nwoofer\nwwwwwwww\nstubby\nsheep\nsecrets\nsparta\nstang\nspud\nsporty\npinball\njorge\njust4fun\njohanna\nmaxxxx\nrebecca1\ngunther\nfatima\nfffffff\nfreeway\ngarion\nscore\nrrrrr\nsancho\noutback\nmaggot\npuddin\ntrial\nadrienne\n987456\ncolton\nclyde\nbrain\nbrains\nhoops\neleanor\ndwayne\nkirby\nmydick\nvilla\n19691969\nbigcat\nbecker\nshiner\nsilverad\nspanish\ntemplar\nlamer\njuicy\nmarsha\nmike1\nmaximum\nrhiannon\nreal\n1223\n10101010\narrows\nandres\nalucard\nbaldwin\nbaron\navenue\nashleigh\nhaggis\nchannel\ncheech\nsafari\nross\ndog123\norion1\npaloma\nqwerasdf\npresiden\nvegitto\ntrees\n969696\nadonis\ncolonel\ncookie1\nnewyork1\nbrigitte\nbuddyboy\nhellos\nheineken\ndwight\neraser\nkerstin\nmotion\nmoritz\nmillwall\nvisual\njaybird\n1983\nbeautifu\nbitter\nyvette\nzodiac\nsteven1\nsinister\nslammer\nsmashing\nslick1\nsponge\nteddybea\ntheater\nthis\nticklish\nlipstick\njonny\nmassage\nmann\nreynolds\nring\n1211\namazing\naptiva\napplepie\nbailey1\nguitar1\nchanel\ncanyon\ngagged\nfuckme1\nrough\ndigital1\ndinosaur\npunk\n98765\n90210\nclowns\ncubs\ndaniels\ndeejay\nnigga\nnaruto\nboxcar\nicehouse\nhotties\nelectra\nkent\nwidget\nindia\ninsanity\n1986\n2004\nbest\nbluefish\nbingo1\n*****\nstratus\nstrength\nsultan\nstorm1\n44444\n4200\nsentnece\nseason\nsexyboy\nsigma\nsmokie\nspam\npoint\npippo\nticket\ntemppass\njoel\nmanman\nmedicine\n1022\nanton\nalmond\nbacchus\naztnm\naxio\nawful\nbamboo\nhakr\ngregor\nhahahaha\n5678\ncasanova\ncaprice\ncamero1\nfellow\nfountain\ndupont\ndolphin1\ndianne\npaddle\nmagnet\nqwert1\npyon\nporsche1\ntripper\nvampires\ncoming\nnoway\nburrito\nbozo\nhighheel\nhughes\nhookem\neddie1\nellie\nentropy\nkkkkkkkk\nkkkkkkk\nillinois\njacobs\n1945\n1951\n24680\n21212121\n100000\nstonecold\ntaco\nsubzero\nsharp\nsexxxy\nskolko\nshanna\nskyhawk\nspurs1\nsputnik\npiazza\ntestpass\nletter\nlane\nkurt\njiggaman\nmatilda\n1224\nharvard\nhannah1\n525252\n4ever\ncarbon\nchef\nfederico\nghosts\ngina\nscorpio1\nrt6ytere\nmadison1\nloki\nraquel\npromise\ncoolness\nchristina\ncoldbeer\ncitadel\nbrittney\nhighway\nevil\nmonarch\nmorgan1\nwashingt\n1997\nbella1\nberry\nyaya\nyolanda\nsuperb\ntaxman\nstudman\nstephanie\n3636\nsherri\nsheriff\nshepherd\npoland\npizzas\ntiffany1\ntoilet\nlatina\nlassie\nlarry1\njoseph1\nmephisto\nmeagan\nmarian\nreptile\nrico\nrazor\n1013\nbarron\nhammer1\ngypsy\ngrande\ncarroll\ncamper\nchippy\ncat123\ncall\nchimera\nfiesta\nglock\nglenn\ndomain\ndieter\ndragonba\nonetwo\nnygiants\nodessa\npassword2\nlouie\nquartz\nprowler\nprophet\ntowers\nultra\ncocker\ncorleone\ndakota1\ncumm\nnnnnnnn\nnatalia\nboxers\nhugo\nheynow\nhollow\niceberg\nelvira\nkittykat\nkate\nkitchen\nwasabi\nvikings1\nimpact\nbeerman\nstring\nsleep\nsplinter\nsnoopy1\npipeline\npocket\nlegs\nmaple\nmickey1\nmanuela\nmermaid\nmicro\nmeowmeow\nredbird\nalisha\nbaura\nbattery\ngrass\nchevys\nchestnut\ncaravan\ncarina\ncharmed\nfraser\nfrogman\ndiving\ndogger\ndraven\ndrifter\noatmeal\nparis1\nlongdong\nquant4307s\nrachel1\nvegitta\ncole\ncobras\ncorsair\ndadada\nnoelle\nmylife\nnine\nbowwow\nbody\nhotrats\neastwood\nmoonligh\nmodena\nwave\nillusion\niiiiiii\njayhawks\nbirgit\nzone\nsutton\nsusana\nswingers\nshocker\nshrimp\nsexgod\nsquall\nstefanie\nsqueeze\nsoul\npatrice\npoiu\nplayers\ntigers1\ntoejam\ntickler\nline\njulie1\njimbo1\njefferso\njuanita\nmichael2\nrodeo\nrobot\n1023\nannie1\nbball\nguess\nhappy2\ncharter\nfarm\nflasher\nfalcon1\nfiction\nfastball\ngadget\nscrabble\ndiaper\ndirtbike\ndinner\noliver1\npartner\npaco\nlucille\nmacman\npoopy\npopper\npostman\nttttttt\nursula\nacura\ncowboy1\nconan\ndaewoo\ncyrus\ncustomer\nnation\nnemrac58\nnnnnn\nnextel\nbolton\nbobdylan\nhopeless\neureka\nextra\nkimmie\nkcj9wx5n\nkillbill\nmusica\nvolkswag\nwage\nwindmill\nwert\nvintage\niloveyou1\nitsme\nbessie\nzippo\n311311\nstarligh\nsmokey1\nspot\nsnappy\nsoulmate\nplasma\nthelma\ntonight\nkrusty\njust4me\nmcdonald\nmarius\nrochelle\nrebel1\n1123\nalfredo\naubrey\naudi\nchantal\nfick\ngoaway\nroses\nsales\nrusty2\ndirt\ndogbone\ndoofus\nooooooo\noblivion\nmankind\nluck\nmahler\nlllllll\npumper\npuck\npulsar\nvalkyrie\ntupac\ncompass\nconcorde\ncostello\ncougars\ndelaware\nniceguy\nnocturne\nbob123\nboating\nbronze\nhopkins\nherewego\nhewlett\nhouhou\nhubert\nearnhard\neeeeeeee\nkeller\nmingus\nmobydick\nventure\nverizon\nimation\n1950\n1948\n1949\n223344\nbigbig\nblossom\nzack\nwowwow\nsissy\nskinner\nspiker\nsquare\nsnooker\nsluggo\nplayer1\njunk\njeannie\njsbach\njumbo\njewel\nmedic\nrobins\nreddevil\nreckless\n123456a\n1125\n1031\nbeacon\nastra\ngumby\nhammond\nhassan\n757575\n585858\nchillin\nfuck1\nsander\nlowell\nradiohea\nupyours\ntrek\ncourage\ncoolcool\nclassics\nchoochoo\ndarryl\nnikki1\nnitro\nbugs\nboytoy\nellen\nexcite\nkirsty\nkane\nwingnut\nwireless\nicu812\n1master\nbeatle\nbigblock\nblanca\nwolfen\nsummer99\nsugar1\ntartar\nsexysexy\nsenna\nsexman\nsick\nsomeone\nsoprano\npippin\nplatypus\npixies\ntelephon\nland\nlaura1\nlaurent\nrimmer\nroad\nreport\n1020\n12qwaszx\narturo\naround\nhamish\nhalifax\nfishhead\nforum\ndododo\ndoit\noutside\nparamedi\nlonesome\nmandy1\ntwist\nuuuuu\nuranus\nttttt\nbutcher\nbruce1\nhelper\nhopeful\neduard\ndusty1\nkathy1\nkatherin\nmoonbeam\nmuscles\nmonster1\nmonkeybo\nmorton\nwindsurf\nvvvvvvv\nvivid\ninstall\n1947\n187187\n1941\n1952\ntatiana\nsusan1\n31415926\nsinned\nsexxy\nsenator\nsebastian\nshadows\nsmoothie\nsnowflak\nplaystat\nplaya\nplayboy1\ntoaster\njerry1\nmarie1\nmason1\nmerlin1\nroger1\nroadster\n112358\n1121\nandrea1\nbacardi\nauto\nhardware\nhardy\n789789\n5555555\ncaptain1\nflores\nfergus\nsascha\nrrrrrrr\ndome\nonion\nnutter\nlololo\nqqqqqqq\nquick\nundertak\nuuuuuuuu\nuuuuuuu\ncriminal\ncobain\ncindy1\ncoors\ndani\ndescent\nnimbus\nnomad\nnanook\nnorwich\nbomb\nbombay\nbroker\nhookup\nkiwi\nwinners\njackpot\n1a2b3c4d\n1776\nbeardog\nbighead\nblast\nbird33\n0987\nstress\nshot\nspooge\npelican\npeepee\nperry\npointer\ntitan\nthedoors\njeremy1\nannabell\naltima\nbaba\nhallie\nhate\nhardone\n5454\ncandace\ncatwoman\nflip\nfaithful\nfinance\nfarmboy\nfarscape\ngenesis1\nsalomon\ndestroy\npapers\noption\npage\nloser1\nlopez\nr2d2\npumpkins\ntraining\nchriss\ncumcum\nninjas\nninja1\nhung\nerika\neduardo\nkillers\nmiller1\nislander\njamesbond\nintel\njarvis\n19841984\n2626\nbizzare\nblue12\nbiker\nyoyoma\nsushi\nstyles\nshitface\nseries\nshanti\nspanker\nsteffi\nsmart\nsphinx\nplease1\npaulie\npistons\ntiburon\nlimited\nmaxwell1\nmdogg\nrockies\narmstron\nalexia\narlene\nalejandr\narctic\nbanger\naudio\nasimov\naugustus\ngrandpa\n753951\n4you\nchilly\ncare1839\nchapman\nflyfish\nfantasia\nfreefall\nsanta\nsandrine\noreo\nohshit\nmacbeth\nmadcat\nloveya\nmallory\nrage\nquentin\nqwerqwer\nproject\nramirez\ncolnago\ncitizen\nchocha\ncobalt\ncrystal1\ndabears\nnevets\nnineinch\nbroncos1\nhelene\nhuge\nedgar\nepsilon\neaster\nkestrel\nmoron\nvirgil\nwinston1\nwarrior1\niiiiiiii\niloveyou2\n1616\nbeat\nbettina\nwoowoo\nzander\nstraight\nshower\nsloppy\nspecialk\ntinkerbe\njellybea\nreader\nromero\nredsox1\nride\n1215\n1112\nannika\narcadia\nanswer\nbaggio\nbase\nguido\n555666\ncarmel\ncayman\ncbr900rr\nchips\ngabriell\ngertrude\nglennwei\nroxy\nsausages\ndisco\npass1\nluna\nlovebug\nmacmac\nqueenie\npuffin\nvanguard\ntrip\ntrinitro\nairwolf\nabbott\naaa111\ncocaine\ncisco\ncottage\ndayton\ndeadly\ndatsun\nbricks\nbumper\neldorado\nkidrock\nwizard1\nwhiskers\nwind\nwildwood\nistheman\ninterest\nitaly\n25802580\nbenoit\nbigones\nwoodland\nwolfpac\nstrawber\nsuicide\n3030\nsheba1\nsixpack\npeace1\nphysics\npearson\ntigger2\ntoad\nmegan1\nmeow\nringo\nroll\namsterdam\n717171\n686868\n5424\ncatherine\ncanuck\nfootball1\nfootjob\nfulham\nseagull\norgy\nlobo\nmancity\ntruth\ntrace\nvancouve\nvauxhall\nacidburn\nderf\nmyspace1\nboozer\nbuttercu\nhowell\nhola\neaston\nminemine\nmunch\njared\n1dragon\nbiology\nbestbuy\nbigpoppa\nblackout\nblowfish\nbmw325\nbigbob\nstream\ntalisman\ntazz\nsundevil\n3333333\nskate\nshutup\nshanghai\nshop\nspencer1\nslowhand\npolish\npinky1\ntootie\nthecrow\nleroy\njonathon\njubilee\njingle\nmartine\nmatrix1\nmanowar\nmichaels\nmessiah\nmclaren\nresident\nreilly\nredbaron\nrollins\nromans\nreturn\nrivera\nandromed\nathlon\nbeach1\nbadgers\nguitars\nharald\nharddick\ngotribe\n6996\n7grout\n5wr2i7h8\n635241\nchase1\ncarver\ncharlotte\nfallout\nfiddle\nfredrick\nfenris\nfrancesc\nfortuna\nferguson\nfairlane\nfelipe\nfelix1\nforward\ngasman\nfrost\nfucks\nsahara\nsassy1\ndogpound\ndogbert\ndivx1\nmanila\nloretta\npriest\npornporn\nquasar\nvenom\n987987\naccess1\nclippers\ndaylight\ndecker\ndaman\ndata\ndentist\ncrusty\nnathan1\nnnnnnnnn\nbruno1\nbucks\nbrodie\nbudapest\nkittens\nkerouac\nmother1\nwaldo1\nwedding\nwhistler\nwhatwhat\nwanderer\nidontkno\n1942\n1946\nbigdawg\nbigpimp\nzaqwsx\n414141\n3000gt\n434343\nshoes\nserpent\nstarr\nsmurf\npasword\ntommie\nthisisit\nlake\njohn1\nrobotics\nredeye\nrebelz\n1011\nalatam\nasses\nasians\nbama\nbanzai\nharvest\ngonzalez\nhair\nhanson\n575757\n5329\ncascade\nchinese\nfatty\nfender1\nflower2\nfunky\nsambo\ndrummer1\ndogcat\ndottie\noedipus\nosama\nmacleod\nprozac\nprivate1\nrampage\npunch\npresley\nconcord\ncook\ncinema\ncornwall\ncleaner\nchristopher\nciccio\ncorinne\nclutch\ncorvet07\ndaemon\nbruiser\nboiler\nhjkl\neyes\negghead\nexpert\nethan\nkasper\nmordor\nwasted\njamess\niverson3\nbluesman\nzouzou\n090909\n1002\nswitch\nstone1\n4040\nsisters\nsexo\nshawna\nsmith1\nsperma\nsneaky\npolska\nthewho\nterminat\nkrypton\nlawson\nlibrary\nlekker\njules\njohnson1\njohann\njustus\nrockie\nromano\naspire\nbastards\ngoodie\ncheese1\nfenway\nfishon\nfishin\nfuckoff1\ngirls1\nsawyer\ndolores\ndesmond\nduane\ndoomsday\npornking\nramones\nrabbits\ntransit\naaaaa1\nclock\ndelilah\nnoel\nboyz\nbookworm\nbongo\nbunnies\nbrady\nbuceta\nhighbury\nhenry1\nheels\neastern\nkrissy\nmischief\nmopar\nministry\nvienna\nweston\nwildone\nvodka\njayson\nbigbooty\nbeavis1\nbetsy\nxxxxxx1\nyogibear\n000001\n0815\nzulu\n420000\nseptember\nsigmar\nsprout\nstalin\npeggy\npatch\nlkjhgfds\nlagnaf\nrolex\nredfox\nreferee\n123123123\n1231\nangus1\nariana\nballin\nattila\nhall\ngreedy\ngrunt\n747474\ncarpedie\ncecile\ncaramel\nfoxylady\nfield\ngatorade\ngidget\nfutbol\nfrosch\nsaiyan\nschmidt\ndrums\ndonner\ndoggy1\ndrum\ndoudou\npack\npain\nnutmeg\nquebec\nvaldepen\ntrash\ntriple\ntosser\ntuscl\ntrack\ncomfort\nchoke\ncomein\ncola\ndeputy\ndeadpool\nbremen\nborders\nbronson\nbreak\nhotass\nhotmail1\neskimo\neggman\nkoko\nkieran\nkatrin\nkordell1\nkomodo\nmone\nmunich\nvvvvvvvv\nwinger\njaeger\nivan\njackson5\n2222222\nbergkamp\nbennie\nbigben\nzanzibar\nworm\nxxx123\nsunny1\n373737\nservices\nsheridan\nslater\nslayer1\nsnoop\nstacie\npeachy\nthecure\ntimes\nlittle1\njennaj\nmarquis\nmiddle\nrasta69\n1114\naries\nhavana\ngratis\ncalgary\ncheckers\nflanker\nsalope\ndirty1\ndraco\ndogface\nluv2epus\nrainbow6\nqwerty123\numpire\nturnip\nvbnm\ntucson\ntroll\naileen\ncodered\ncommande\ndamon\nnana\nneon\nnico\nnightwin\nneil\nboomer1\nbushido\nhotmail0\nhorace\nenternow\nkaitlyn\nkeepout\nkaren1\nmindy\nmnbv\nviewsoni\nvolcom\nwizards\nwine\n1995\nberkeley\nbite\nzach\nwoodstoc\ntarpon\nshinobi\nstarstar\nphat\npatience\npatrol\ntoolbox\njulien\njohnny1\njoebob\nmarble\nriders\nreflex\n120676\n1235\nangelus\nanthrax\natlas\nhawks\ngrandam\nharlem\nhawaii50\ngorgeous\n655321\ncabron\nchalleng\ncallisto\nfirewall\nfirefire\nfischer\nflyer\nflower1\nfactory\nfederal\ngambler\nfrodo1\nfunk\nsand\nsam123\nscania\ndingo\npapito\npassmast\nolive\npalermo\nou8123\nlock\nranch\npride\nrandy1\ntwiggy\ntravis1\ntransfer\ntreetop\naddict\nadmin1\n963852\naceace\nclarissa\ncliff\ncirrus\nclifton\ncolin\nbobdole\nbonner\nbogus\nbonjovi\nbootsy\nboater\nelway7\nedison\nkelvin\nkenny1\nmoonshin\nmontag\nmoreno\nwayne1\nwhite1\njazzy\njakejake\n1994\n1991\n2828\nblunt\nbluejays\nbeau\nbelmont\nworthy\nsystems\nsensei\nsouthpark\nstan\npeeper\npharao\npigpen\ntomahawk\nteensex\nleedsutd\nlarkin\njermaine\njeepster\njimjim\njosephin\nmelons\nmarlon\nmatthias\nmarriage\nrobocop\n1003\n1027\nantelope\nazsxdc\ngordo\nhazard\ngranada\n8989\n7894\nceasar\ncabernet\ncheshire\ncalifornia\nchelle\ncandy1\nfergie\nfanny\nfidelio\ngiorgio\nfuckhead\nruth\nsanford\ndiego\ndominion\ndevon\npanic\nlonger\nmackie\nqawsed\ntrucking\ntwelve\nchloe1\ncoral\ndaddyo\nnostromo\nboyboy\nbooster\nbucky\nhonolulu\nesquire\ndynamite\nmotor\nmollydog\nwilder\nwindows1\nwaffle\nwallet\nwarning\nvirus\nwashburn\nwealth\nvincent1\njabber\njaguars\njavelin\nirishman\nidefix\nbigdog1\nblue42\nblanked\nblue32\nbiteme1\nbearcats\nblaine\nyessir\nsylveste\nteam\nstephan\nsunfire\ntbird\nstryker\n3ip76k2\nsevens\nsheldon\npilgrim\ntenchi\ntitman\nleeds\nlithium\nlander\nlinkin\nlandon\nmarijuan\nmariner\nmarkie\nmidnite\nreddwarf\n1129\n123asd\n12312312\nallstar\nalbany\nasdf12\nantonia\naspen\nhardball\ngoldfing\n7734\n49ers\ncarlo\nchambers\ncable\ncarnage\ncallum\ncarlos1\nfitter\nfandango\nfestival\nflame\ngofast\ngamma\nfucmy69\nscrapper\ndogwood\ndjango\nmagneto\nloose\npremium\naddison\n9999999\nabc1234\ncromwell\nnewyear\nnichole\nbookie\nburns\nbounty\nbrown1\nbologna\nearl\nentrance\nelway\nkilljoy\nkerry\nkeenan\nkick\nklondike\nmini\nmouser\nmohammed\nwayer\nimpreza\nirene\ninsomnia\n24682468\n2580\n24242424\nbillbill\nbellaco\nblessing\nblues1\nbedford\nblanco\nblunts\nstinks\nteaser\nstreets\nsf49ers\nshovel\nsolitude\nspikey\nsonia\npimpdadd\ntimeout\ntoffee\nlefty\njohndoe\njohndeer\nmega\nmanolo\nmentor\nmargie\nratman\nridge\nrecord\nrhodes\nrobin1\n1124\n1210\n1028\n1226\nanother\nbabylove\nbarbados\nharbor\ngramma\n646464\ncarpente\nchaos1\nfishbone\nfireblad\nglasgow\nfrogs\nscissors\nscreamer\nsalem\nscuba1\nducks\ndriven\ndoggies\ndicky\ndonovan\nobsidian\nrams\nprogress\ntottenham\naikman\ncomanche\ncorolla\nclarke\nconway\ncumslut\ncyborg\ndancing\nboston1\nbong\nhoudini\nhelmut\nelvisp\nedge\nkeksa12\nmisha\nmonty1\nmonsters\nwetter\nwatford\nwiseguy\nveronika\nvisitor\njanelle\n1989\n1987\n20202020\nbiatch\nbeezer\nbigguns\nblueball\nbitchy\nwyoming\nyankees2\nwrestler\nstupid1\nsealteam\nsidekick\nsimple1\nsmackdow\nsporting\nspiral\nsmeller\nsperm\nplato\ntophat\ntest2\ntheatre\nthick\ntoomuch\nleigh\njello\njewish\njunkie\nmaxim\nmaxime\nmeadow\nremingto\nroofer\n124038\n1018\n1269\n1227\n123457\narkansas\nalberta\naramis\nandersen\nbeaker\nbarcelona\nbaltimor\ngoogoo\ngoochi\n852456\n4711\ncatcher\ncarman\nchamp1\nchess\nfortress\nfishfish\nfirefigh\ngeezer\nrsalinas\nsamuel1\nsaigon\nscooby1\ndoors\ndick1\ndevin\ndoom\ndirk\ndoris\ndontknow\nload\nmagpies\nmanfred\nraleigh\nvader1\nuniversa\ntulips\ndefense\nmygirl\nburn\nbowtie\nbowman\nholycow\nheinrich\nhoneys\nenforcer\nkatherine\nminerva\nwheeler\nwitch\nwaterboy\njaime\nirving\n1992\n23skidoo\nbimbo\nblue11\nbirddog\nwoodman\nwomble\nzildjian\n030303\nstinker\nstoppedby\nsexybabe\nspeakers\nslugger\nspotty\nsmoke1\npolopolo\nperfect1\nthings\ntorpedo\ntender\nthrasher\nlakeside\nlilith\njimmys\njerk\njunior1\nmarsh\nmasamune\nrice\nroot\n1214\napril1\nallgood\nbambi\ngrinch\n767676\n5252\ncherries\nchipmunk\ncezer121\ncarnival\ncapecod\nfinder\nflint\nfearless\ngoats\nfunstuff\ngideon\nsavior\nseabee\nsandro\nschalke\nsalasana\ndisney1\nduckman\noptions\npancake\npantera1\nmalice\nlookin\nlove123\nlloyd\nqwert123\npuppet\nprayers\nunion\ntracer\ncrap\ncreation\ncwoui\nnascar24\nhookers\nhollie\nhewitt\nestrella\nerection\nernesto\nericsson\nedthom\nkaylee\nkokoko\nkokomo\nkimball\nmorales\nmooses\nmonk\nwalton\nweekend\ninter\ninternal\n1michael\n1993\n19781978\n25252525\nworker\nsummers\nsurgery\nshibby\nshamus\nskibum\nsheepdog\nsex69\nspliff\nslipper\nspoons\nspanner\nsnowbird\nslow\ntoriamos\ntemp123\ntennesse\nlakers1\njomama\njulio\nmazdarx7\nrosario\nrecon\nriddle\nroom\nrevolver\n1025\n1101\nbarney1\nbabycake\nbaylor\ngotham\ngravity\nhallowee\nhancock\n616161\n515000\ncaca\ncannabis\ncastor\nchilli\nfdsa\ngetout\nfuck69\ngators1\nsail\nsable\nrumble\ndolemite\ndork\ndickens\nduffer\ndodgers1\npainting\nonions\nlogger\nlorena\nlookout\nmagic32\nport\npoon\nprime\ntwat\ncoventry\ncitroen\nchristmas\ncivicsi\ncocksucker\ncoochie\ncompaq1\nnancy1\nbuzzer\nboulder\nbutkus\nbungle\nhogtied\nhonor\nhero\nhotgirls\nhilary\nheidi1\neggplant\nmustang6\nmortal\nmonkey12\nwapapapa\nwendy1\nvolleyba\nvibrate\nvicky\nbledsoe\nblink\nbirthday4\nwoof\nxxxxx1\ntalk\nstephen1\nsuburban\nstock\ntabatha\nsheeba\nstart1\nsoccer10\nsomething\nstarcraft\nsoccer12\npeanut1\nplastics\npenthous\npeterbil\ntools\ntetsuo\ntorino\ntennis1\ntermite\nladder\nlast\nlemmein\nlakewood\njughead\nmelrose\nmegane\nreginald\nredone\nrequest\nangela1\nalive\nalissa\ngoodgirl\ngonzo1\ngolden1\ngotyoass\n656565\n626262\ncapricor\nchains\ncalvin1\nfoolish\nfallon\ngetmoney\ngodfather\ngabber\ngilligan\nrunaway\nsalami\ndummy\ndungeon\ndudedude\ndumb\ndope\nopus\nparagon\noxygen\npanhead\npasadena\nopendoor\nodyssey\nmagellan\nlottie\nprinting\npressure\nprince1\ntrustme\nchrista\ncourt\ndavies\nneville\nnono\nbread\nbuffet\nhound\nkajak\nkillkill\nmona\nmoto\nmildred\nwinner1\nvixen\nwhiteboy\nversace\nwinona\nvoyager1\ninstant\nindy\njackjack\nbigal\nbeech\nbiggun\nblake1\nblue99\nbig1\nwoods\nsynergy\nsuccess1\n336699\nsixty9\nshark1\nskin\nsimba1\nsharpe\nsebring\nspongebo\nspunk\nsprings\nsliver\nphialpha\npassword9\npizza1\nplane\nperkins\npookey\ntickling\nlexingky\nlawman\njoe123\njolly\nmike123\nromeo1\nredheads\nreserve\napple123\nalanis\nariane\nantony\nbackbone\naviation\nband\nhand\ngreen123\nhaley\ncarlitos\nbyebye\ncartman1\ncamden\nchewy\ncamaross\nfavorite6\nforumwp\nfranks\nginscoot\nfruity\nsabrina1\ndevil666\ndoughnut\npantie\noldone\npaintball\nlumina\nrainbow1\nprosper\ntotal\ntrue\numbrella\najax\n951753\nachtung\nabc12345\ncompact\ncolor\ncorn\ncomplete\nchristi\ncloser\ncorndog\ndeerhunt\ndarklord\ndank\nnimitz\nbrandy1\nbowl\nbreanna\nholidays\nhetfield\nholein1\nhillbill\nhugetits\neast\nevolutio\nkenobi\nwhiplash\nwaldo\nwg8e3wjf\nwing\nistanbul\ninvis\n1996\nbenton\nbigjohn\nbluebell\nbeef\nbeater\nbenji\nbluejay\nxyzzy\nwrestling\nstorage\nsuperior\nsuckdick\ntaichi\nstellar\nstephane\nshaker\nskirt\nseymour\nsemper\nsplurge\nsqueak\npearls\nplayball\npitch\nphyllis\npooky\npiss\ntomas\ntitfuck\njoemama\njohnny5\nmarcello\nmarjorie\nmarried\nmaxi\nrhubarb\nrockwell\nratboy\nreload\nrooney\nredd\n1029\n1030\n1220\nanchor\nbbking\nbaritone\ngryphon\ngone\n57chevy\n494949\nceleron\nfishy\ngladiator\nfucker1\nroswell\ndougie\ndowner\ndicker\ndiva\ndomingo\ndonjuan\nnympho\nomar\npraise\nracers\ntrick\ntrauma\ntruck1\ntrample\nacer\ncorwin\ncricket1\nclemente\nclimax\ndenmark\ncuervo\nnotnow\nnittany\nneutron\nnative\nbosco1\nbuffa\nbreaker\nhello2\nhydro\nestelle\nexchange\nexplore\nkisskiss\nkittys\nkristian\nmontecar\nmodem\nmississi\nmooney\nweiner\nwashington\n20012001\nbigdick1\nbibi\nbenfica\nyahoo1\nstriper\ntabasco\nsupra\n383838\n456654\nseneca\nserious\nshuttle\nsocks\nstanton\npenguin1\npathfind\ntestibil\nthethe\nlisten\nlightning\nlighting\njeter2\nmarma\nmark1\nmetoo\nrepublic\nrollin\nredleg\nredbone\nredskin\nrocco\n1245\narmand\nanthony7\naltoids\nandrews\nbarley\naway\nasswipe\nbauhaus\nbbbbbb1\ngohome\nharrier\ngolfpro\ngoldeney\n818181\n6666666\n5000\n5rxypn\ncameron1\ncalling\nchecker\ncalibra\nfields\nfreefree\nfaith1\nfist\nfdm7ed\nfinally\ngiraffe\nglasses\ngiggles\nfringe\ngate\ngeorgie\nscamper\nrrpass1\nscrewyou\nduffy\ndeville\ndimples\npacino\nontario\npassthie\noberon\nquest1\npostov1000\npuppydog\npuffer\nraining\nprotect\nqwerty7\ntrey\ntribe\nulysses\ntribal\nadam25\na1234567\ncompton\ncollie\ncleopatr\ncontract\ndavide\nnorris\nnamaste\nmyrtle\nbuffalo1\nbonovox\nbuckley\nbukkake\nburning\nburner\nbordeaux\nburly\nhun999\nemilie\nelmo\nenters\nenrique\nkeisha\nmohawk\nwillard\nvgirl\nwhale\nvince\njayden\njarrett\n1812\n1943\n222333\nbigjim\nbigd\nzoom\nwordup\nziggy1\nyahooo\nworkout\nyoung1\nwritten\nxmas\nzzzzzz1\nsurfer1\nstrife\nsunlight\ntasha1\nskunk\nshauna\nseth\nsoft\nsprinter\npeaches1\nplanes\npinetree\nplum\npimping\ntheforce\nthedon\ntoocool\nleeann\nladdie\nlist\nlkjh\nlara\njoke\njupiter1\nmckenzie\nmatty\nrene\nredrose\n1200\n102938\nannmarie\nalexa\nantares\naustin31\nground\ngoose1\n737373\n78945612\n789987\n6464\ncalimero\ncaster\ncasper1\ncement\nchevrolet\nchessie\ncaddy\nchill\nchild\ncanucks\nfeeling\nfavorite\nfellatio\nf00tball\nfrancine\ngateway2\ngigi\ngamecube\ngiovanna\nrugby1\nscheisse\ndshade\ndudes\ndixie1\nowen\noffshore\nolympia\nlucas1\nmacaroni\nmanga\npringles\npuff\ntribble\ntrouble1\nussy\ncore\nclint\ncoolhand\ncolonial\ncolt\ndebra\ndarthvad\ndealer\ncygnusx1\nnatalie1\nnewark\nhusband\nhiking\nerrors\neighteen\nelcamino\nemmett\nemilia\nkoolaid\nknight1\nmurphy1\nvolcano\nidunno\n2005\n2233\nblock\nbenito\nblueberr\nbiguns\nyamahar1\nzapper\nzorro1\n0911\n3006\nsixsix\nshopper\nsiobhan\nsextoy\nstafford\nsnowboard\nspeedway\nsounds\npokey\npeabody\nplayboy2\ntiti\nthink\ntoast\ntoonarmy\nlister\nlambda\njoecool\njonas\njoyce\njuniper\nmercer\nmax123\nmanny\nmassimo\nmariposa\nmet2002\nreggae\nricky1\n1236\n1228\n1016\nall4one\narianna\nbaberuth\nasgard\ngonzales\n484848\n5683\n6669\ncatnip\nchiquita\ncharisma\ncapslock\ncashmone\nchat\nfigure\ngalant\nfrenchy\ngizmodo1\ngirlies\ngabby\ngarner\nscrewy\ndoubled\ndivers\ndte4uw\ndone\ndragonfl\nmaker\nlocks\nrachelle\ntreble\ntwinkie\ntrailer\ntropical\nacid\ncrescent\ncooking\ncococo\ncory\ndabomb\ndaffy\ndandfa\ncyrano\nnathanie\nbriggs\nboners\nhelium\nhorton\nhoffman\nhellas\nespresso\nemperor\nkilla\nkikimora\nwanda\nw4g8at\nverona\nilikeit\niforget\n1944\n20002000\nbirthday1\nbeatles1\nblue1\nbigdicks\nbeethove\nblacklab\nblazers\nbenny1\nwoodwork\n0069\n0101\ntaffy\nsusie\nsurvivor\nswim\nstokes\n4567\nshodan\nspoiled\nsteffen\npissed\npavlov\npinnacle\nplace\npetunia\nterrell\nthirty\ntoni\ntito\nteenie\nlemonade\nlily\nlillie\nlalakers\nlebowski\nlalalala\nladyboy\njeeper\njoyjoy\nmercury1\nmantle\nmannn\nrocknrol\nriversid\nreeves\n123aaa\n11112222\n121314\n1021\n1004\n1120\nallen1\nambers\namstel\nambrose\nalice1\nalleycat\nallegro\nambrosia\nalley\naustralia\nhatred\ngspot\ngraves\ngoodsex\nhattrick\nharpoon\n878787\n8inches\n4wwvte\ncassandr\ncharlie123\ncase\nchavez\nfighting\ngabriela\ngatsby\nfudge\ngerry\ngeneric\ngareth\nfuckme2\nsamm\nsage\nseadog\nsatchmo\nscxakv\nsantafe\ndipper\ndingle\ndizzy\noutoutout\nmadmad\nlondon1\nqbg26i\npussy123\nrandolph\nvaughn\ntzpvaw\nvamp\ncomedy\ncomp\ncowgirl\ncoldplay\ndawgs\ndelaney\nnt5d27\nnovifarm\nneedles\nnotredam\nnewness\nmykids\nbryan1\nbouncer\nhihihi\nhoneybee\niceman1\nherring\nhorn\nhook\nhotlips\ndynamo\nklaus\nkittie\nkappa\nkahlua\nmuffy\nmizzou\nmohamed\nmusical\nwannabe\nwednesda\nwhatup\nweller\nwaterfal\nwilly1\ninvest\nblanche\nbear1\nbillabon\nyouknow\nzelda\nyyyyyy1\nzachary1\n01234567\n070462\nzurich\nsuperstar\nstorms\ntail\nstiletto\nstrat\n427900\nsigmachi\nshelter\nshells\nsexy123\nsmile1\nsophie1\nstefano\nstayout\nsomerset\nsmithers\nplaymate\npinkfloyd\nphish1\npayday\nthebear\ntelefon\nlaetitia\nkswbdu\nlarson\njetta\njerky\nmelina\nmetro\nrevoluti\nretire\nrespect\n1216\n1201\n1204\n1222\n1115\narchange\nbarry1\nhandball\n676767\nchandra\nchewbacc\nflesh\nfurball\ngocubs\nfruit\nfullback\ngman\ngentle\ndunbar\ndewalt\ndominiqu\ndiver1\ndhip6a\nolemiss\nollie\nmandrake\nmangos\npretzel\npusssy\ntripleh\nvaldez\nvagabond\nclean\ncomment\ncrew\nclovis\ndeaths\ndandan\ncsfbr5yy\ndeadspin\ndarrel\nninguna\nnoah\nncc74656\nbootsie\nbp2002\nbourbon\nbrennan\nbumble\nbooks\nhose\nheyyou\nhouston1\nhemlock\nhippo\nhornets\nhurricane\nhorseman\nhogan\nexcess\nextensa\nmuffin1\nvirginie\nwerdna\nidontknow\ninfo\niron\njack1\n1bitch\n151nxjmt\nbendover\nbmwbmw\nbills\nzaq123\nwxcvbn\nsurprise\nsupernov\ntahoe\ntalbot\nsimona\nshakur\nsexyone\nseviyi\nsonja\nsmart1\nspeed1\npepito\nphantom1\nplayoffs\nterry1\nterrier\nlaser1\nlite\nlancia\njohngalt\njenjen\njolene\nmidori\nmessage\nmaserati\nmatteo\nmental\nmiami1\nriffraff\nronald1\nreason\nrhythm\n1218\n1026\n123987\n1015\n1103\narmada\narchitec\naustria\ngotmilk\nhawkins\ngray\ncamila\ncamp\ncambridg\ncharge\ncamero\nflex\nforeplay\ngetoff\nglacier\nglotest\nfroggie\ngerbil\nrugger\nsanity72\nsalesman\ndonna1\ndreaming\ndeutsch\norchard\noyster\npalmtree\nophelia\npajero\nm5wkqf\nmagenta\nluckyone\ntreefrog\nvantage\nusmarine\ntyvugq\nuptown\nabacab\naaaaaa1\nadvance\nchuck1\ndelmar\ndarkange\ncyclones\nnate\nnavajo\nnope\nborder\nbubba123\nbuilding\niawgk2\nhrfzlz\ndylan1\nenrico\nencore\nemilio\neclipse1\nkillian\nkayleigh\nmutant\nmizuno\nmustang2\nvideo1\nviewer\nweed420\nwhales\njaguar1\ninsight\n1990\n159159\n1love\nbliss\nbears1\nbigtruck\nbinder\nbigboss\nblitz\nxqgann\nyeahyeah\nzeke\nzardoz\nstickman\ntable\n3825\nsignal\nsentra\nside\nshiva\nskipper1\nsingapor\nsouthpaw\nsonora\nsquid\nslamdunk\nslimjim\nplacid\nphoton\nplacebo\npearl1\ntest12\ntherock1\ntiger123\nleinad\nlegman\njeepers\njoeblow\nmccarthy\nmike23\nredcar\nrhinos\nrjw7x4\n1102\n13576479\n112211\nalcohol\ngwju3g\ngreywolf\n7bgiqk\n7878\n535353\n4snz9g\ncandyass\ncccccc1\ncarola\ncatfight\ncali\nfister\nfosters\nfinland\nfrankie1\ngizzmo\nfuller\nroyalty\nrugrat\nsandie\nrudolf\ndooley\ndive\ndoreen\ndodo\ndrop\noemdlg\nout3xf\npaddy\nopennow\npuppy1\nqazwsxedc\npregnant\nquinn\nramjet\nunder\nuncle\nabraxas\ncorner\ncreed\ncocoa\ncrown\ncows\ncn42qj\ndancer1\ndeath666\ndamned\nnudity\nnegative\nnimda2k\nbuick\nbobb\nbraves1\nbrook\nhenrik\nhigher\nhooligan\ndust\neverlast\nkarachi\nmortis\nmulligan\nmonies\nmotocros\nwally1\nweapon\nwaterman\nview\nwillie1\nvicki\ninspiron\n1test\n2929\nbigblack\nxytfu7\nyackwin\nzaq1xsw2\nyy5rbfsc\n100100\n0660\ntahiti\ntakehana\ntalks\n332211\n3535\nsedona\nseawolf\nskydiver\nshine\nspleen\nslash\nspjfet\nspecial1\nspooner\nslimshad\nsopranos\nspock1\npenis1\npatches1\nterri\nthierry\nthething\ntoohot\nlarge\nlimpone\njohnnie\nmash4077\nmatchbox\nmasterp\nmaxdog\nribbit\nreed\nrita\nrockin\nredhat\nrising\n1113\n14789632\n1331\nallday\naladin\nandrey\namethyst\nariel\nanytime\nbaseball1\nathome\nbasil\ngoofy1\ngreenman\ngustavo\ngoofball\nha8fyp\ngoodday\n778899\ncharon\nchappy\ncastillo\ncaracas\ncardiff\ncapitals\ncanada1\ncajun\ncatter\nfreddy1\nfavorite2\nfrazier\nforme\nfollow\nforsaken\nfeelgood\ngavin\ngfxqx686\ngarlic\nsarge\nsaskia\nsanjose\nruss\nsalsa\ndilbert1\ndukeduke\ndownhill\nlonghair\nloop\nlocutus\nlockdown\nmalachi\nmamacita\nlolipop\nrainyday\npumpkin1\npunker\nprospect\nrambo1\nrainbows\nquake\ntwin\ntrinity1\ntrooper1\naimee\ncitation\ncoolcat\ncrappy\ndefault\ndental\ndeniro\nd9ungl\ndaddys\nnapoli\nnautica\nnermal\nbukowski\nbrick\nbubbles1\nbogota\nboard\nbranch\nbreath\nbuds\nhulk\nhumphrey\nhitachi\nevans\nender\nexport\nkikiki\nkcchiefs\nkram\nmorticia\nmontrose\nmongo\nwaqw3p\nwizzard\nvisited\nwhdbtp\nwhkzyc\nimage\n154ugeiu\n1fuck\nbinky\nblind\nbigred1\nblubber\nbenz\nbecky1\nyear2005\nwonderfu\nwooden\nxrated\n0001\ntampabay\nsurvey\ntammy1\nstuffer\n3mpz4r\n3000\n3some\nselina\nsierra1\nshampoo\nsilk\nshyshy\nslapnuts\nstandby\nspartan1\nsprocket\nsometime\nstanley1\npoker1\nplus\nthought\ntheshit\ntorture\nthinking\nlavalamp\nlight1\nlaserjet\njediknig\njjjjj1\njocelyn\nmazda626\nmenthol\nmaximo\nmargaux\nmedic1\nrelease\nrichter\nrhino1\nroach\nrenate\nrepair\nreveal\n1209\n1234321\namigos\napricot\nalexandra\nasdfgh1\nhairball\nhatter\ngraduate\ngrimace\n7xm5rq\n6789\ncartoons\ncapcom\ncheesy\ncashflow\ncarrots\ncamping\nfanatic\nfool\nformat\nfleming\ngirlie\nglover\ngilmore\ngardner\nsafeway\nruthie\ndogfart\ndondon\ndiapers\noutsider\nodin\nopiate\nlollol\nlove12\nloomis\nmallrats\nprague\nprimetime21\npugsley\nprogram\nr29hqq\ntouch\nvalleywa\nairman\nabcdefg1\ndarkone\ncummer\ndempsey\ndamn\nnadia\nnatedogg\nnineball\nndeyl5\nnatchez\nnewone\nnormandy\nnicetits\nbuddy123\nbuddys\nhomely\nhusky\niceland\nhr3ytm\nhighlife\nholla\nearthlin\nexeter\neatmenow\nkimkim\nkarine\nk2trix\nkernel\nkirkland\nmoney123\nmoonman\nmiles1\nmufasa\nmousey\nwilma\nwilhelm\nwhites\nwarhamme\ninstinct\njackass1\n2277\n20spanks\nblobby\nblair\nblinky\nbikers\nblackjack\nbecca\nblue23\nxman\nwyvern\n085tzzqi\nzxzxzx\nzsmj2v\nsuede\nt26gn4\nsugars\nsylvie\ntantra\nswoosh\nswiss\n4226\n4271\n321123\n383pdjvl\nshoe\nshane1\nshelby1\nspades\nspain\nsmother\nsoup\nsparhawk\npisser\nphoto1\npebble\nphones\npeavey\npicnic\npavement\nterra\nthistle\ntokyo\ntherapy\nlives\nlinden\nkronos\nlilbit\nlinux\njohnston\nmaterial\nmelanie1\nmarbles\nredlight\nreno\nrecall\n1208\n1138\n1008\nalchemy\naolsucks\nalexalex\natticus\nauditt\nballet\nb929ezzh\ngoodyear\nhanna\ngriffith\ngubber\n863abgsg\n7474\n797979\n464646\n543210\n4zqauf\n4949\nch5nmk\ncarlito\nchewey\ncarebear\ncaleb\ncheckmat\ncheddar\nchachi\nfever\nforgetit\nfine\nforlife\ngiants1\ngates\ngetit\ngamble\ngerhard\ngalileo\ng3ujwg\nganja\nrufus1\nrushmore\nscouts\ndiscus\ndudeman\nolympus\noscars\nosprey\nmadcow\nlocust\nloyola\nmammoth\nproton\nrabbit1\nquestion\nptfe3xxp\npwxd5x\npurple1\npunkass\nprophecy\nuyxnyd\ntyson1\naircraft\naccess99\nabcabc\ncocktail\ncolts\ncivilwar\ncleveland\nclaudia1\ncontour\nclement\ndddddd1\ncypher\ndenied\ndapzu455\ndagmar\ndaisydog\nname\nnoles\nbutters\nbuford\nhoochie\nhotel\nhoser\neddy\nellis\neldiablo\nkingrich\nmudvayne\nmotown\nmp8o6d\nwife\nvipergts\nitaliano\ninnocent\n2055\n2211\nbeavers\nbloke\nblade1\nyamato\nzooropa\nyqlgr667\n050505\nzxcvbnm1\nzw6syj\nsuckcock\ntango1\nswing\nstern\nstephens\nswampy\nsusanna\ntammie\n445566\n333666\n380zliki\nsexpot\nsexylady\nsixtynin\nsickboy\nspiffy\nsleeping\nskylark\nsparkles\nslam\npintail\nphreak\nplaces\nteller\ntimtim\ntires\nthighs\nleft\nlatex\nllamas\nletsdoit\nlkjhg\nlandmark\nletters\nlizzard\nmarlins\nmarauder\nmetal1\nmanu\nregister\nrighton\n1127\nalain\nalcat\namigo\nbasebal1\nazertyui\nattract\nazrael\nhamper\ngotenks\ngolfgti\ngutter\nhawkwind\nh2slca\nharman\ngrace1\n6chid8\n789654\ncanine\ncasio\ncazzo\nchamber\ncbr900\ncabrio\ncalypso\ncapetown\nfeline\nflathead\nfisherma\nflipmode\nfungus\ngoal\ng9zns4\nfull\ngiggle\ngabriel1\nfuck123\nsaffron\ndogmeat\ndreamcas\ndirtydog\ndunlop\ndouche\ndresden\ndickdick\ndestiny1\npappy\noaktree\nlydia\nluft4\nputa\nprayer\nramada\ntrumpet1\nvcradq\ntulip\ntracy71\ntycoon\naaaaaaa1\nconquest\nclick\nchitown\ncorps\ncreepers\nconstant\ncouples\ncode\ncornhole\ndanman\ndada\ndensity\nd9ebk7\ncummins\ndarth\ncute\nnash\nnirvana1\nnixon\nnorbert\nnestle\nbrenda1\nbonanza\nbundy\nbuddies\nhotspur\nheavy\nhorror\nhufmqw\nelectro\nerasure\nenough\nelisabet\netvww4\newyuza\neric1\nkinder\nkenken\nkismet\nklaatu\nmusician\nmilamber\nwilli\nwaiting\nisacs155\nigor\n1million\n1letmein\nx35v8l\nyogi\nywvxpz\nxngwoj\nzippy1\n020202\n****\nstonewal\nsweeney\nstory\nsentry\nsexsexsex\nspence\nsonysony\nsmirnoff\nstar12\nsolace\nsledge\nstates\nsnyder\nstar1\npaxton\npentagon\npkxe62\npilot1\npommes\npaulpaul\nplants\ntical\ntictac\ntoes\nlighthou\nlemans\nkubrick\nletmein22\nletmesee\njys6wz\njonesy\njjjjjj1\njigga\njoelle\nmate\nmerchant\nredstorm\nriley1\nrosa\nrelief\n14141414\n1126\nallison1\nbadboy1\nasthma\nauggie\nbasement\nhartley\nhartford\nhardwood\ngumbo\n616913\n57np39\n56qhxs\n4mnveh\ncake\nforbes\nfatluvr69\nfqkw5m\nfidelity\nfeathers\nfresno\ngodiva\ngecko\ngladys\ngibson1\ngogators\nfridge\ngeneral1\nsaxman\nrowing\nsammys\nscotts\nscout1\nsasasa\nsamoht\ndragon69\nducky\ndragonball\ndriller\np3wqaw\nnurse\npapillon\noneone\nopenit\noptimist\nlongshot\nportia\nrapier\npussy2\nralphie\ntuxedo\nulrike\nundertow\ntrenton\ncopenhag\ncome\ndelldell\nculinary\ndeltas\nmytime\nnicky\nnickie\nnoname\nnoles1\nbucker\nbopper\nbullock\nburnout\nbryce\nhedges\nibilltes\nhihje863\nhitter\nekim\nespana\neatme69\nelpaso\nenvelope\nexpress1\neeeeee1\neatme1\nkaraoke\nkara\nmustang5\nmisses\nwellingt\nwillem\nwaterski\nwebcam\njasons\ninfinite\niloveyou!\njakarta\nbelair\nbigdad\nbeerme\nyoshi\nyinyang\nzimmer\nx24ik3\n063dyjuy\n0000007\nztmfcq\nstopit\nstooges\nsurvival\nstockton\nsymow8\nstrato\n2hot4u\nship\nsimons\nskins\nshakes\nsex1\nshield\nsnacks\nsofttail\nslimed123\npizzaman\npipe\npitt\npathetic\npinto\ntigercat\ntonton\nlager\nlizzy\njuju\njohn123\njennings\njosiah\njesse1\njordon\njingles\nmartian\nmario1\nrootedit\nrochard\nredwine\nrequiem\nriverrat\nrats\n1117\n1014\n1205\nalthea\nallie\namor\namiga\nalpina\nalert\natreides\nbanana1\nbahamut\nhart\ngolfman\nhappines\n7uftyx\n5432\n5353\n5151\n4747\nbyron\nchatham\nchadwick\ncherie\nfoxfire\nffvdj474\nfreaked\nforeskin\ngayboy\ngggggg1\nglenda\ngameover\nglitter\nfunny1\nscoobydoo\nscroll\nrudolph\nsaddle\nsaxophon\ndingbat\ndigimon\nomicron\nparsons\nohio\npanda1\nloloxx\nmacintos\nlululu\nlollypop\nracer1\nqueen1\nqwertzui\nprick\nupnfmc\ntyrant\ntrout1\n9skw5g\naceman\nadelaide\nacls2h\naaabbb\nacapulco\naggie\ncomcast\ncraft\ncrissy\ncloudy\ncq2kph\ncuster\nd6o8pm\ncybersex\ndavecole\ndarian\ncrumbs\ndaisey\ndavedave\ndasani\nneedle\nmzepab\nmyporn\nnarnia\nnineteen\nbooger1\nbravo1\nbudgie\nbtnjey\nhighlander\nhotel6\nhumbug\nedwin\newtosi\nkristin1\nkobe\nknuckles\nkeith1\nkatarina\nmuff\nmuschi\nmontana1\nwingchun\nwiggle\nwhatthe\nwalking\nwatching\nvette1\nvols\nvirago\nintj3a\nishmael\nintern\njachin\nillmatic\n199999\n2010\nbeck\nblender\nbigpenis\nbengal\nblue1234\nyour\nzaqxsw\nxray\nxxxxxxx1\nzebras\nyanks\nworlds\ntadpole\nstripes\nsvetlana\n3737\n4343\n3728\n4444444\n368ejhih\nsolar\nsonne\nsmalls\nsniffer\nsonata\nsquirts\npitcher\nplaystation\npktmxr\npescator\npoints\ntexaco\nlesbos\nlilian\nl8v53x\njo9k2jw2\njimbeam\njosie\njimi\njupiter2\njurassic\nmarines1\nmaya\nrocket1\nringer\n14725836\n12345679\n1219\n123098\n1233\nalessand\nalthor\nangelika\narch\narmando\nalpha123\nbasher\nbarefeet\nbalboa\nbbbbb1\nbanks\nbadabing\nharriet\ngopack\ngolfnut\ngsxr1000\ngregory1\n766rglqy\n8520\n753159\n8dihc6\n69camaro\n666777\ncheeba\nchino\ncalendar\ncheeky\ncamel1\nfishcake\nfalling\nflubber\ngiuseppe\ngianni\ngloves\ngnasher23\nfrisbee\nfuzzy1\nfuzzball\nsauce\nsave13tx\nschatz\nrussell1\nsandra1\nscrotum\nscumbag\nsabre\nsamdog\ndripping\ndragon12\ndragster\npaige\norwell\nmainland\nlunatic\nlonnie\nlotion\nmaine\nmaddux\nqn632o\npoophead\nrapper\nporn4life\nproducer\nrapunzel\ntracks\nvelocity\nvanessa1\nulrich\ntrueblue\nvampire1\nabacus\n902100\ncrispy\ncorky\ncrane\nchooch\nd6wnro\ncutie\ndeal\ndabulls\ndehpye\nnavyseal\nnjqcw4\nnownow\nnigger1\nnightowl\nnonenone\nnightmar\nbustle\nbuddy2\nboingo\nbugman\nbulletin\nbosshog\nbowie\nhybrid\nhillside\nhilltop\nhotlegs\nhonesty\nhzze929b\nhhhhh1\nhellohel\neloise\nevilone\nedgewise\ne5pftu\neded\nembalmer\nexcalibur\nelefant\nkenzie\nkarl\nkarin\nkillah\nkleenex\nmouses\nmounta1n\nmotors\nmutley\nmuffdive\nvivitron\nwinfield\nwednesday\nw00t88\niloveit\njarjar\nincest\nindycar\n17171717\n1664\n17011701\n222777\n2663\nbeelch\nbenben\nyitbos\nyyyyy1\nyasmin\nzapata\nzzzzz1\nstooge\ntangerin\ntaztaz\nstewart1\nsummer69\nsweetness\nsystem1\nsurveyor\nstirling\n3qvqod\n3way\n456321\nsizzle\nsimhrq\nshrink\nshawnee\nsomeday\nsparty\nssptx452\nsphere\nspark\nslammed\nsober\npersian\npeppers\nploppy\npn5jvw\npoobear\npianos\nplaster\ntestme\ntiff\nthriller\nlarissa\nlennox\njewell\nmaster12\nmessier\nrockey\n1229\n1217\n1478\n1009\nanastasi\nalmighty\namonra\naragon\nargentin\nalbino\nazazel\ngrinder\n6uldv8\n83y6pv\n8888888\n4tlved\n515051\ncarsten\nchanges\nflanders\nflyers88\nffffff1\nfirehawk\nforeman\nfiredog\nflashman\nggggg1\ngerber\ngodspeed\ngalway\ngiveitup\nfuntimes\ngohan\ngiveme\ngeryfe\nfrenchie\nsayang\nrudeboy\nsavanna\nsandals\ndevine\ndougal\ndrag0n\ndga9la\ndisaster\ndesktop\nonly\nonlyone\notter\npandas\nmafia\nlombard\nluckys\nlovejoy\nlovelife\nmanders\nproduct\nqqh92r\nqcmfd454\npork\nradar1\npunani\nptbdhw\nturtles\nundertaker\ntrs8f7\ntramp\nugejvp\nabba\n911turbo\nacdc\nabcd123\nclever\ncorina\ncristian\ncreate\ncrash1\ncolony\ncrosby\ndelboy\ndaniele\ndavinci\ndaughter\nnotebook\nniki\nnitrox\nborabora\nbonzai\nbudd\nbrisbane\nhotter\nheeled\nheroes\nhooyah\nhotgirl\ni62gbq\nhorse1\nhills\nhpk2qc\nepvjb6\necho\nkorean\nkristie\nmnbvc\nmohammad\nmind\nmommy1\nmunster\nwade\nwiccan\nwanted\njacket\n2369\nbettyboo\nblondy\nbismark\nbeanbag\nbjhgfi\nblackice\nyvtte545\nynot\nyess\nzlzfrh\nwolvie\n007bond\n******\ntailgate\ntanya1\nsxhq65\nstinky1\n3234412\n3ki42x\nseville\nshimmer\nsheryl\nsienna\nshitshit\nskillet\nseaman\nsooners1\nsolaris\nsmartass\npastor\npasta\npedros\npennywis\npfloyd\ntobydog\nthetruth\nlethal\nletme1n\nleland\njenifer\nmario66\nmicky\nrocky2\nrewq\nripped\nreindeer\n1128\n1207\n1104\n1432\naprilia\nallstate\nalyson\nbagels\nbasic\nbaggies\nbarb\nbarrage\ngreatest\ngomez\nguru\nguard\n72d5tn\n606060\n4wcqjn\ncaldwell\nchance1\ncatalog\nfaust\nfilm\nflange\nfran\nfartman\ngeil\ngbhcf2\nfussball\nglen\nfuaqz4\ngameboy\ngarnet\ngeneviev\nrotary\nseahawk\nrussel\nsaab\nseal\nsamadams\ndevlt4\nditto\ndrevil\ndrinker\ndeuce\ndipstick\ndonut\noctopus\nottawa\nlosangel\nloverman\nporky\nq9umoz\nrapture\npump\npussy4me\nuniversity\ntriplex\nue8fpw\ntrent\ntrophy\nturbos\ntroubles\nagent\naaa340\nchurchil\ncrazyman\nconsult\ncreepy\ncraven\nclass\ncutiepie\nddddd1\ndejavu\ncuxldv\nnettie\nnbvibt\nnikon\nniko\nnorwood\nnascar1\nnolan\nbubba2\nboobear\nboogers\nbuff\nbullwink\nbully\nbulldawg\nhorsemen\nescalade\neditor\neagle2\ndynamic\nella\nefyreg\nedition\nkidney\nminnesot\nmogwai\nmorrow\nmsnxbi\nmoonlight\nmwq6qlzo\nwars\nwerder\nverygood\nvoodoo1\nwheel\niiiiii1\n159951\n1624\n1911a1\n2244\nbellagio\nbedlam\nbelkin\nbill1\nwoodrow\nxirt2k\nworship\n??????\ntanaka\nswift\nsusieq\nsundown\nsukebe\ntales\nswifty\n2fast4u\nsenate\nsexe\nsickness\nshroom\nshaun\nseaweed\nskeeter1\nstatus\nsnicker\nsorrow\nspanky1\nspook\npatti\nphaedrus\npilots\npinch\npeddler\ntheo\nthumper1\ntessie\ntiger7\ntmjxn151\nthematri\nl2g7k3\nletmeinn\nlazy\njeffjeff\njoan\njohnmish\nmantra\nmariana\nmike69\nmarshal\nmart\nmazda6\nriptide\nrobots\nrental\n1107\n1130\n142857\n11001001\n1134\narmored\nalvin\nalec\nallnight\nalright\namatuers\nbartok\nattorney\nastral\nbaboon\nbahamas\nballs1\nbassoon\nhcleeb\nhappyman\ngranite\ngraywolf\ngolf1\ngomets\n8vjzus\n7890\n789123\n8uiazp\n5757\n474jdvff\n551scasi\n50cent\ncamaro1\ncherry1\nchemist\nfinal\nfirenze\nfishtank\nfarrell\nfreewill\nglendale\nfrogfrog\ngerhardt\nganesh\nsame\nscirocco\ndevilman\ndoodles\ndinger\nokinawa\nolympic\nnursing\norpheus\nohmygod\npaisley\npallmall\nnull\nlounge\nlunchbox\nmanhatta\nmahalo\nmandarin\nqwqwqw\nqguvyt\npxx3eftp\npresident\nrambler\npuzzle\npoppy1\nturk182\ntrotter\nvdlxuc\ntrish\ntugboat\nvaliant\ntracie\nuwrl7c\nchris123\ncoaster\ncmfnpu\ndecimal\ndebbie1\ndandy\ndaedalus\ndede\nnatasha1\nnissan1\nnancy123\nnevermin\nnapalm\nnewcastle\nboats\nbranden\nbritt\nbonghit\nhester\nibxnsm\nhhhhhh1\nholger\ndurham\nedmonton\nerwin\nequinox\ndvader\nkimmy\nknulla\nmustafa\nmonsoon\nmistral\nmorgana\nmonica1\nmojave\nmonth\nmonterey\nmrbill\nvkaxcs\nvictor1\nwacker\nwendell\nviolator\nvfdhif\nwilson1\nwavpzt\nverena\nwildstar\nwinter99\niqzzt580\njarrod\nimback\n1914\n19741974\n1monkey\n1q2w3e4r5t\n2500\n2255\nblank\nbigshow\nbigbucks\nblackcoc\nzoomer\nwtcacq\nwobble\nxmen\nxjznq5\nyesterda\nyhwnqc\nzzzxxx\nstreak\n393939\n2fchbg\nskinhead\nskilled\nshakira\nshaft\nshadow12\nseaside\nsigrid\nsinful\nsilicon\nsmk7366\nsnapshot\nsniper1\nsoccer11\nstaff\nslap\nsmutty\npeepers\npleasant\nplokij\npdiddy\npimpdaddy\nthrust\nterran\ntopaz\ntoday1\nlionhear\nlittlema\nlauren1\nlincoln1\nlgnu9d\nlaughing\njuneau\nmethos\nmedina\nmerlyn\nrogue1\nromulus\nredshift\n1202\n1469\n12locked\narizona1\nalfarome\nal9agd\naol123\naltec\napollo1\narse\nbaker1\nbbb747\nbach\naxeman\nastro1\nhawthorn\ngoodfell\nhawks1\ngstring\nhannes\n8543852\n868686\n4ng62t\n554uzpad\n5401\n567890\n5232\ncatfood\nframe\nflow\nfire1\nflipflop\nfffff1\nfozzie\nfluff\ngarrison\nfzappa\nfurious\nround\nrustydog\nsandberg\nscarab\nsatin\nruger\nsamsung1\ndestin\ndiablo2\ndreamer1\ndetectiv\ndominick\ndoqvq3\ndrywall\npaladin1\npapabear\noffroad\npanasonic\nnyyankee\nluetdi\nqcfmtz\npyf8ah\npuddles\nprivacy\nrainer\npussyeat\nralph1\nprinceto\ntrivia\ntrewq\ntri5a3\nadvent\n9898\nagyvorc\nclarkie\ncoach1\ncourier\ncontest\nchristo\ncorinna\nchowder\nconcept\nclimbing\ncyzkhw\ndavidb\ndad2ownu\ndays\ndaredevi\nde7mdf\nnose\nnecklace\nnazgul\nbooboo1\nbroad\nbonzo\nbrenna\nboot\nbutch1\nhuskers1\nhgfdsa\nhornyman\nelmer\nelektra\nengland1\nelodie\nkermit1\nknife\nkaboom\nminute\nmodern\nmotherfucker\nmorten\nmocha\nmonday1\nmorgoth\nward\nweewee\nweenie\nwalters\nvorlon\nwebsite\nwahoo\nilovegod\ninsider\njayman\n1911\n1dallas\n1900\n1ranger\n201jedlz\n2501\n1qaz\nbertram\nbignuts\nbigbad\nbeebee\nbillows\nbelize\nbebe\nwvj5np\nwu4etd\nyamaha1\nwrinkle5\nzebra1\nyankee1\nzoomzoom\n09876543\n0311\n?????\nstjabn\ntainted\n3tmnej\nshoot\nskooter\nskelter\nsixteen\nstarlite\nsmack\nspice1\nstacey1\nsmithy\nperrin\npollux\npeternorth\npixie\npaulina\npiston\npick\npoets\npine\ntoons\ntooth\ntopspin\nkugm7b\nlegends\njeepjeep\njuliana\njoystick\njunkmail\njojojojo\njonboy\njudge\nmidland\nmeteor\nmccabe\nmatter\nmayfair\nmeeting\nmerrill\nraul\nriches\nreznor\nrockrock\nreboot\nreject\nrobyn\nrenee1\nroadway\nrasta220\n1411\n1478963\n1019\narchery\nallman\nandyandy\nbarks\nbagpuss\nauckland\ngooseman\nhazmat\ngucci\nguns\ngrammy\nhappydog\ngreek\n7kbe9d\n7676\n6bjvpe\n5lyedn\n5858\n5291\ncharlie2\nchas\nc7lrwu\ncandys\nchateau\nccccc1\ncardinals\nfear\nfihdfv\nfortune12\ngocats\ngaelic\nfwsadn\ngodboy\ngldmeo\nfx3tuo\nfubar1\ngarland\ngenerals\ngforce\nrxmtkp\nrulz\nsairam\ndunhill\ndivision\ndogggg\ndetect\ndetails\ndoll\ndrinks\nozlq6qwm\nov3ajy\nlockout\nmakayla\nmacgyver\nmallorca\nloves\nprima\npvjegu\nqhxbij\nraphael\nprelude1\ntotoro\ntusymo\ntrousers\ntunnel\nvaleria\ntulane\nturtle1\ntracy1\naerosmit\nabbey1\naddress\nclticic\nclueless\ncooper1\ncomets\ncollect\ncorbin\ndelpiero\nderick\ncyprus\ndante1\ndave1\nnounours\nneal\nnexus6\nnero\nnogard\nnorfolk\nbrent1\nbooyah\nbootleg\nbuckaroo\nbulls23\nbulls1\nbooper\nheretic\nicecube\nhellno\nhounds\nhoneydew\nhooters1\nhoes\nhowie\nhevnm4\nhugohugo\neighty\nepson\nevangeli\neeeee1\neyphed".split("\n");

/* ===================== QR ENCODER (byte mode, versions 1-10, ECC L/M/Q/H) =====================
   Structure follows the public QR spec (ISO/IEC 18004); verified module-for-module against `segno` in tools/test_qr.py.
   Own implementation so the file needs no CDN. */
var QR = (function () {
  var ECCW = { L: [-1, 7, 10, 15, 20, 26, 18, 20, 24, 30, 18], M: [-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26], Q: [-1, 13, 22, 18, 26, 18, 24, 18, 22, 20, 24], H: [-1, 17, 28, 22, 16, 22, 28, 26, 26, 24, 28] };
  var NBLK = { L: [-1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4], M: [-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5], Q: [-1, 1, 1, 2, 2, 4, 4, 6, 6, 8, 8], H: [-1, 1, 1, 2, 4, 4, 4, 5, 6, 8, 8] };
  var FMT = { L: 1, M: 0, Q: 3, H: 2 };
  function rawModules(v) { var r = (16 * v + 128) * v + 64; if (v >= 2) { var n = Math.floor(v / 7) + 2; r -= (25 * n - 10) * n - 55; if (v >= 7) r -= 36; } return r; }
  function dataCw(v, e) { return Math.floor(rawModules(v) / 8) - ECCW[e][v] * NBLK[e][v]; }
  function alignPos(v) {
    if (v === 1) return [];
    var n = Math.floor(v / 7) + 2, step = Math.ceil((v * 4 + 4) / (n * 2 - 2)) * 2, size = v * 4 + 17, res = [6];
    for (var pos = size - 7; res.length < n; pos -= step) res.splice(1, 0, pos);
    return res;
  }
  function gfMul(x, y) { var z = 0; for (var i = 7; i >= 0; i--) { z = (z << 1) ^ ((z >>> 7) * 0x11D); z ^= ((y >>> i) & 1) * x; } return z; }
  function rsDivisor(deg) {
    var res = []; for (var i = 0; i < deg - 1; i++) res.push(0); res.push(1);
    var root = 1;
    for (i = 0; i < deg; i++) { for (var j = 0; j < res.length; j++) { res[j] = gfMul(res[j], root); if (j + 1 < res.length) res[j] ^= res[j + 1]; } root = gfMul(root, 2); }
    return res;
  }
  function rsRem(data, div) {
    var res = div.map(function () { return 0; });
    data.forEach(function (b) { var f = b ^ res.shift(); res.push(0); div.forEach(function (c, i) { res[i] ^= gfMul(c, f); }); });
    return res;
  }
  function bit(x, i) { return ((x >>> i) & 1) !== 0; }

  function encode(text, ecc, forceMask) {
    ecc = ecc || 'M';
    var bytes = Array.prototype.slice.call(new TextEncoder().encode(text)), v, capBits;
    for (v = 1; v <= 10; v++) { capBits = dataCw(v, ecc) * 8; var ccb = v <= 9 ? 8 : 16; if (4 + ccb + bytes.length * 8 <= capBits) break; }
    if (v > 10) throw new Error('Text too long for built-in QR (max ~150 bytes at ECC ' + ecc + ')');
    var bits = [];
    function put(val, n) { for (var i = n - 1; i >= 0; i--) bits.push((val >>> i) & 1); }
    put(4, 4); put(bytes.length, v <= 9 ? 8 : 16); bytes.forEach(function (b) { put(b, 8); });
    put(0, Math.min(4, capBits - bits.length)); put(0, (8 - bits.length % 8) % 8);
    for (var pad = 0xEC; bits.length < capBits; pad ^= 0xEC ^ 0x11) put(pad, 8);
    var data = []; for (var i = 0; i < bits.length; i += 8) { var b = 0; for (var k = 0; k < 8; k++) b = (b << 1) | bits[i + k]; data.push(b); }
    /* ECC + interleave */
    var nb = NBLK[ecc][v], eccLen = ECCW[ecc][v], raw = Math.floor(rawModules(v) / 8), nShort = nb - raw % nb, shortLen = Math.floor(raw / nb);
    var blocks = [], div = rsDivisor(eccLen), kk = 0;
    for (i = 0; i < nb; i++) {
      var dat = data.slice(kk, kk + shortLen - eccLen + (i < nShort ? 0 : 1)); kk += dat.length;
      var er = rsRem(dat, div); if (i < nShort) dat.push(0); blocks.push(dat.concat(er));
    }
    var all = [];
    for (i = 0; i < blocks[0].length; i++) blocks.forEach(function (bl, j) { if (i !== shortLen - eccLen || j >= nShort) all.push(bl[i]); });
    /* matrix */
    var size = v * 4 + 17, M = [], F = [];
    for (i = 0; i < size; i++) { M.push(new Array(size).fill(false)); F.push(new Array(size).fill(false)); }
    function set(x, y, d) { M[y][x] = d; F[y][x] = true; }
    for (i = 0; i < size; i++) { set(6, i, i % 2 === 0); set(i, 6, i % 2 === 0); }
    function finder(cx, cy) { for (var dy = -4; dy <= 4; dy++) for (var dx = -4; dx <= 4; dx++) { var d = Math.max(Math.abs(dx), Math.abs(dy)), x = cx + dx, y = cy + dy; if (x >= 0 && x < size && y >= 0 && y < size) set(x, y, d !== 2 && d !== 4); } }
    finder(3, 3); finder(size - 4, 3); finder(3, size - 4);
    var ap = alignPos(v), na = ap.length;
    for (i = 0; i < na; i++) for (var j = 0; j < na; j++) {
      if ((i === 0 && j === 0) || (i === 0 && j === na - 1) || (i === na - 1 && j === 0)) continue;
      for (var dy = -2; dy <= 2; dy++) for (var dx = -2; dx <= 2; dx++) set(ap[i] + dx, ap[j] + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1);
    }
    function drawFormat(mask) {
      var d = (FMT[ecc] << 3) | mask, rem = d;
      for (var q = 0; q < 10; q++) rem = (rem << 1) ^ ((rem >>> 9) * 0x537);
      var fb = ((d << 10) | rem) ^ 0x5412;
      for (q = 0; q <= 5; q++) set(8, q, bit(fb, q)); set(8, 7, bit(fb, 6)); set(8, 8, bit(fb, 7)); set(7, 8, bit(fb, 8));
      for (q = 9; q < 15; q++) set(14 - q, 8, bit(fb, q));
      for (q = 0; q < 8; q++) set(size - 1 - q, 8, bit(fb, q));
      for (q = 8; q < 15; q++) set(8, size - 15 + q, bit(fb, q));
      set(8, size - 8, true);
    }
    drawFormat(0);
    if (v >= 7) {
      var rem = v; for (i = 0; i < 12; i++) rem = (rem << 1) ^ ((rem >>> 11) * 0x1F25);
      var vb = (v << 12) | rem;
      for (i = 0; i < 18; i++) { var c = bit(vb, i), a = size - 11 + i % 3, b2 = Math.floor(i / 3); set(a, b2, c); set(b2, a, c); }
    }
    /* codewords, zigzag */
    var bi = 0;
    for (var right = size - 1; right >= 1; right -= 2) {
      if (right === 6) right = 5;
      for (var vert = 0; vert < size; vert++) for (j = 0; j < 2; j++) {
        var x = right - j, up = ((right + 1) & 2) === 0, y = up ? size - 1 - vert : vert;
        if (!F[y][x] && bi < all.length * 8) { M[y][x] = bit(all[bi >>> 3], 7 - (bi & 7)); bi++; }
      }
    }
    function applyMask(m) {
      for (var y = 0; y < size; y++) for (var x = 0; x < size; x++) {
        var inv; switch (m) {
          case 0: inv = (x + y) % 2 === 0; break; case 1: inv = y % 2 === 0; break; case 2: inv = x % 3 === 0; break; case 3: inv = (x + y) % 3 === 0; break;
          case 4: inv = (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0; break; case 5: inv = x * y % 2 + x * y % 3 === 0; break;
          case 6: inv = (x * y % 2 + x * y % 3) % 2 === 0; break; default: inv = ((x + y) % 2 + x * y % 3) % 2 === 0;
        }
        if (!F[y][x] && inv) M[y][x] = !M[y][x];
      }
    }
    function penalty() {
      var p = 0, y, x, run, k;
      for (y = 0; y < size; y++) for (var dir = 0; dir < 2; dir++) {
        run = 1; for (x = 1; x < size; x++) { var cur = dir ? M[x][y] : M[y][x], prev = dir ? M[x - 1][y] : M[y][x - 1]; if (cur === prev) { run++; if (run === 5) p += 3; else if (run > 5) p++; } else run = 1; }
      }
      for (y = 0; y < size - 1; y++) for (x = 0; x < size - 1; x++) { var c0 = M[y][x]; if (c0 === M[y][x + 1] && c0 === M[y + 1][x] && c0 === M[y + 1][x + 1]) p += 3; }
      var pat = [true, false, true, true, true, false, true, false, false, false, false], pat2 = pat.slice().reverse();
      for (y = 0; y < size; y++) for (x = 0; x <= size - 11; x++) for (var d2 = 0; d2 < 2; d2++) {
        var m1 = true, m2 = true; for (k = 0; k < 11; k++) { var val = d2 ? M[x + k][y] : M[y][x + k]; if (val !== pat[k]) m1 = false; if (val !== pat2[k]) m2 = false; } if (m1) p += 40; if (m2) p += 40;
      }
      var dark = 0; M.forEach(function (r) { r.forEach(function (c) { if (c) dark++; }); });
      p += Math.floor(Math.abs(dark * 20 - size * size * 10) / (size * size)) * 10;   /* approx of rule 4 */
      return p;
    }
    var best = forceMask, bestP = Infinity;
    if (best == null) for (var m = 0; m < 8; m++) { applyMask(m); drawFormat(m); var pp = penalty(); if (pp < bestP) { best = m; bestP = pp; } applyMask(m); }
    applyMask(best); drawFormat(best);
    return { size: size, modules: M, version: v, mask: best, ecc: ecc };
  }
  function toCanvas(canvas, qr, scale, border) {
    scale = scale || 6; border = border == null ? 4 : border;
    var n = qr.size + border * 2; canvas.width = canvas.height = n * scale;
    var ctx = canvas.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, canvas.width, canvas.height); ctx.fillStyle = '#000';
    for (var y = 0; y < qr.size; y++) for (var x = 0; x < qr.size; x++) if (qr.modules[y][x]) ctx.fillRect((x + border) * scale, (y + border) * scale, scale, scale);
  }
  return { encode: encode, toCanvas: toCanvas, dataCw: dataCw };
})();
if (typeof module !== 'undefined') module.exports = QR;

/* ===================== PATTERN LOCK LOGIC (no DOM) =====================
   Android-style rules: n x n grid, connect >= 4 dots, no dot used twice, and a line may not jump over an
   unvisited dot (a dot lying exactly on the segment is added automatically, as on Android).
   COUNTS = number of valid patterns with >= 4 dots. 3x3 and 4x4 are EXACT (dynamic programming, re-verified by tools/test_pattern.mjs);
   5x5 and 6x6 are too large to enumerate and are sampling ESTIMATES (Knuth random-path estimator, standard error <= 0.1%, see tools/pattern_count.mjs). */
var PAT = (function () {
  var MIN = 4, MAXN = 6;
  var COUNTS = { 3: 389112, 4: 4350069823024, 5: 2.361e23, 6: 1.039e34 };
  var EXACT = { 3: true, 4: true, 5: false, 6: false };
  var SYMS = '123456789abcdefghijklmnopqrstuvwxyzA';
  function gcd(a, b) { while (b) { var t = a % b; a = b; b = t; } return a; }
  function between(n, a, b) {
    var ar = Math.floor(a / n), ac = a % n, br = Math.floor(b / n), bc = b % n, dr = br - ar, dc = bc - ac, g = gcd(Math.abs(dr), Math.abs(dc)), r = [];
    for (var k = 1; k < g; k++) r.push((ar + dr / g * k) * n + ac + dc / g * k);
    return r;
  }
  function options(n, vis, last) {          /* nodes that can legally be connected next */
    var out = [];
    for (var b = 0; b < n * n; b++) {
      if (vis[b]) continue;
      var ok = true, m = between(n, last, b);
      for (var i = 0; i < m.length; i++) if (!vis[m[i]]) { ok = false; break; }
      if (ok) out.push(b);
    }
    return out;
  }
  function expand(n, seq) {                  /* user-hit nodes -> full path with auto-included in-between dots; null if a dot repeats */
    var path = [], vis = {};
    for (var i = 0; i < seq.length; i++) {
      var b = seq[i]; if (vis[b] || b < 0 || b >= n * n) return null;
      if (path.length) between(n, path[path.length - 1], b).forEach(function (m) { if (!vis[m]) { vis[m] = 1; path.push(m); } });
      vis[b] = 1; path.push(b);
    }
    return path;
  }
  function validate(n, path) {
    if (!path || path.length < MIN) return { ok: false, why: 'Too short: connect at least ' + MIN + ' dots.' };
    if (path.length > n * n) return { ok: false, why: 'Too long.' };
    var vis = {};
    for (var i = 0; i < path.length; i++) {
      var b = path[i]; if (b < 0 || b >= n * n || vis[b]) return { ok: false, why: 'A dot can only be used once.' };
      if (i) { var m = between(n, path[i - 1], b); for (var j = 0; j < m.length; j++) if (!vis[m[j]]) return { ok: false, why: 'A line cannot jump over an unused dot.' }; }
      vis[b] = 1;
    }
    return { ok: true };
  }
  function pathBits(n, path) {               /* information if every choice were uniform among legal moves: an UPPER bound for this path */
    var vis = {}, bits = Math.log2(n * n);
    vis[path[0]] = 1;
    for (var i = 1; i < path.length; i++) { bits += Math.log2(options(n, vis, path[i - 1]).length || 1); vis[path[i]] = 1; }
    return bits;
  }
  function limitBits(n) { return Math.log2(COUNTS[n]); }
  function toSymbols(path) { return path.map(function (i) { return SYMS[i]; }).join(''); }
  function parseSeq(n, str) {                /* "1-5-9-6" / "1596" (3x3) / "1,5,9,14" -> {path} or {error} */
    str = (str || '').trim(); if (!str) return null;
    var nums = (n <= 3 && /^\d+$/.test(str)) ? str.split('').map(Number) : str.split(/[^0-9]+/).filter(Boolean).map(Number);
    for (var i = 0; i < nums.length; i++) if (nums[i] < 1 || nums[i] > n * n) return { error: 'Dot numbers run from 1 to ' + n * n + ' on this grid.' };
    var path = expand(n, nums.map(function (x) { return x - 1; }));
    if (!path) return { error: 'A dot can only be used once.' };
    var v = validate(n, path); return v.ok ? { path: path } : { error: v.why };
  }
  /* analysis object shaped like analyze() so the rest of the app can use it; modelled at HALF the theoretical bits because
     people choose predictable patterns (an assumption, stated in the UI) */
  function analyze(n, path) {
    var ub = Math.min(pathBits(n, path), limitBits(n)), est = Math.max(1, Math.round(ub * 0.5 * 10) / 10);
    return { isPattern: true, grid: n, len: path.length, estBits: est, naiveBits: Math.round(ub * 10) / 10, theoBits: Math.round(limitBits(n) * 10) / 10, rank: 0, tokens: [], classes: {},
      weak: [{ id: 'patmax', sev: 'crit', msg: 'A ' + n + '×' + n + ' pattern can never exceed ' + (limitBits(n)).toFixed(1) + ' bits, even if drawn at random.' }, { id: 'pathuman', sev: 'warn', msg: 'Real patterns are predictable (favoured start dots and simple shapes), so the modelled strength is half the theoretical figure.' }].concat(path.length < 6 ? [{ id: 'patshort', sev: 'warn', msg: 'Short pattern (' + path.length + ' dots).' }] : []),
      label: est < 28 ? 'CRITICAL' : est < 40 ? 'WEAK' : est < 60 ? 'FAIR' : est < 80 ? 'GOOD' : 'STRONG', pct: Math.max(2, Math.min(100, Math.round(est / 1.28))) };
  }
  function exactCount(n) {                    /* DP over (visited mask, last dot): used by tests, practical for n <= 4 */
    var NN = n * n, size = 1 << NN, dp = new Float64Array(size * NN), total = 0, bm = [];
    for (var a = 0; a < NN; a++) { bm.push([]); for (var b = 0; b < NN; b++) bm[a].push(between(n, a, b).reduce(function (x, i) { return x | (1 << i); }, 0)); }
    for (var s = 0; s < NN; s++) dp[(1 << s) * NN + s] = 1;
    for (var mask = 1; mask < size; mask++) {
      var pc = 0, x = mask; while (x) { pc++; x &= x - 1; }
      for (var last = 0; last < NN; last++) {
        var v = dp[mask * NN + last]; if (!v) continue; if (pc >= MIN) total += v;
        for (var c = 0; c < NN; c++) { if (mask & (1 << c)) continue; var need = bm[last][c]; if ((need & mask) !== need) continue; dp[(mask | (1 << c)) * NN + c] += v; }
      }
    }
    return total;
  }
  return { MIN: MIN, MAXN: MAXN, COUNTS: COUNTS, EXACT: EXACT, between: between, options: options, expand: expand, validate: validate, pathBits: pathBits, limitBits: limitBits, toSymbols: toSymbols, parseSeq: parseSeq, analyze: analyze, exactCount: exactCount };
})();
if (typeof module !== 'undefined') module.exports = PAT;

/* ===================== APP: state, ledger, audio, FX, feedback ===================== */
var APP_NAME = 'SystemVault', STORE_KEY = 'systemvault_v1';
var CONTACT_ENDPOINT = 'https://script.google.com/macros/s/AKfycbzvKlrt3NYoGvwIoxpOrDyarhJYL5V8TctpxuG16xw0I5ee-jcOWs1Fw_c9SSh6jI_McA/exec'; /* BRIEF > CONTACT ENDPOINT (owner's relay) */
var CONTACT_EMAIL = 'francisuadm@gmail.com';                                                                                                        /* BRIEF > ADMIN CONTACT EMAIL (owner's relay) */

/* ---------- display timezone: Pacific (handles PST/PDT automatically). Display only: ledger timestamps stay ISO-8601 UTC so the hash chain is unaffected. ---------- */
var TZ = 'America/Los_Angeles';
var _ptFmt = new Intl.DateTimeFormat('en-US', { timeZone: TZ, hour12: false, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', timeZoneName: 'short' });
function ptParts(d) { var o = {}; _ptFmt.formatToParts(d).forEach(function (p) { o[p.type] = p.value; }); if (o.hour === '24') o.hour = '00'; return o; }
function fmtPT(iso) { var d = new Date(iso); if (isNaN(d)) return String(iso || ''); var o = ptParts(d); return o.year + '-' + o.month + '-' + o.day + ' ' + o.hour + ':' + o.minute + ':' + o.second + ' ' + o.timeZoneName; }
function $(id) { return document.getElementById(id); }
function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
function stripTags(s) { return String(s).replace(/<[^>]*>/g, ''); }
function fmt1(n) { return (Math.round(n * 10) / 10).toString(); }

/* ---------- persisted state: ONE key. Secrets (typed passwords, generated keys) are never part of S. ---------- */
var UI_DEFAULTS = { fx: 65, tilt: 0, fxAnim: true, glow: 55, iconSize: 100, crt: false, soundEnabled: true, soundVolume: 50, blur: 12, fill: 68, depth: 45 };
var PREF_DEFAULTS = { startPage: 'fortify', startWt: false, gnFold: false, mode: 'echo', floor: 128, clip: 30, idle: 120, wipeHide: true, ambig: false, gnMode: 'password', gnLen: 30, gnWords: 6, gnSep: '-', gnComb: 'isolated', gnCap: false, gnNum: true, gnSym: false };
var S = { ui: {}, prefs: {}, audit: [], hidden: {}, tray: [], collapsed: {}, order: [], wtDone: {}, rotDone: {}, welcomeSeen: false, theme: 'dark', view: 'grid', prefsVer: 0, lastVer: '' };
var ui = Object.assign({}, UI_DEFAULTS), prefs = Object.assign({}, PREF_DEFAULTS);
function load() {
  try { var raw = localStorage.getItem(STORE_KEY); if (raw) { var o = JSON.parse(raw); Object.keys(S).forEach(function (k) { if (o[k] !== undefined) S[k] = o[k]; }); } } catch (e) {}
  if (!Array.isArray(S.audit)) S.audit = [];
}
function save() { try { localStorage.setItem(STORE_KEY, JSON.stringify(S)); } catch (e) {} }

/* ---------- Telemetry-FX engine (blueprint 2.8) ---------- */
var PREFS_VER = 2;   /* bump to push new defaults onto browsers that saved the old ones (v2: floor 128, length 30) */
function loadUI() {
  ui = Object.assign({}, UI_DEFAULTS, S.ui || {}); prefs = Object.assign({}, PREF_DEFAULTS, S.prefs || {});
  prefs.cs = JSON.parse(JSON.stringify(prefs.cs || { on: {}, custom: '', exclude: '' }));
  if ((S.prefsVer || 0) < PREFS_VER) { prefs.floor = PREF_DEFAULTS.floor; prefs.gnLen = PREF_DEFAULTS.gnLen; S.prefsVer = PREFS_VER; S.prefs = prefs; save(); }
  applyFx();
}
function saveUI() { S.ui = ui; S.prefs = prefs; save(); applyFx(); }
function applyFx() {
  var r = document.documentElement, st = r.style;
  st.setProperty('--fx', ((ui.fx == null ? 65 : ui.fx) / 100).toFixed(2));
  r.setAttribute('data-fx', ui.fxAnim === false ? 'off' : 'on');
  if (ui.crt) r.setAttribute('data-crt', 'on'); else r.removeAttribute('data-crt');
  var gr = (ui.glow == null ? 55 : ui.glow) / 100;
  st.setProperty('--glow', '0 0 ' + Math.round(24 * gr) + 'px rgba(47,230,208,' + (0.35 * gr).toFixed(2) + ')');
  st.setProperty('--ui-scale', ((ui.iconSize == null ? 100 : ui.iconSize) / 100).toFixed(2));
  st.setProperty('--g-blur', (ui.blur == null ? 12 : ui.blur) + 'px');
  st.setProperty('--g-fill-a', ((ui.fill == null ? 68 : ui.fill) / 100).toFixed(2));
  st.setProperty('--g-shadow-a', ((ui.depth == null ? 45 : ui.depth) / 100).toFixed(2));
  st.setProperty('--tilt', (ui.tilt || 0) + 'deg');
  r.setAttribute('data-theme', S.theme === 'light' ? 'light' : 'dark');
  var b = $('btnSound'); if (b) b.textContent = ui.soundEnabled === false ? '🔇' : '🔊';
  document.querySelectorAll('.tbtn,.brand .glyph').forEach(function (e) { e.style.zoom = ''; });
}
function wireTilt(selector) {
  document.querySelectorAll(selector).forEach(function (p) {
    if (p._tilted) return; p._tilted = true;
    p.addEventListener('mousemove', function (e) {
      if (ui.fxAnim === false || (ui.tilt || 0) <= 0) return;
      if (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches) return;
      var r = p.getBoundingClientRect(), px = (e.clientX - r.left) / r.width - 0.5, py = (e.clientY - r.top) / r.height - 0.5, deg = ui.tilt == null ? 0 : ui.tilt;
      p.classList.add('tilt'); p.style.setProperty('--gtx', (-py * deg).toFixed(2) + 'deg'); p.style.setProperty('--gty', (px * deg).toFixed(2) + 'deg');
    });
    p.addEventListener('mouseleave', function () { p.classList.remove('tilt'); p.style.removeProperty('--gtx'); p.style.removeProperty('--gty'); });
  });
}

/* ---------- Web Audio synthesizer (blueprint PART 7) ---------- */
var audioCtx = null;
function playBeep(freq, type, duration, gain) {
  if (ui.soundEnabled === false) return;
  freq = freq || 880; type = type || 'sine'; duration = duration || .08; gain = gain == null ? .05 : gain;
  try {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    if (audioCtx.state === 'suspended') audioCtx.resume();
    var osc = audioCtx.createOscillator(), g = audioCtx.createGain(), master = (ui.soundVolume == null ? 50 : ui.soundVolume) / 100;
    osc.type = type; osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
    g.gain.setValueAtTime(Math.max(.0001, gain * master), audioCtx.currentTime);
    g.gain.exponentialRampToValueAtTime(.0001, audioCtx.currentTime + duration);
    osc.connect(g); g.connect(audioCtx.destination); osc.start(); osc.stop(audioCtx.currentTime + duration);
  } catch (e) {}
}
function playCheerChime() {
  playBeep(523.25, 'triangle', .12, .08);
  setTimeout(function () { playBeep(659.25, 'triangle', .12, .08); }, 80);
  setTimeout(function () { playBeep(783.99, 'triangle', .18, .10); }, 160);
  setTimeout(function () { playBeep(1046.5, 'sine', .28, .12); }, 240);
}

/* ---------- toasts ---------- */
function toast(kind, title, msg) {
  var box = $('toasts'); if (!box) return;
  var t = document.createElement('div'); t.className = 'toast ' + (kind === 'err' ? 'err' : kind === 'warn' ? 'warn' : '');
  t.innerHTML = '<b>' + esc(title) + '</b>' + esc(msg || ''); box.appendChild(t);
  setTimeout(function () { t.style.opacity = '0'; t.style.transition = 'opacity .3s'; setTimeout(function () { t.remove(); }, 320); }, 3600);
}

/* ---------- confetti + comic pop (blueprint 2.10; colours/physics verbatim, randomness from the vault RNG) ---------- */
var gfxCtx = null, gfxParticles = [], gfxRAF = null;
var PULSE_WORDS = ['FORTIFIED!', 'ENTROPY MIXED!', 'CHAIN INTACT!', 'NO WEAK LINKS!', 'BITS VERIFIED!'];
function rnd01() { return R.int(1000000) / 1000000; }   /* never Math.random */
function initConfetti() { var cv = $('gfx'); if (!cv) return; cv.width = innerWidth; cv.height = innerHeight; gfxCtx = cv.getContext('2d'); }
function fireConfetti(x, y) {
  if (!gfxCtx) initConfetti(); if (!gfxCtx) return;
  x = x == null ? innerWidth / 2 : x; y = y == null ? innerHeight / 3 : y;
  var colors = ['#2fe6d0', '#7dff9b', '#ffcf5c', '#8b7dff', '#59b4ff'];
  for (var i = 0; i < 45; i++) gfxParticles.push({ x: x, y: y, vx: (rnd01() - .5) * 9, vy: rnd01() * -9 - 2, g: .35, size: 4 + rnd01() * 5, color: colors[i % colors.length], life: 60 + rnd01() * 25 });
  if (!gfxRAF) gfxRAF = requestAnimationFrame(loopConfetti);
  comicPop(x, y); playCheerChime();
}
function loopConfetti() {
  var cv = $('gfx'); if (!cv || !gfxCtx) { gfxRAF = null; return; }
  gfxCtx.clearRect(0, 0, cv.width, cv.height);
  gfxParticles.forEach(function (p) { p.vy += p.g; p.x += p.vx; p.y += p.vy; p.life--; gfxCtx.fillStyle = p.color; gfxCtx.fillRect(p.x, p.y, p.size, p.size); });
  gfxParticles = gfxParticles.filter(function (p) { return p.life > 0 && p.y < cv.height + 40; });
  gfxRAF = gfxParticles.length ? requestAnimationFrame(loopConfetti) : null;
}
function comicPop(x, y) {
  var el = document.createElement('div'); el.className = 'gcomic'; el.textContent = PULSE_WORDS[R.int(PULSE_WORDS.length)];
  el.style.left = x + 'px'; el.style.top = y + 'px'; document.body.appendChild(el); setTimeout(function () { el.remove(); }, 1000);
}

/* ---------- tamper-evident audit ledger (blueprint PART 5) ---------- */
var GENESIS = '0000000000000000000000000000000000000000000000000000000000000000';
var HAS_SUBTLE = !!(window.crypto && window.crypto.subtle);
/* Both paths are real SHA-256 (WebCrypto when present, the built-in pure-JS implementation otherwise); the label says which. */
var LEDGER_ALGO = HAS_SUBTLE ? 'SHA-256 (WebCrypto)' : 'SHA-256 (built-in JS; crypto.subtle unavailable in this context)';
function hashOf(str) {
  if (HAS_SUBTLE) {
    try {
      return crypto.subtle.digest('SHA-256', new TextEncoder().encode(str)).then(function (buf) { return toHex(new Uint8Array(buf)); })['catch'](function () { return Promise.resolve(sha256hex(str)); });
    } catch (e) {}
  }
  return Promise.resolve(sha256hex(str));
}
function blockPayload(e) { return e.seq + '|' + e.ts + '|' + e.subject + '|' + e.action + '|' + e.prevHash; }
var _ledgerQ = Promise.resolve();
function ledgerQueue(fn) { _ledgerQ = _ledgerQ.then(fn)['catch'](function () {}); return _ledgerQ; }
function ledgerSettled() { return _ledgerQ; }
/* audit() records metadata ONLY. Callers must never pass a password or generated key. */
function audit(subject, action) {
  _ledgerQ = _ledgerQ.then(function () {
    var head = S.audit[0], seq = head && head.seq ? head.seq + 1 : 1, prev = head && head.hash ? head.hash : GENESIS;
    var e = { seq: seq, ts: new Date().toISOString(), subject: String(subject), action: String(action), prevHash: prev, hash: '' };
    return hashOf(blockPayload(e)).then(function (h) {
      e.hash = h; S.audit.unshift(e); if (S.audit.length > 500) S.audit.length = 500;
      save(); if (window.renderPanel) renderPanel('ledger'), renderPanel('activity'); updateLedgerStatus();
    });
  })['catch'](function () {});
  return _ledgerQ;
}
function verifyChain() {
  var chron = S.audit.slice().reverse(), prev = GENESIS, chain = Promise.resolve({ ok: true, count: chron.length });
  chron.forEach(function (e) {
    chain = chain.then(function (res) {
      if (!res.ok) return res;
      var probe = { seq: e.seq, ts: e.ts, subject: e.subject, action: e.action, prevHash: prev };
      return hashOf(blockPayload(probe)).then(function (h) {
        if (e.prevHash !== prev || h !== e.hash) return { ok: false, brokenAt: e.seq || '?', count: chron.length };
        prev = e.hash; return res;
      });
    });
  });
  return chain;
}
function migrateLedger() {
  var legacy = S.audit.filter(function (e) { return !e.hash; }); if (!legacy.length) return;
  var chron = S.audit.slice().reverse(), prev = GENESIS, seq = 0, chain = Promise.resolve();
  chron.forEach(function (e) { chain = chain.then(function () { e.seq = ++seq; e.prevHash = prev; return hashOf(blockPayload(e)).then(function (h) { e.hash = h; prev = h; }); }); });
  _ledgerQ = chain.then(function () { save(); updateLedgerStatus(); audit('Ledger', 'Re-chained ' + legacy.length + ' pre-existing audit rows into the hash chain'); })['catch'](function () {});
}

/* ---------- clipboard (honest: reports success only when the copy actually happened) ---------- */
var clipTimer = null;
function copyText(text, label) {
  function done(ok) {
    if (!ok) { toast('err', 'COPY FAILED', 'The browser refused clipboard access. Select the text manually.'); return; }
    playBeep(980, 'sine', .06, .04); toast('ok', 'COPIED', (label || 'Value') + ' copied' + (prefs.clip > 0 ? ' · clipboard clear attempted in ' + prefs.clip + ' s (best-effort)' : '') + '.');
    audit('Clipboard', (label || 'Value') + ' copied');
    if (clipTimer) clearTimeout(clipTimer);
    if (prefs.clip > 0) clipTimer = setTimeout(function () { try { navigator.clipboard.writeText(' ').catch(function () {}); } catch (e) {} }, prefs.clip * 1000);
  }
  if (window.isSecureContext && navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(function () { done(true); }, function () { done(legacyCopy(text)); });
  } else done(legacyCopy(text));
}
function legacyCopy(text) {
  var ta = document.createElement('textarea'); ta.value = text; ta.setAttribute('readonly', ''); ta.style.cssText = 'position:fixed;left:-9999px;top:0;opacity:0';
  document.body.appendChild(ta); ta.select(); var ok = false; try { ok = document.execCommand('copy'); } catch (e) {} ta.remove(); return ok;
}
function dl(name, content, type) {
  var b = new Blob([content], { type: type || 'text/plain' }), a = document.createElement('a');
  a.href = URL.createObjectURL(b); a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(function () { URL.revokeObjectURL(a.href); }, 2000);
  audit('Export', name);
}

/* ===================== APP: vault memory, Fortify, generator, panels ===================== */
var R = new EntropyMixer();
initDicts(EFF_WORDS, COMMON_PW);
var WORD_BITS = Math.log2(DICT.words.length);
/* in-memory secrets live ONLY here and in the DOM while revealed; never in S, the ledger, exports or toasts */
var vault = { result: null, batch: [], batchShown: false, resShown: false, analysis: null, qrText: null, qrLabel: '', delivered: false, started: Date.now(), verified: null, lastAct: Date.now(), selftest: null };
var MODE_HINT = {
  echo: 'Keeps the recognisable words and shape, re-draws weak digits/symbols, flips case / look-alike swaps on a random third of the letters, inserts random characters and appends a random tail up to the bit floor. Retained material counts as <b>0 trusted bits</b>.',
  shape: 'Keeps only the length and character-class layout (upper / lower / digit / symbol per position). Every character is newly drawn, so no part of the original survives.',
  fresh: 'Ignores the input entirely: fresh random characters over the full pool, all four classes guaranteed. The most secure option.'
};
var RATES = [
  { id: 'bcrypt', name: 'Slow hash · bcrypt cost 10, one RTX 6000 Ada-class GPU', rate: 1.5e5, note: 'figure carried over from v1 (assumption)' },
  { id: 'fast', name: 'Fast hash · NTLM / MD5, one high-end GPU', rate: 1e11, note: 'order-of-magnitude assumption' },
  { id: 'farm', name: 'Fast hash · 100-GPU cracking rig', rate: 1e13, note: 'order-of-magnitude assumption' }
];
var POLICIES = [
  { id: 'basic', name: 'Basic', floor: 64, len: 14, words: 5, use: 'low-value / rate-limited logins' },
  { id: 'standard', name: 'Standard', floor: 80, len: 18, words: 6, use: 'most corporate accounts' },
  { id: 'high', name: 'High', floor: 96, len: 22, words: 8, use: 'admin / privileged accounts' },
  { id: 'vault', name: 'Vault', floor: 128, len: 28, words: 10, use: 'master passwords, key material' },
  { id: 'paranoid', name: 'Paranoid', floor: 256, len: 44, words: 20, use: 'long-lived key material' },
  { id: 'max', name: 'Maximum', floor: 512, len: 84, words: 40, use: 'symbolic ceiling; far beyond practical need' }
];
var ROTATE_ITEMS = ['Change the password on the real system (the vault does not do this for you)', 'Enable MFA or a hardware key (e.g. YubiKey) on that account', 'Store the new value in the approved password manager', 'Sign out other sessions and revoke old tokens / app passwords', 'Replace the old password anywhere it was reused', 'Purge vault memory and close this tab'];

function dots(n) { return '•'.repeat(Math.min(n, 40)) + (n > 40 ? '…' : ''); }
function priv(t) { return '<span class="priv">' + t + '</span>'; }
function fzRevealed() { var i = $('fzIn'); return !!i && i.type === 'text'; }
function secretSpan(id, text, shown) { return '<span class="secret" id="' + id + '">' + esc(shown ? text : dots(text.length)) + '</span>'; }
function touch() { vault.lastAct = Date.now(); }

/* ---------- Fortify ---------- */
function setFzMode(m) { prefs.mode = m; syncFortifyUI(); }
function onFzCfg() { prefs.floor = +$('fzFloor').value; prefs.ambig = $('fzAmbig').checked; renderPanel('charset'); }
function syncFortifyUI() {
  document.querySelectorAll('#fzMode button').forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-m') === prefs.mode); });
  var h = $('fzModeHint'); if (h) h.innerHTML = MODE_HINT[prefs.mode];
  if ($('fzFloor')) $('fzFloor').value = String(prefs.floor); if ($('fzAmbig')) $('fzAmbig').checked = !!prefs.ambig;
}
function onFzInput() {
  if (vault.src === 'pattern') return;
  touch(); var v = $('fzIn').value;
  vault.analysis = v ? analyze(v) : null;
  var a = vault.analysis, m = $('fzMeter'), e = $('fzEst');
  if (m) m.style.width = a ? a.pct + '%' : '0%';
  if (e) e.innerHTML = a ? 'Length: <b class="mono">' + priv(Array.from(v).length + (Array.from(v).length === 1 ? ' character' : ' characters')) + '</b> · Estimated strength: <b class="mono">' + priv(fmt1(a.estBits) + ' bits') + '</b> · <span class="tag ' + (a.estBits < 40 ? 'bad' : a.estBits < 60 ? 'warn' : 'ok') + '">' + a.label + '</span> (offline model, not a guarantee)' : 'Waiting for input…';
  renderPanel('weakness'); renderPanel('model'); renderHud();
}
function runFortify() {
  touch(); var usePat = vault.src === 'pattern', pw = usePat ? '' : $('fzIn').value, mode = usePat ? 'fresh' : prefs.mode, floor = +$('fzFloor').value;
  if (usePat && !vault.pattern) { toast('warn', 'NO PATTERN', 'Draw a pattern first, or switch to "Type it".'); return; }
  if (!pw && mode !== 'fresh') { toast('warn', 'NO INPUT', 'Nothing typed — generating a Fresh password instead.'); mode = 'fresh'; }
  try {
    R.jitter('timing', [Math.floor(performance.now() * 1000) & 0xffff]);
    var r = fortify(R, pw, mode, floor, { charset: currentCs() });
    vault.result = r; vault.resShown = false; vault.delivered = false;
    r.sim = pw ? similarity(pw, r.text) : 0; r.inBits = usePat ? vault.analysis.estBits : (pw ? analyze(pw).estBits : 0); r.src = usePat ? 'pattern' : 'typed';
    audit('Fortify', 'mode=' + mode + ' floor=' + floor + 'b trusted=' + r.trustedBits + 'b length=' + r.text.length + ' input=' + (usePat ? 'pattern(' + vault.analysis.label + ', ' + vault.analysis.grid + 'x' + vault.analysis.grid + ')' : (pw ? r.analysis.label : 'none')));
    playBeep(660, 'triangle', .08, .05); setTimeout(function () { playBeep(990, 'triangle', .1, .06); }, 90);
    fireConfetti(); toast('ok', 'FORTIFIED', fmt1(r.trustedBits) + ' trusted bits · ' + r.text.length + ' characters.');
    S.wtDone.run = true; save();
  } catch (e) { toast('err', 'GENERATION REFUSED', e.message); return; }
  renderPanel('fortify'); renderPanel('model'); renderHud(); renderWalkthrough();
}
function renderFortifyResult() {
  var box = $('fzOut'); if (!box) return; var r = vault.result;
  if (!r) { box.innerHTML = '<div class="empty">No result yet. Enter a password and press <code>FORTIFY</code>.</div>'; return; }
  var steps = r.steps.map(function (s) { return '<li><b>+' + fmt1(s.bits) + ' b</b> ' + esc(s.label) + '</li>'; }).join('');
  box.innerHTML = '<div class="resultbox"><div class="ctrl-label">Fortified password &middot; ' + r.mode.toUpperCase() + '</div>' + secretSpan('fzSecret', r.text, vault.resShown) +
    '<div class="btnrow" style="margin:10px 0"><button class="btn sm" data-on-click="toggleResShown()">' + (vault.resShown ? '🙈 Hide' : '👁 Reveal') + '</button><button class="btn sm primary" data-on-click="copyResult()">📋 Copy</button><button class="btn sm" data-on-click="showQr(vault.result.text,\'Fortified password\')">📱 QR</button><button class="btn sm" data-on-click="runFortify()">↻ Re-roll</button></div>' +
    '<div class="kv"><span>Trusted entropy</span><b>' + fmt1(r.trustedBits) + ' bits (floor ' + r.floor + ')</b><span>Input estimate</span><b>' + priv(fmt1(r.inBits) + ' bits') + '</b><span>Retained from input</span><b>' + (r.mode === 'echo' ? fmt1(r.retainedBits) + ' b (counted as 0)' : 'none') + '</b><span>Length</span><b>' + r.text.length + ' chars</b><span>Similarity kept</span><b>' + Math.round(r.sim * 100) + '%</b></div>' +
    '<details style="margin-top:10px"><summary class="mini" style="cursor:pointer">Where the trusted bits come from</summary><ul class="steps">' + steps + '</ul></details>' +
    '<div class="note-warn">An attacker who knows the old password is assumed. Only bits drawn from the CSPRNG are counted &mdash; anything kept from the old password adds nothing.</div></div>';
}
function toggleResShown() { vault.resShown = !vault.resShown; renderFortifyResult(); }
function copyResult() { if (!vault.result) return; copyText(vault.result.text, 'Fortified password'); vault.delivered = true; S.wtDone.deliver = true; save(); renderHud(); renderWalkthrough(); }
function toggleReveal(inId, btnId) { var i = $(inId); i.type = i.type === 'password' ? 'text' : 'password'; playBeep(i.type === 'text' ? 760 : 420, 'sine', .04, .025); if (inId === 'fzIn') renderPanel('weakness'); }

/* ---------- Weakness report + brute-force model ---------- */
function renderWeaknessTyped() {
  var b = $('wkBody'); if (!b) return; var a = vault.analysis;
  if (!a) { b.innerHTML = '<div class="empty">No password analysed. Type one in the <code>Fortify</code> panel &mdash; analysis runs live, offline, in memory.</div>'; return; }
  var shown = fzRevealed(), toks = a.tokens.map(function (t) { return '<span class="tok ' + t.type + '"><span class="secret">' + esc(shown ? t.text : dots(t.text.length)) + '</span><i>' + t.type + ' · ' + t.text.length + ' chars · ' + priv(t.bits + 'b') + '</i></span>'; }).join('');
  var f = a.weak.length ? a.weak.map(function (w) { return '<div class="find"><span class="sv ' + w.sev + '">' + w.sev.toUpperCase() + '</span><span>' + esc(w.msg) + '</span></div>'; }).join('') : '<div class="find"><span class="sv info">INFO</span><span>No common weaknesses detected by the offline model.</span></div>';
  b.innerHTML = '<div class="kv"><span>Length</span><b>' + a.len + '</b><span>Naive bits (len × log₂ pool)</span><b>' + priv(fmt1(a.naiveBits)) + '</b><span>Model estimate</span><b>' + priv(fmt1(a.estBits)) + ' (' + a.label + ')</b><span>Common-list match</span><b>' + (a.rank ? priv(rankBucket(a.rank)) : 'not found') + '</b></div><div class="mini">Token text is masked; press the eye in Fortify to show it. Figures marked private are hidden when printing.</div>' +
    '<div class="ctrl-label" style="margin-top:12px">Tokenisation</div><div>' + toks + '</div><div class="ctrl-label" style="margin-top:12px">Findings (' + a.weak.length + ')</div>' + f +
    '<div class="mini" style="margin-top:8px">Checked against ' + DICT.common.length.toLocaleString('en-US') + ' common passwords and ' + DICT.words.length.toLocaleString('en-US') + ' dictionary words, locally.</div>';
}
function renderModel() {
  var b = $('mdBody'); if (!b) return;
  var rows = [], r = vault.result, a = vault.analysis;
  if (!a && !r) { b.innerHTML = '<div class="empty">Nothing to model yet. Analyse or fortify a password first.</div>'; return; }
  var head = '<tr><th>Attacker model</th>' + (a ? '<th>Original (' + priv(fmt1(a.estBits) + ' b') + ')</th>' : '') + (r ? '<th>Fortified (' + fmt1(r.trustedBits) + ' b)</th>' : '') + '</tr>';
  RATES.forEach(function (x) {
    rows.push('<tr><td>' + esc(x.name) + '<div class="mini">' + esc(x.note) + ' · ' + (x.rate >= 1e9 ? (x.rate / 1e9) + ' GH/s' : (x.rate / 1e3) + ' kH/s') + '</div></td>' + (a ? '<td class="m">' + priv(bitsToTime(a.estBits, x.rate)) + '</td>' : '') + (r ? '<td class="m">' + bitsToTime(r.trustedBits, x.rate) + '</td>' : '') + '</tr>');
  });
  b.innerHTML = '<table class="t">' + head + rows.join('') + '</table><div class="mini" style="margin-top:8px">Average time = half the keyspace ÷ guess rate. Rates are stated assumptions, not measurements; offline attacks only. There is no &ldquo;infinite&rdquo; &mdash; very large values are capped as &gt;10^N years.</div>';
}

/* ---------- Generator + batch ---------- */
function setGnMode(m) { prefs.gnMode = m; onGnCfg(); }
function setGnComb(id) { prefs.gnComb = id; if ($('gnComb')) $('gnComb').value = id; onGnCfg(); saveUI(); }
/* what each text-mixing mode produces (shape is illustrative; MY TEXT is the Base field, random parts come from the entropy pool) */
var COMB_INFO = {
  isolated: { shape: '[random]', need: 0, note: 'Your text is not put in the key.' },
  append: { shape: '[MY TEXT][random]', need: 1, note: 'Your text first, then the random part.' },
  prepend: { shape: '[random][MY TEXT]', need: 1, note: 'The random part first, then your text.' },
  mix: { shape: 'MY TEXT and random characters, shuffled together', need: 1, note: 'Every character is shuffled with an unbiased Fisher-Yates pass.' },
  embed: { shape: '[random\u2026][MY TEXT][\u2026random]', need: 1, note: 'Your text stays whole but is hidden inside the random part (never first or last). The hiding position adds a few real bits.' },
  omni: { shape: '[MY TEXT]-[random characters]-[passphrase]', need: 0, note: 'Your text (optional), a random string and a random passphrase joined with your separator.' },
  omnishuffle: { shape: 'all of the Omni-Mix parts, shuffled', need: 0, note: 'Omni-Mix with every character shuffled.' }
};
function onGnCfg() {
  touch(); prefs.gnLen = +$('gnLen').value; prefs.gnWords = +$('gnWords').value; prefs.gnSep = $('gnSep').value; prefs.gnComb = $('gnComb').value;
  prefs.gnCap = $('gnCap').checked; prefs.gnNum = $('gnNum').checked; prefs.gnSym = $('gnSym').checked;
  $('gnLenV').textContent = prefs.gnLen; $('gnWordV').textContent = prefs.gnWords;
  var pw = prefs.gnMode === 'password';
  document.querySelectorAll('#gnMode button').forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-m') === prefs.gnMode); });
  $('gnLenBox').style.display = pw ? '' : 'none'; $('gnWordBox').style.display = pw ? 'none' : ''; $('gnSepBox').style.display = pw ? 'none' : ''; $('gnPassOpts').style.display = pw ? 'none' : '';
  $('gnLenWarn').innerHTML = prefs.gnLen < 12 ? '<span style="color:var(--warn)">⚠ under 12 characters is weak for modern attacks</span>' : '';
  prefs.gnFold = $('gnFold').checked; var ci = COMB_INFO[prefs.gnComb] || COMB_INFO.isolated, hasBase = !!currentBase();
  $('gnCombHint').innerHTML = 'Result shape: <code>' + ci.shape + '</code> &middot; ' + ci.note + (prefs.gnComb === 'isolated' ? '' : ' Your text counts as <b>0 trusted bits</b>; only the random parts count.');
  $('gnBase').placeholder = prefs.gnComb === 'isolated' ? 'not used in the key (Isolated); can still seed the entropy pool below' : ci.need ? 'required for this mode: the text to mix into the key' : 'optional for this mode';
  $('gnFoldHint').innerHTML = !prefs.gnFold ? 'Off: your text only goes into the key, never into the entropy pool.' : hasBase ? '<span style="color:var(--accent-2)">On:</span> a SHA-256 hash of your text is folded into the pool when you press DEPLOY. It adds <b>0 trusted bits</b> and cannot weaken the output.' : 'On, but there is no text yet: type something in the base field above (nothing is folded until you do).';
  var base = currentBase(), q = $('gnBaseQ'), bl = $('gnBaseLen'); if (bl) { var bn = Array.from(base).length; bl.innerHTML = base ? 'LENGTH: ' + priv(bn + (bn === 1 ? ' character' : ' characters')) : ''; }
  if (base) { var a = baseAnalysis(base); q.textContent = 'QUALITY: ' + a.label + ' (' + fmt1(a.estBits) + 'b)'; q.className = 'tag ' + (a.estBits < 40 ? 'bad' : a.estBits < 60 ? 'warn' : 'ok'); } else { q.textContent = 'QUALITY: —'; q.className = 'tag'; }
}
function combine(base, core, comb, sepc, extra) {
  switch (comb) {
    case 'append': return base + core; case 'prepend': return core + base;
    case 'mix': return R.shuffle((base + core).split('')).join('');
    case 'embed': { var pos = R.int(core.length - 1) + 1; return core.slice(0, pos) + base + core.slice(pos); }   /* interior slot: never first, never last */
    case 'omni': return (base ? base + sepc : '') + core + (extra ? sepc + extra : '');
    case 'omnishuffle': return R.shuffle(((base ? base + sepc : '') + core + (extra ? sepc + extra : '')).split('')).join('');
    default: return core;
  }
}
function runBatch() {
  touch(); onGnCfg(); var base = currentBase(), comb = prefs.gnComb, n = 10, list = [], sepc = prefs.gnSep || '-';
  if (!base && (comb === 'append' || comb === 'prepend' || comb === 'mix' || comb === 'embed')) { toast('err', 'BASE REQUIRED', 'This text-mixing mode needs your text in the base field.'); return; }
  var folded = false; if (prefs.gnFold) { if (base) { R.addText('user', base); folded = true; } else toast('warn', 'NOTHING TO FOLD', 'The fold option is on but the base field is empty.'); }
  try {
    for (var i = 0; i < n; i++) {
      var core, extra = null, bits;
      if (comb === 'omni' || comb === 'omnishuffle') {
        var p1 = genPassword(R, prefs.gnLen, { charset: currentCs() }), p2 = genPassphrase(R, prefs.gnWords, sepc, { cap: prefs.gnCap, num: prefs.gnNum, sym: prefs.gnSym, charset: currentCs() });
        core = p1.text; extra = p2.text; bits = p1.trustedBits + p2.trustedBits;
      } else {
        core = prefs.gnMode === 'password' ? genPassword(R, prefs.gnLen, { charset: currentCs() }) : genPassphrase(R, prefs.gnWords, sepc, { cap: prefs.gnCap, num: prefs.gnNum, sym: prefs.gnSym, charset: currentCs() });
        bits = core.trustedBits; core = core.text;
      }
      if (comb === 'embed') bits += Math.log2(Math.max(1, core.length - 1));   /* the random insertion slot is a real CSPRNG choice */
      list.push({ text: combine(base, core, comb, sepc, extra), bits: Math.round(bits * 10) / 10, shown: false });
    }
  } catch (e) { toast('err', 'GENERATION REFUSED', e.message); return; }
  vault.batch = list; vault.batchShown = false; vault.delivered = false; S.wtDone.run = S.wtDone.run || false;
  audit('Batch', 'n=' + n + ' type=' + prefs.gnMode + ' mode=' + comb + ' trusted=' + list[0].bits + 'b each' + (folded ? ' \u00B7 user text folded into the pool (0 trusted bits)' : ''));
  playBeep(740, 'triangle', .08, .05); toast('ok', 'ENTROPY DEPLOYED', n + ' keys · ' + list[0].bits + ' trusted bits each' + (base ? ' (base text counted as 0)' : '') + (folded ? ' Your text was also folded into the entropy pool (0 trusted bits).' : '') + '');
  if (folded) renderPanel('sources'); openPanel('batch'); renderHud();
}
function renderBatch() {
  var b = $('bhList'); if (!b) return; var L = vault.batch;
  if (!L.length) { b.innerHTML = '<div class="empty">No batch yet. Use <code>DEPLOY ENTROPY</code> in the Key Generator panel.</div>'; $('bhMeta').textContent = ''; return; }
  $('bhMeta').textContent = L.length + ' results · ' + L[0].bits + ' trusted bits each';
  $('bhReveal').innerHTML = vault.batchShown ? '🙈 Hide all' : '👁 Reveal all';
  b.innerHTML = L.map(function (it, i) {
    var shown = vault.batchShown || it.shown;
    return '<div class="outitem">' + secretSpan('bh' + i, it.text, shown) + '<span class="bits">' + it.bits + ' b</span><button class="btn sm" data-on-click="vault.batch[' + i + '].shown=!vault.batch[' + i + '].shown;renderBatch()">' + (shown ? '🙈' : '👁') + '</button><button class="btn sm" data-on-click="copyBatch(' + i + ')">📋</button><button class="btn sm" data-on-click="showQr(vault.batch[' + i + '].text,\'Generated key\')">📱 QR</button></div>';
  }).join('');
}
function toggleBatchReveal() { vault.batchShown = !vault.batchShown; renderBatch(); }
function copyBatch(i) { copyText(vault.batch[i].text, 'Generated key'); vault.delivered = true; S.wtDone.deliver = true; save(); renderHud(); renderWalkthrough(); }

/* ---------- entropy sources ---------- */
function onSrcCfg() { R.enabled.pointer = $('srcPtr').checked; R.enabled.key = $('srcKey').checked; renderPanel('sources'); renderHud(); }
function renderSources() {
  var g = $('srcGrid'); if (!g) return; var s = R.stats;
  function card(name, n, unit, on, note) { return '<div class="src"><h4>' + name + ' <span class="tag ' + (on ? 'ok' : 'warn') + '">' + (on ? 'ACTIVE' : 'OFF') + '</span></h4><div class="n">' + n.toLocaleString('en-US') + '</div><div class="mini">' + unit + ' · ' + note + '</div></div>'; }
  g.innerHTML = card('CSPRNG', s.csprng, 'bytes drawn', R.ok, 'crypto.getRandomValues (floor of every output)') + card('POINTER', s.pointer, 'samples', R.enabled.pointer, 'movement deltas + timestamps') + card('KEY TIMING', s.key, 'intervals', R.enabled.key, 'timestamps only, no key values') + card('HI-RES TIMING', s.timing, 'samples', true, 'busy-loop jitter at boot') + card('WEBCRYPTO', s.subtle, 'bytes folded', HAS_SUBTLE, HAS_SUBTLE ? 'SHA-256 digest folded into pool' : 'unavailable on this origin') + card('YOUR TEXT', s.user, 'bytes folded', s.user > 0, 'SHA-256 of your base text, optional, 0 trusted bits') + card('POOL', s.folds, 'folds', true, 'SHA-256 chain over jitter');
}
function foldSubtle() {
  if (!HAS_SUBTLE) { toast('warn', 'WEBCRYPTO UNAVAILABLE', 'crypto.subtle is not available on this origin (common on file://).'); return; }
  var seed = new Uint8Array(32); crypto.getRandomValues(seed);
  crypto.subtle.digest('SHA-256', seed).then(function (d) { R.addBytes('subtle', new Uint8Array(d)); renderPanel('sources'); toast('ok', 'FOLDED', '32 bytes of WebCrypto digest folded into the pool.'); audit('Entropy', 'WebCrypto digest folded into pool'); });
}
function runSelfTest() {
  var t = randomnessSanity(R, 4096); vault.selftest = t;
  $('srcTest').innerHTML = (t.pass ? '<span class="tag ok">PASS</span> ' : '<span class="tag bad">FAIL</span> ') + t.bits.toLocaleString('en-US') + ' bits · ones ' + t.ones + ' · monobit z=' + t.zMono.toFixed(2) + ' · runs z=' + t.zRuns.toFixed(2) + ' · smoke test only, not a certification.';
  audit('Entropy', 'Randomness sanity check ' + (t.pass ? 'passed' : 'FAILED')); playBeep(t.pass ? 880 : 220, 'sine', .1, .05);
}

/* ---------- QR ---------- */
function showQr(text, label) {
  vault.qrText = text; vault.qrLabel = label; vault.delivered = true; S.wtDone.deliver = true; save(); openPanel('airgap'); redrawQr();
  audit('Airgap QR', label + ' displayed as QR'); renderHud(); renderWalkthrough();
}
function redrawQr() {
  var w = $('qrWrap'); if (!w) return;
  if (!vault.qrText) { w.innerHTML = '<div class="empty">Nothing selected. Use the <code>QR</code> button next to a result.</div>'; return; }
  try {
    var q = QR.encode(vault.qrText, $('qrEcc').value);
    w.innerHTML = '<div class="qrbox"><canvas id="qrCanvas"></canvas></div><div class="mini" style="text-align:center;margin-top:8px">' + esc(vault.qrLabel) + ' · QR v' + q.version + ' · ECC ' + q.ecc + ' · contents are the secret itself</div>';
    QR.toCanvas($('qrCanvas'), q, 6, 4);
  } catch (e) { w.innerHTML = '<div class="empty">' + esc(e.message) + '</div>'; }
}
function closeQr() { vault.qrText = null; redrawQr(); }

/* ---------- wordlist / policy / rotate / activity / ledger / about ---------- */
function renderWordlist() {
  var b = $('wlBody'); if (!b) return; var smp = [], i; for (i = 0; i < 8; i++) smp.push(R.pick(DICT.words));
  b.innerHTML = '<div class="kv"><span>Passphrase wordlist</span><b>EFF large · ' + DICT.words.length.toLocaleString('en-US') + ' words</b><span>Entropy per word</span><b>' + WORD_BITS.toFixed(3) + ' bits</b><span>6 / 8 / 10 words</span><b>' + (6 * WORD_BITS).toFixed(1) + ' / ' + (8 * WORD_BITS).toFixed(1) + ' / ' + (10 * WORD_BITS).toFixed(1) + ' b</b><span>Common-password list</span><b>SecLists · ' + DICT.common.length.toLocaleString('en-US') + ' entries</b><span>v1 wordlist</span><b>776 words · 9.6 b/word</b></div>' +
    '<div class="ctrl-label" style="margin-top:12px">Random sample</div><div>' + smp.map(function (w) { return '<span class="tok">' + esc(w) + '</span>'; }).join('') + '</div>' +
    '<div class="ctrl-label" style="margin-top:12px">Look up a word (local only)</div><input type="password" id="wlQ" class="mono" spellcheck="false" autocomplete="off" data-lpignore="true" placeholder="is it in either list?" data-on-input="wlLookup()"><div class="mini" id="wlRes" style="margin-top:6px"></div>';
}
function wlLookup() {
  var q = $('wlQ').value.toLowerCase(), r = $('wlRes'); if (!q) { r.textContent = ''; return; }
  var inW = DICT.words.indexOf(q) >= 0, rk = DICT.commonRank[q];
  r.innerHTML = (inW ? '<span class="tag ok">in EFF wordlist</span> ' : '<span class="tag">not in EFF wordlist</span> ') + (rk ? '<span class="tag bad">common-password rank ' + rk + '</span>' : '<span class="tag ok">not in common list</span>');
}
function applyPolicy(id) {
  var p = POLICIES.filter(function (x) { return x.id === id; })[0]; if (!p) return;
  prefs.floor = p.floor; prefs.gnLen = p.len; prefs.gnWords = p.words; $('gnLen').value = p.len; $('gnWords').value = p.words; syncFortifyUI(); onGnCfg();
  audit('Policy', 'Applied preset ' + p.name + ' (' + p.floor + ' bits)'); toast('ok', 'POLICY', p.name + ': floor ' + p.floor + ' bits · ' + p.len + ' chars · ' + p.words + ' words'); playBeep(700, 'sine', .05, .03); renderPanel('policy'); save();
}
function renderPolicy() {
  var b = $('plBody'); if (!b) return;
  b.innerHTML = '<table class="t"><tr><th>Preset</th><th>Floor</th><th>Chars</th><th>Words</th><th></th></tr>' + POLICIES.map(function (p) {
    var cur = prefs.floor === p.floor; return '<tr><td><b>' + p.name + '</b><div class="mini">' + p.use + '</div></td><td class="m">' + p.floor + ' b</td><td class="m">' + p.len + '</td><td class="m">' + p.words + ' (' + fmt1(p.words * WORD_BITS) + ' b)</td><td><button class="btn sm ' + (cur ? 'primary' : '') + '" data-on-click="applyPolicy(\'' + p.id + '\')">' + (cur ? 'ACTIVE' : 'APPLY') + '</button></td></tr>';
  }).join('') + '</table>';
}
function rotDoneCount() { return Object.keys(S.rotDone || {}).filter(function (k) { return S.rotDone[k]; }).length; }
function toggleRot(i) { S.rotDone[i] = !S.rotDone[i]; save(); playBeep(S.rotDone[i] ? 760 : 420, 'sine', .04, .03); if (rotDoneCount() === ROTATE_ITEMS.length) fireConfetti(); renderPanel('rotate'); }
function renderRotate() {
  var b = $('rtBody'); if (!b) return;
  b.innerHTML = '<div class="mini" style="margin-bottom:8px">A stronger password only helps once it replaces the old one. <b>' + rotDoneCount() + ' / ' + ROTATE_ITEMS.length + '</b> done.</div>' + ROTATE_ITEMS.map(function (t, i) { return '<label class="switch"><input type="checkbox" ' + (S.rotDone[i] ? 'checked' : '') + ' data-on-change="toggleRot(' + i + ')"> ' + esc(t) + '</label>'; }).join('');
}
function renderActivity() {
  var cv = $('spark'); if (!cv) return; var w = cv.clientWidth || 600; cv.width = w; var ctx = cv.getContext('2d'), N = 24, now = Date.now(), b = new Array(N).fill(0), cnt = 0;
  S.audit.forEach(function (e) { var age = (now - Date.parse(e.ts)) / 3600000; if (age >= 0 && age < N) { b[N - 1 - Math.floor(age)]++; cnt++; } });
  var mx = Math.max(1, Math.max.apply(null, b)), cs = getComputedStyle(document.documentElement);
  ctx.clearRect(0, 0, w, 80); ctx.strokeStyle = cs.getPropertyValue('--accent').trim() || '#2fe6d0'; ctx.lineWidth = 2; ctx.beginPath();
  b.forEach(function (v, i) { var x = 6 + i * (w - 12) / (N - 1), y = 72 - v / mx * 62; if (i) ctx.lineTo(x, y); else ctx.moveTo(x, y); }); ctx.stroke();
  if ($('sparkMeta')) $('sparkMeta').textContent = cnt + ' ledger events in the last 24 h · peak ' + mx + '/h';
}
function renderLedger() {
  var b = $('ledBody'); if (!b) return;
  if (!S.audit.length) { b.innerHTML = '<div class="empty">The ledger is empty. Every action appends a hash-chained block (metadata only).</div>'; }
  else b.innerHTML = '<table class="t"><tr><th>#</th><th>Time (Pacific)</th><th>Event</th><th>Detail</th><th>Hash</th></tr>' + S.audit.slice(0, 60).map(function (e) { return '<tr><td class="m">' + e.seq + '</td><td class="m">' + esc(fmtPT(e.ts)) + '</td><td>' + esc(e.subject) + '</td><td>' + esc(e.action) + '</td><td class="m" title="' + e.hash + '">' + (e.hash || '').slice(0, 12) + '…</td></tr>'; }).join('') + '</table>' + (S.audit.length > 60 ? '<div class="mini">Showing newest 60 of ' + S.audit.length + '.</div>' : '');
  updateLedgerStatus();
}
function updateLedgerStatus() {
  var c = $('ledCount'), a = $('ledAlgo'), n = $('ledNote'); if (c) c.textContent = S.audit.length + ' blocks'; if (a) a.textContent = LEDGER_ALGO;
  if (n) { n.style.display = HAS_SUBTLE ? 'none' : 'block'; n.innerHTML = HAS_SUBTLE ? '' : '⚠ <b>crypto.subtle is unavailable in this context</b> (browsers withhold WebCrypto on a bare <code>file://</code> path). The ledger still uses real SHA-256 through the built-in JavaScript implementation and is labelled accordingly. Serve over <code>http://localhost</code> to use WebCrypto.'; }
  renderStatus();
}
function verifyLedger() {
  var st = $('ledState'); if (st) { st.textContent = 'Verifying…'; st.style.color = 'var(--warn)'; }
  ledgerSettled().then(verifyChain).then(function (r) {
    vault.verified = r.ok; if (st) { st.style.color = r.ok ? 'var(--accent-2)' : 'var(--danger)'; st.textContent = r.ok ? 'INTACT · ' + r.count + ' blocks verified' : 'BROKEN at block #' + r.brokenAt; }
    toast(r.ok ? 'ok' : 'err', r.ok ? 'CHAIN INTACT' : 'CHAIN BROKEN', r.ok ? r.count + ' blocks verified (' + LEDGER_ALGO + ').' : 'First mismatch at block #' + r.brokenAt + '.');
    playBeep(r.ok ? 880 : 200, 'sine', .1, .06); if (r.ok) S.wtDone.verify = true; save(); renderHud(); renderWalkthrough();
  });
}
function exportLedger(kind) {
  var blocks = S.audit.slice().reverse();
  if (kind === 'csv') { dl('SystemVault_ledger.csv', 'seq,ts,subject,action,prevHash,hash\n' + blocks.map(function (e) { return [e.seq, e.ts, e.subject, e.action, e.prevHash, e.hash].map(function (x) { return '"' + String(x).replace(/"/g, '""') + '"'; }).join(','); }).join('\n'), 'text/csv'); }
  else dl('SystemVault_ledger.json', JSON.stringify({ app: APP_NAME, version: APP_VERSION, algo: LEDGER_ALGO, genesis: GENESIS, exportedAt: new Date().toISOString(), blocks: blocks }, null, 2), 'application/json');
  toast('ok', 'EXPORT', 'Ledger ' + kind.toUpperCase() + ' downloaded.');
}
function importLedger(file) {
  if (!file) return; var fr = new FileReader();
  fr.onload = function () {
    try {
      var o = JSON.parse(fr.result); if (o.app !== APP_NAME || !Array.isArray(o.blocks)) throw new Error('Not a System Vault ledger export.');
      ledgerQueue(function () { S.audit = o.blocks.slice().reverse(); save(); renderPanel('ledger'); }); toast('ok', 'IMPORTED', o.blocks.length + ' blocks — run VERIFY CHAIN.'); audit('Ledger', 'Imported ' + o.blocks.length + ' blocks');
    } catch (e) { toast('err', 'IMPORT FAILED', e.message); }
  }; fr.readAsText(file);
}
function clearLedger() { if (!confirm('Clear the audit ledger? This cannot be undone.')) return; ledgerQueue(function () { S.audit = []; save(); }).then(function () { renderPanel('ledger'); audit('Ledger', 'Cleared by user'); }); }
function changelogHtml() {
  return '<h4>Version history</h4><div class="tbl-scroll"><table class="t"><tr><th>Version</th><th>Date</th><th>Changes</th></tr>' + CHANGELOG.map(function (c) { return '<tr><td class="m"><b>v' + esc(c.v) + '</b></td><td class="m">' + esc(c.d) + '</td><td><ul class="plain" style="margin:0;padding-left:16px">' + c.n.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ul></td></tr>'; }).join('') + '</table></div>';
}
function renderAbout() {
  var h = '<h4>What this is</h4><p>System Vault re-generates weak passwords and creates new keys using a mixed cryptographic entropy pool. Everything runs in this page; there is no server.</p>' +
    '<h4>What the numbers mean</h4><p><b>Trusted bits</b> are summed from the real choice space of every CSPRNG decision. Anything kept from a user’s old password counts as zero, because an attacker is assumed to know it. The strength estimate for the <i>old</i> password is a model, not a guarantee.</p>' +
    '<h4>Entropy design</h4><p>Each output byte is <code>crypto.getRandomValues ⊕ SHA-256(pool ∥ counter)</code>. XOR with an independent stream cannot reduce entropy below the CSPRNG; pointer and timing jitter are defence-in-depth. All choices use rejection sampling (no modulo bias), and <code>Math.random</code> is never used.</p>' +
    '<h4>Limits you should know</h4><p>The browser and OS must be trustworthy &mdash; malware or a hostile extension can read the page. Typing a password you still use is a risk you should close by rotating it. A QR code is only as private as the screen it appears on. Clipboard clearing is best-effort.</p>' +
    '<h4>Network</h4><p>The only outbound request is the Contact Admin message when you press SEND. Passwords and keys are never part of it and are never written to storage, exports, or the ledger.</p>' +
    '<h4>Credits</h4><p>Passphrase wordlist: EFF Large Wordlist (Electronic Frontier Foundation, CC BY 3.0 US). Common-password list: SecLists 10k-most-common (Daniel Miessler et al., MIT). Everything else is original to this file.</p>' +
    '<h4>Using your own text</h4><p>In the Key Generator, <b>How should your text be mixed in?</b> puts your base text into the key (append, prepend, hidden inside, or shuffled with the random part). Only the random parts count as trusted bits. Optionally, <b>fold my text into the entropy pool</b> also feeds a SHA-256 hash of it into the pool as an extra source. That adds <b>0 trusted bits</b> (an attacker is assumed to know it) and cannot weaken the output, because every byte is still the CSPRNG XOR a hash of the pool. Purge reseeds the pool so nothing derived from your text stays behind.</p>' +
    '<h4>What changed from v1</h4><p>v1 loaded three CDN scripts and a web font, shuffled with <code>Math.random</code>, used a 776-word list (9.6 bits per word) with modulo bias, counted the user’s own base text as random bits, and showed &ldquo;INFINITY&rdquo; above 80 bits. v2 fixes each.</p>';
  h += changelogHtml(); if ($('abBody')) $('abBody').innerHTML = h; if ($('stAbout')) $('stAbout').innerHTML = h + '<p class="mini">Build ' + APP_VERSION + ' &middot; ' + DICT.words.length + ' words &middot; ' + DICT.common.length + ' common passwords &middot; ' + LEDGER_ALGO + '</p>';
}

/* ---------- memory hygiene ---------- */
function purgeMemory(silent) {
  var i = $('fzIn'), g = $('gnBase'); if (i) { i.value = ''; i.type = 'password'; } if (g) { g.value = ''; g.type = 'password'; }
  vault.result = null; vault.batch = []; vault.batchShown = false; vault.resShown = false; vault.analysis = null; vault.qrText = null; vault.delivered = false; wipePads();
  R.wipe(); R.reseed(); var wq = $('wlQ'); if (wq) { wq.value = ''; wq.type = 'password'; }
  if (silent !== 'tab hidden') { if (clipTimer) { clearTimeout(clipTimer); clipTimer = null; } try { if (window.isSecureContext && navigator.clipboard) navigator.clipboard.writeText(' ').catch(function () {}); } catch (e) {} }
  onFzInput(); onGnCfg(); renderPanel('fortify'); renderPanel('batch'); renderPanel('airgap'); renderPanel('model'); renderHud();
  audit('Purge', silent ? 'Memory wiped automatically (' + silent + ')' : 'Memory purged by user'); if (!silent || silent === 'idle') toast('ok', 'MEMORY PURGED', 'Typed passwords, results and QR contents were wiped from this tab.'); playBeep(300, 'sine', .08, .04);
  S.wtDone.purge = true; save(); renderWalkthrough();
}
function idleTick() {
  var s = prefs.idle; if (!s) return; var holding = holdingSecrets();
  if (holding && (Date.now() - vault.lastAct) / 1000 >= s) { purgeMemory('idle'); vault.lastAct = Date.now(); }
}
var maskStash = [];
/* print path: swap every secret/private figure for dots, hide QR, force secret inputs back to type=password.
   Originals are kept in a JS array (never in a DOM attribute) so a DOM snapshot taken while masked contains no secret. */
function maskAllSecrets() {
  maskStash = [];
  document.querySelectorAll('.secret,.priv').forEach(function (e) { maskStash.push({ el: e, text: e.textContent }); e.textContent = dots(e.textContent.length || 3); });
  document.querySelectorAll('input[type=text]').forEach(function (i) { if (/^(fzIn|gnBase|wlQ)$/.test(i.id)) { i.type = 'password'; maskStash.push({ el: i, type: 'text' }); } });
  document.querySelectorAll('.qrbox').forEach(function (q) { maskStash.push({ el: q, display: q.style.display }); q.style.display = 'none'; });
}
function unmaskSecrets() {
  maskStash.forEach(function (m) { if (m.text !== undefined) m.el.textContent = m.text; else if (m.type) m.el.type = m.type; else if (m.display !== undefined) m.el.style.display = m.display; });
  maskStash = [];
}

/* ---------- configurable character set (shared by Fortify and the generator) ---------- */
function currentCs() { var c = prefs.cs || { on: {}, custom: '', exclude: '' }; return { groups: c.on, custom: c.custom, exclude: c.exclude, noAmbig: !!prefs.ambig }; }
function csEnabled(g) { var v = prefs.cs.on[g.id]; return v === undefined ? !!g.on : !!v; }
function csChanged() {
  S.prefs = prefs; save(); var n = poolString(poolsFor(currentCs())).length;
  audit('Character set', 'pool=' + n + ' chars, ' + (n ? fmt1(Math.log2(n)) : '0') + ' bits/char'); renderCharset();
}
function csToggle(id, v) { prefs.cs.on[id] = v; playBeep(v ? 760 : 420, 'sine', .04, .03); csChanged(); }
function csText(which, v) { prefs.cs[which] = v; csChanged(); }
function csAmbig(v) { prefs.ambig = v; if ($('fzAmbig')) $('fzAmbig').checked = v; csChanged(); }
function csReset() { prefs.cs = { on: {}, custom: '', exclude: '' }; prefs.ambig = false; if ($('fzAmbig')) $('fzAmbig').checked = false; playBeep(440, 'sine', .1, .06); csChanged(); }
function renderCharset() {
  var b = $('csBody'); if (!b) return; var cfg = currentCs(), p = poolsFor(cfg), total = poolString(p).length;
  var rows = GROUP_DEFS.map(function (g) {
    var shown = g.id === 'ext' ? g.chars.length + ' accented letters &amp; symbols' : esc(g.chars.length > 40 ? g.chars.slice(0, 26) : g.chars);
    return '<label class="switch cs-row"><input type="checkbox" ' + (csEnabled(g) ? 'checked' : '') + ' data-on-change="csToggle(\'' + g.id + '\',this.checked)"> <span style="min-width:150px">' + g.label + '</span><span class="mono cs-chars">' + shown + '</span></label>';
  }).join('');
  var customIn = Array.from(prefs.cs.custom || ''), accepted = customIn.filter(function (c) { return c.length === 1 && c > ' ' && c !== '\u007f'; }).length;
  var warns = [];
  if (!total) warns.push('<span class="tag bad">EMPTY</span> No characters available. Enable at least one group.');
  else if (total < 40) warns.push('<span class="tag warn">SMALL POOL</span> Only ' + fmt1(Math.log2(total)) + ' bits per character; results will be longer to reach the same strength.');
  if (csEnabled(GROUP_DEFS[8])) warns.push('<span class="tag warn">QUOTES</span> Quote characters can break scripts, forms and command lines.');
  if (csEnabled(GROUP_DEFS[9]) || customIn.some(function (c) { return c.charCodeAt(0) > 126; })) warns.push('<span class="tag warn">NON-ASCII</span> Accented/extended characters may be rejected by some systems or typed differently on other keyboards.');
  if (customIn.length && accepted < customIn.length) warns.push('<span class="tag">NOTE</span> ' + (customIn.length - accepted) + ' custom character(s) skipped (spaces, controls and emoji are not allowed).');
  b.innerHTML = '<div class="mini" style="margin-bottom:8px">Applies to Fortify and to password mode in the Key Generator. Every character the vault writes comes from this set; trusted bits are computed from the real pool size.</div>' + rows +
    '<div class="row2" style="margin-top:12px"><div class="field"><label class="ctrl-label" for="csCustom">Custom characters</label><input type="text" id="csCustom" class="mono" maxlength="64" spellcheck="false" autocomplete="off" value="' + esc(prefs.cs.custom || '') + '" data-on-change="csText(\'custom\',this.value)" placeholder="e.g. \u00A7\u00B5\u20AC"></div>' +
    '<div class="field"><label class="ctrl-label" for="csExclude">Exclude these characters</label><input type="text" id="csExclude" class="mono" maxlength="64" spellcheck="false" autocomplete="off" value="' + esc(prefs.cs.exclude || '') + '" data-on-change="csText(\'exclude\',this.value)" placeholder="e.g. l1O0"></div></div>' +
    '<label class="switch"><input type="checkbox" ' + (prefs.ambig ? 'checked' : '') + ' data-on-change="csAmbig(this.checked)"> avoid look-alike characters (Il1O0o|)</label>' +
    '<div class="resultbox" style="margin-top:12px"><div class="kv"><span>Pool size</span><b>' + total + ' characters</b><span>Bits per character</span><b>' + (total ? fmt1(Math.log2(total)) : '0') + '</b><span>By class</span><b>' + p.lower.length + ' lower \u00B7 ' + p.upper.length + ' upper \u00B7 ' + p.digit.length + ' digit \u00B7 ' + p.sym.length + ' special</b></div>' + (warns.length ? '<div style="margin-top:8px">' + warns.map(function (w) { return '<div class="find"><span>' + w + '</span></div>'; }).join('') + '</div>' : '') + '</div>' +
    '<div class="btnrow" style="margin-top:10px"><button class="btn sm" data-on-click="csReset()">RESET TO DEFAULTS</button></div>';
}

/* ===================== APP: pattern-lock input (Fortify + generator base) =====================
   A drawn pattern is treated exactly like a typed weak password: held only in memory (vault.pattern / vault.gnPattern),
   never stored, never logged, hidden once drawn unless revealed, wiped on purge / idle / tab-hide, and not printed. */
vault.src = 'type'; vault.pattern = null; vault.gnSrc = 'type'; vault.gnPattern = null; vault.pads = {};
if (!prefs.grid) prefs.grid = 3;

function holdingSecrets() {
  return !!(vault.result || vault.batch.length || vault.pattern || vault.gnPattern || ($('fzIn') && $('fzIn').value) || ($('gnBase') && $('gnBase').value));
}
function gridInfoText(n) {
  var c = PAT.COUNTS[n];
  return n + '×' + n + ' grid: ' + (PAT.EXACT[n] ? c.toLocaleString('en-US') : '≈ ' + c.toExponential(2).replace('e+', '×10^')) + ' possible patterns (' + (PAT.EXACT[n] ? 'exact' : 'sampling estimate') + ') · at most ' + PAT.limitBits(n).toFixed(1) + ' bits';
}

/* ---------- the drawing pad ---------- */
function mountPad(key, hostId, onChange) {
  var host = $(hostId); if (!host) return null;
  var SZ = 260, PAD = 32;
  host.innerHTML = '<div class="patpad noprint"><div class="btnrow" style="margin-bottom:8px;align-items:center"><span class="ctrl-label" style="margin:0">Grid</span>' +
    '<select id="' + key + 'Grid" style="width:auto">' + [3, 4, 5, 6].map(function (n) { return '<option value="' + n + '">' + n + '×' + n + '</option>'; }).join('') + '</select>' +
    '<button type="button" class="btn sm" id="' + key + 'Rev">👁 Reveal</button><button type="button" class="btn sm" id="' + key + 'Clr">Clear</button></div>' +
    '<canvas class="patcv" id="' + key + 'Cv" width="' + SZ + '" height="' + SZ + '" aria-label="Pattern drawing pad"></canvas>' +
    '<div class="mini" id="' + key + 'Msg" style="margin-top:6px"></div>' +
    '<div class="inwrap" style="margin-top:8px"><input type="password" id="' + key + 'Seq" class="mono" spellcheck="false" autocomplete="off" autocapitalize="off" data-lpignore="true" data-1p-ignore="true" placeholder="or type the dot numbers, e.g. 1-5-9-6"></div>' +
    '<div class="mini" id="' + key + 'Info" style="margin-top:6px"></div></div>';
  var cv = $(key + 'Cv'), ctx = cv.getContext('2d'), dpr = window.devicePixelRatio || 1;
  cv.width = SZ * dpr; cv.height = SZ * dpr; cv.style.width = SZ + 'px'; cv.style.height = SZ + 'px'; ctx.scale(dpr, dpr);
  var p = { n: prefs.grid || 3, path: [], drawing: false, done: false, reveal: false, cur: null, msg: '', lastT: 0 };
  $(key + 'Grid').value = String(p.n);
  function step() { return (SZ - 2 * PAD) / (p.n - 1); }
  function ctr(i) { return { x: PAD + (i % p.n) * step(), y: PAD + Math.floor(i / p.n) * step() }; }
  function hit(x, y) { var r = Math.min(step() * 0.42, 30); for (var i = 0; i < p.n * p.n; i++) { var c = ctr(i); if (Math.hypot(c.x - x, c.y - y) <= r) return i; } return -1; }
  function setMsg() { var m = $(key + 'Msg'); if (m) m.textContent = p.msg; $(key + 'Info').textContent = gridInfoText(p.n); $(key + 'Rev').innerHTML = p.reveal ? '🙈 Hide' : '👁 Reveal'; }
  function draw() {
    var cs = getComputedStyle(document.documentElement), acc = cs.getPropertyValue('--accent').trim() || '#2fe6d0', dim = cs.getPropertyValue('--line-2').trim() || '#1e3345', ink = cs.getPropertyValue('--ink-dim').trim() || '#8ba2b8';
    ctx.clearRect(0, 0, SZ, SZ);
    var showLines = p.drawing || p.reveal;
    if (showLines && p.path.length) {
      ctx.strokeStyle = acc; ctx.lineWidth = 4; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.beginPath();
      p.path.forEach(function (i, k) { var c = ctr(i); if (k) ctx.lineTo(c.x, c.y); else ctx.moveTo(c.x, c.y); });
      if (p.drawing && p.cur) ctx.lineTo(p.cur.x, p.cur.y);
      ctx.stroke();
    }
    for (var i = 0; i < p.n * p.n; i++) {
      var c = ctr(i), on = showLines && p.path.indexOf(i) >= 0;
      ctx.beginPath(); ctx.arc(c.x, c.y, on ? 9 : 6.5, 0, 6.2832); ctx.fillStyle = on ? acc : dim; ctx.fill();
      if (p.n <= 4 && !on) { ctx.fillStyle = ink; ctx.globalAlpha = .55; ctx.font = '9px monospace'; ctx.textAlign = 'center'; ctx.fillText(String(i + 1), c.x, c.y - 11); ctx.globalAlpha = 1; }
    }
  }
  function commit() {
    var path = p.path.slice();
    if (path.length < PAT.MIN) { p.msg = path.length ? 'Too short: connect at least ' + PAT.MIN + ' dots.' : ''; p.path = []; p.done = false; onChange(null); }
    else { p.done = true; p.msg = 'Pattern captured · ' + path.length + ' dots' + (p.reveal ? '' : ' (hidden)') + '.'; onChange(path, p.n); }
    setMsg(); draw();
  }
  function pos(e) { var r = cv.getBoundingClientRect(); return { x: (e.clientX - r.left) * SZ / r.width, y: (e.clientY - r.top) * SZ / r.height }; }
  function feed(e) {
    var q = pos(e); p.cur = q; var i = hit(q.x, q.y);
    if (i >= 0 && p.path.indexOf(i) < 0) {
      var np = PAT.expand(p.n, p.path.concat([i]));
      if (np) { p.path = np; playBeep(480 + p.path.length * 45, 'sine', .04, .02); R.jitter('pointer', [Math.floor((e.timeStamp - p.lastT) * 1000) & 0xffff]); p.lastT = e.timeStamp; }
    }
    draw();
  }
  cv.addEventListener('pointerdown', function (e) { e.preventDefault(); try { cv.setPointerCapture(e.pointerId); } catch (x) {} touch(); p.path = []; p.done = false; p.drawing = true; p.msg = ''; p.lastT = e.timeStamp; $(key + 'Seq').value = ''; feed(e); });
  cv.addEventListener('pointermove', function (e) { if (p.drawing) feed(e); });
  function end() { if (!p.drawing) return; p.drawing = false; p.cur = null; commit(); }
  cv.addEventListener('pointerup', end); cv.addEventListener('pointercancel', end);
  $(key + 'Clr').addEventListener('click', function () { api.clear(); });
  $(key + 'Rev').addEventListener('click', function () { p.reveal = !p.reveal; if (p.done) p.msg = 'Pattern captured · ' + p.path.length + ' dots' + (p.reveal ? '' : ' (hidden)') + '.'; setMsg(); draw(); });
  $(key + 'Grid').addEventListener('change', function () { p.n = +this.value; prefs.grid = p.n; S.prefs = prefs; save(); api.clear(); Object.keys(vault.pads).forEach(function (k) { var o = vault.pads[k]; if (o !== api && o.n() !== p.n) o.setGrid(p.n); }); });
  $(key + 'Seq').addEventListener('input', function () {
    touch(); var r = PAT.parseSeq(p.n, this.value);
    if (!r) { p.path = []; p.done = false; p.msg = ''; onChange(null); }
    else if (r.error) { p.path = []; p.done = false; p.msg = r.error; onChange(null); }
    else { p.path = r.path; commit(); }
    setMsg(); draw();
  });
  var api = {
    clear: function () { p.path = []; p.done = false; p.drawing = false; p.msg = ''; $(key + 'Seq').value = ''; onChange(null); setMsg(); draw(); },
    n: function () { return p.n; },
    setGrid: function (n) { p.n = n; $(key + 'Grid').value = String(n); api.clear(); },
    redraw: draw
  };
  vault.pads[key] = api; setMsg(); draw(); return api;
}
function wipePads() { vault.pattern = null; vault.gnPattern = null; Object.keys(vault.pads).forEach(function (k) { vault.pads[k].clear(); }); }

/* ---------- Fortify: input method ---------- */
function patternAnalysis(path, n) { return PAT.analyze(n, path); }
function onFzPattern(path, n) {
  vault.pattern = path ? path.slice() : null; vault.patternN = n || (vault.pads.fz ? vault.pads.fz.n() : 3);
  vault.analysis = path ? patternAnalysis(path, vault.patternN) : null;
  renderPanel('weakness'); renderPanel('model'); renderHud();
}
function setFzSrc(s) {
  vault.src = s; playBeep(s === 'pattern' ? 760 : 560, 'sine', .04, .03);
  document.querySelectorAll('#fzSrc button').forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-s') === s); });
  var pat = s === 'pattern';
  $('fzTypeBox').style.display = pat ? 'none' : ''; $('fzSimBox').style.display = pat ? 'none' : ''; $('fzPatBox').style.display = pat ? '' : 'none';
  if (pat) { vault.analysis = vault.pattern ? patternAnalysis(vault.pattern, vault.patternN || 3) : null; renderPanel('weakness'); renderPanel('model'); renderHud(); }
  else onFzInput();
}

/* weakness report for a pattern: numbers marked private are hidden when printing; nothing here reveals the shape */
function renderPatternWeakness() {
  var b = $('wkBody'); if (!b) return; var a = vault.analysis;
  var f = a.weak.map(function (w) { return '<div class="find"><span class="sv ' + w.sev + '">' + w.sev.toUpperCase() + '</span><span>' + esc(w.msg) + '</span></div>'; }).join('');
  b.innerHTML = '<div class="kv"><span>Input</span><b>Pattern · ' + a.grid + '×' + a.grid + ' grid</b><span>Dots</span><b>' + a.len + '</b><span>Grid maximum</span><b>' + a.theoBits.toFixed(1) + ' bits (' + (PAT.EXACT[a.grid] ? 'exact' : 'estimated') + ' count)</b><span>This pattern, if random</span><b>' + priv(a.naiveBits.toFixed(1) + ' bits') + '</b><span>Modelled estimate</span><b>' + priv(fmt1(a.estBits)) + ' (' + a.label + ')</b></div>' +
    '<div class="ctrl-label" style="margin-top:12px">Findings (' + a.weak.length + ')</div>' + f +
    '<div class="mini" style="margin-top:8px">A pattern has no words to keep, so Fortify always produces a Fresh password from a pattern. Figures marked private are hidden when printing.</div>';
}
function renderWeakness() { if (vault.analysis && vault.analysis.isPattern) renderPatternWeakness(); else renderWeaknessTyped(); }

/* ---------- Generator: base modifier from a pattern ---------- */
function currentBase() {
  if (vault.gnSrc === 'pattern') return vault.gnPattern ? PAT.toSymbols(vault.gnPattern) : '';
  return $('gnBase').value;
}
function baseAnalysis(base) { return (vault.gnSrc === 'pattern' && vault.gnPattern) ? PAT.analyze(vault.gnPatternN || 3, vault.gnPattern) : analyze(base); }
function onGnPattern(path, n) { vault.gnPattern = path ? path.slice() : null; vault.gnPatternN = n || (vault.pads.gn ? vault.pads.gn.n() : 3); onGnCfg(); }
function toggleGnPattern() {
  var pat = vault.gnSrc !== 'pattern'; vault.gnSrc = pat ? 'pattern' : 'type';
  $('gnPadHost').style.display = pat ? '' : 'none'; $('gnBase').closest('.inwrap').style.display = pat ? 'none' : '';
  $('gnSrcBtn').innerHTML = pat ? '⌨ Type the base instead' : '✍ Use a pattern instead';
  playBeep(pat ? 760 : 560, 'sine', .04, .03); onGnCfg();
}
function mountPatternPads() { mountPad('fz', 'fzPadHost', onFzPattern); mountPad('gn', 'gnPadHost', onGnPattern); }

/* ===================== APP: chrome, views, walkthrough, splash, palette, settings, boot ===================== */
var PANELS = [
  { id: 'fortify', name: 'Fortify Password', ic: '🔒', r: renderFortifyResult },
  { id: 'weakness', name: 'Weakness Report', ic: '🔍', r: renderWeakness },
  { id: 'model', name: 'Strength &amp; Brute-Force Model', ic: '⏱', r: renderModel },
  { id: 'generator', name: 'Key Generator', ic: '🔑', r: function () { syncGenUI(); } },
  { id: 'charset', name: 'Character Set', ic: '\uD83D\uDD24', r: renderCharset },
  { id: 'batch', name: 'Batch Output', ic: '📦', r: renderBatch },
  { id: 'sources', name: 'Entropy Sources', ic: '📡', r: renderSources },
  { id: 'wordlist', name: 'Wordlist Inspector', ic: '📖', r: renderWordlist },
  { id: 'airgap', name: 'Airgap QR Transfer', ic: '📱', r: redrawQr },
  { id: 'policy', name: 'Policy Presets', ic: '📋', r: renderPolicy },
  { id: 'rotate', name: 'Rotation Checklist', ic: '✅', r: renderRotate },
  { id: 'activity', name: 'Session Activity', ic: '📈', r: renderActivity },
  { id: 'ledger', name: 'Audit Ledger', ic: '🔐', r: renderLedger },
  { id: 'about', name: 'About &amp; Security Notes', ic: 'ℹ', r: renderAbout }
];
function pById(id) { return PANELS.filter(function (p) { return p.id === id; })[0]; }
function panelEl(id) { return $('panel_' + id); }
function renderPanel(id) { var p = pById(id); if (!p || !p.r) return; var el = panelEl(id); if (!el) return; try { p.r(); } catch (e) { console.error('panel ' + id, e); } }
function syncGenUI() {
  $('gnLen').value = prefs.gnLen; $('gnWords').value = prefs.gnWords; $('gnSep').value = prefs.gnSep; $('gnComb').value = prefs.gnComb; $('gnFold').checked = !!prefs.gnFold;
  $('gnCap').checked = prefs.gnCap; $('gnNum').checked = prefs.gnNum; $('gnSym').checked = prefs.gnSym; onGnCfg();
}

/* ---------- panel chrome ---------- */
function buildPanelHeads() {
  PANELS.forEach(function (p) {
    var el = panelEl(p.id); if (!el || el.querySelector('.phead')) return;
    var h = document.createElement('div'); h.className = 'phead';
    h.innerHTML = '<span class="ic">' + p.ic + '</span><h3>' + p.name + '</h3><div class="pctl"><button class="rowbtn" title="Move up" data-on-click="movePanel(\'' + p.id + '\',-1)">▲</button><button class="rowbtn" title="Move down" data-on-click="movePanel(\'' + p.id + '\',1)">▼</button><button class="rowbtn" title="Collapse / expand" data-on-click="toggleCollapse(\'' + p.id + '\')">▾</button><button class="rowbtn" title="Hide" data-on-click="hidePanel(\'' + p.id + '\')">✕</button></div>';
    el.insertBefore(h, el.firstChild);
  });
}
function applyOrder() {
  var g = $('grid'), ids = (S.order || []).filter(function (id) { return pById(id); });
  PANELS.forEach(function (p) { if (ids.indexOf(p.id) < 0) ids.push(p.id); }); S.order = ids;
  ids.forEach(function (id) { var el = panelEl(id); if (el) g.appendChild(el); });
}
function movePanel(id, d) { var o = S.order, i = o.indexOf(id), j = i + d; if (j < 0 || j >= o.length) return; o.splice(i, 1); o.splice(j, 0, id); save(); applyOrder(); playBeep(560, 'sine', .04, .025); }
function toggleCollapse(id) {
  var el = id === 'walkthrough' ? $('panel-walkthrough') : panelEl(id); if (!el) return;
  var c = el.getAttribute('data-collapsed') === '1' ? '0' : '1'; el.setAttribute('data-collapsed', c); S.collapsed[id] = c === '1'; save(); playBeep(c === '1' ? 520 : 700, 'sine', .04, .025);
}
/* The opening page is the user's choice (Settings > Opening page, saved in prefs.startPage). The chosen panel opens under the banner; the status HUD shows for every choice except "home".
   "tour" = the original standard trio (banner, HUD, guided walkthrough). "home" = the original layout (banner only). Any other page hides the walkthrough unless prefs.startWt is on. */
var START_PAGES = [['fortify', 'Fortify a password', '🔒'], ['generator', 'Key generator', '🔑'], ['sources', 'Entropy sources', '📡'], ['tour', 'Guided tour (walkthrough)', '🧭'], ['home', 'Home banner only (original layout)', '🔐']];
function startPageId() { var p = prefs.startPage; return START_PAGES.some(function (x) { return x[0] === p; }) ? p : 'fortify'; }
function startPageName() { return START_PAGES.filter(function (x) { return x[0] === startPageId(); })[0][1].replace(/ \(.*\)$/, ''); }
function applyDefaultView() {
  S.hidden = {}; PANELS.forEach(function (p) { S.hidden[p.id] = true; }); S.tray = []; S.view = 'grid';
  var sp = startPageId(), wtOn = sp === 'tour' || !!prefs.startWt;
  if (sp !== 'tour' && sp !== 'home') S.hidden[sp] = false;
  var hud = $('heroHud'); if (hud) hud.setAttribute('data-hidden', sp === 'home' ? '1' : '0');
  var wt = $('panel-walkthrough'); if (wt) { wt.setAttribute('data-hidden', wtOn ? '0' : '1'); wt.setAttribute('data-collapsed', '0'); }
  if (wtTimer) wtStop();
  save();
}
function setStartPage(id, quiet) { prefs.startPage = id; saveUI(); if (!quiet) { audit('Settings', 'Opening page set to ' + startPageName()); toast('ok', 'OPENING PAGE', startPageName() + '. Applies on every page load; press Default View to see it now.'); } }
function defaultView() { applyDefaultView(); render(); window.scrollTo({ top: 0, behavior: 'smooth' }); playBeep(560, 'sine', .06, .03); audit('Layout', 'Default view restored (' + startPageName() + ')'); toast('ok', 'DEFAULT VIEW', startPageName() + '.'); }
function hideAllPanels() { defaultView(); }
function showAll() { PANELS.forEach(function (p) { S.hidden[p.id] = false; }); S.tray = []; save(); render(); playBeep(880, 'sine', .07, .04); audit('Layout', 'Show all panels'); }
function hidePanel(id) {
  S.hidden[id] = true; S.tray = (S.tray || []).filter(function (x) { return x !== id; }); S.tray.unshift(id); if (S.tray.length > 8) S.tray.length = 8;
  playBeep(420, 'sine', .05, .03); audit('Panel ' + id, 'Hidden'); render();
}
function togglePanel(id) { S.hidden[id] = !S.hidden[id]; if (!S.hidden[id]) S.tray = (S.tray || []).filter(function (x) { return x !== id; }); playBeep(S.hidden[id] ? 420 : 760, 'sine', .05, .03); render(); }
function openPanel(id) {
  if (S.hidden[id]) { S.hidden[id] = false; S.tray = (S.tray || []).filter(function (x) { return x !== id; }); render(); }
  var el = panelEl(id); if (el && el.getAttribute('data-collapsed') === '1') toggleCollapse(id);
  renderPanel(id); setTimeout(function () { jumpTo('panel_' + id); }, 40); if (id === 'fortify') setTimeout(function () { var i = $('fzIn'); if (i) i.focus(); }, 380);
}
function jumpTo(domId) {
  if (domId === 'panel-walkthrough' || domId === 'heroHud') { var w = $(domId); if (w.getAttribute('data-hidden') === '1') { w.setAttribute('data-hidden', '0'); w.setAttribute('data-collapsed', '0'); if (domId === 'heroHud') renderHud(); else renderWalkthrough(); } }
  var el = $(domId); if (!el) return; var off = ($('topbar').offsetHeight || 54) + 8; window.scrollTo({ top: Math.max(0, el.getBoundingClientRect().top + window.pageYOffset - off), behavior: 'smooth' }); }
function renderChips() {
  var c = $('jumpChips'); if (!c) return;
  var comp = [['homeBanner', '🔐 Home'], ['heroHud', '📡 HUD'], ['panel-walkthrough', '🧭 Walkthrough']];
  c.innerHTML = comp.map(function (x) { return '<span class="chip jumpchip" data-jump="' + x[0] + '" data-on-click="jumpTo(\'' + x[0] + '\')">' + x[1] + '</span>'; }).join('') +
    PANELS.map(function (p) { return '<span class="chip jumpchip ' + (S.hidden[p.id] ? 'hidden-p' : '') + '" title="' + (S.hidden[p.id] ? 'Hidden — click to open' : 'Jump') + '" data-on-click="openPanel(\'' + p.id + '\')">' + p.ic + ' ' + stripTags(p.name) + '</span>'; }).join('');
}
function renderTray() {
  var t = $('hiddenTray'); if (!t) return; t.innerHTML = '';
  var recent = (S.tray || []).filter(function (id) { return S.hidden[id]; });
  recent.forEach(function (id) { var p = pById(id); if (!p) return; var b = document.createElement('button'); b.className = 'trchip'; b.textContent = '↺ ' + stripTags(p.name); b.title = 'Restore this panel'; b.onclick = function () { togglePanel(id); setTimeout(function () { jumpTo('panel_' + id); }, 60); }; t.appendChild(b); });
  var extra = PANELS.filter(function (p) { return S.hidden[p.id]; }).length - recent.length;
  if (extra > 0) { var b2 = document.createElement('button'); b2.className = 'trchip'; b2.textContent = '▦ +' + extra + ' more'; b2.onclick = toggleChipDrawer; t.appendChild(b2); }
}
function toggleChipDrawer() {
  var d = $('chipDrawer'); d.classList.toggle('open');
  d.innerHTML = PANELS.map(function (p) { return '<label><input type="checkbox" ' + (S.hidden[p.id] ? '' : 'checked') + ' data-on-change="togglePanel(\'' + p.id + '\')"> ' + p.ic + ' ' + p.name + '</label>'; }).join('');
  playBeep(d.classList.contains('open') ? 700 : 520, 'sine', .04, .025);
}
function setView(v, quiet) { S.view = v; document.body.setAttribute('data-view', v); document.querySelectorAll('#viewSw button').forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-v') === v); }); save(); if (!quiet) playBeep(640, 'sine', .05, .03); if (v === 'ledger') { renderPanel('ledger'); renderPanel('activity'); } }
function render() {
  PANELS.forEach(function (p) { var el = panelEl(p.id); if (!el) return; el.setAttribute('data-hidden', S.hidden[p.id] ? '1' : '0'); el.setAttribute('data-collapsed', S.collapsed[p.id] ? '1' : '0'); if (!S.hidden[p.id]) renderPanel(p.id); });
  if (S.collapsed.walkthrough) $('panel-walkthrough').setAttribute('data-collapsed', '1');
  renderChips(); renderTray(); renderHud(); renderStatus(); renderWalkthrough(); setView(S.view || 'grid', true); wireTilt('.gpanel');
}
function measureTopbar() { var h = $('topbar').offsetHeight; document.documentElement.style.setProperty('--topbar-h', h + 'px'); }

/* ---------- HUD / KPIs / status ---------- */
function kpiHtml() {
  var k = [[R.ok ? 'OK' : 'NONE', 'CSPRNG'], [HAS_SUBTLE ? 'WEBCRYPTO' : 'JS-SHA256', 'HASH'], [WORD_BITS.toFixed(1) + ' b', 'PER WORD'], [S.audit.length, 'LEDGER BLOCKS']];
  return k.map(function (x) { return '<div class="gkpi"><div class="v">' + x[0] + '</div><div class="l">' + x[1] + '</div></div>'; }).join('');
}
function ringSvg(pct, label) {
  var r = 22, c = 2 * Math.PI * r, off = c * (1 - pct / 100);
  return '<div class="ring"><svg width="56" height="56" viewBox="0 0 56 56"><circle cx="28" cy="28" r="' + r + '" fill="none" stroke="var(--line-2)" stroke-width="5"/><circle cx="28" cy="28" r="' + r + '" fill="none" stroke="var(--accent)" stroke-width="5" stroke-linecap="round" stroke-dasharray="' + c.toFixed(1) + '" stroke-dashoffset="' + off.toFixed(1) + '" transform="rotate(-90 28 28)"/><text x="28" y="32" text-anchor="middle" class="rv">' + Math.round(pct) + '</text></svg><div class="rl">' + label + '</div></div>';
}
function renderHud() {
  var v = $('hudVerdict'); if (!v) return; var r = vault.result;
  var active = 2 + (R.enabled.pointer ? 1 : 0) + (R.enabled.key ? 1 : 0);
  var rings = [ringSvg(active / 4 * 100, 'Sources'), ringSvg(vault.analysis ? 100 : 0, 'Analyse'), ringSvg(r ? Math.min(100, r.trustedBits / r.floor * 100) : 0, 'Harden'), ringSvg(vault.delivered ? 100 : 0, 'Deliver')];
  $('hudRings').innerHTML = rings.join(''); $('hudKpis').innerHTML = kpiHtml(); var wk = $('wKpis'); if (wk) wk.innerHTML = kpiHtml();
  v.textContent = r ? 'Fortified · ' + fmt1(r.trustedBits) + ' trusted bits' : vault.analysis ? 'Analysed · ' + vault.analysis.label + ' (' + fmt1(vault.analysis.estBits) + ' bits)' : 'Vault ready · awaiting input';
  var l = $('hudLamp'); l.className = 'lamp' + (!R.ok ? ' bad' : (vault.analysis && vault.analysis.estBits < 40 && !r) ? ' warn' : '');
}
function renderStatus() {
  var s = $('statusbar'); if (!s) return; var st = R.stats;
  s.innerHTML = '<span class="st-item ' + (R.ok ? 'ok' : 'warn') + '">CSPRNG <b>' + (R.ok ? 'OK' : 'MISSING') + '</b></span><span class="st-item">LEDGER <b>' + (HAS_SUBTLE ? 'SHA-256' : 'SHA-256 (JS)') + ' · ' + S.audit.length + ' blocks</b></span><span class="st-item">POOL <b>' + st.folds + ' folds · ' + (st.pointer + st.key + st.timing) + ' jitter</b></span><span class="st-item ' + ((vault.result || vault.batch.length) ? 'warn' : '') + '">MEMORY <b>' + ((vault.result || vault.batch.length) ? 'HOLDING SECRETS' : 'CLEAN') + '</b></span><span class="st-item">IDLE WIPE <b>' + (prefs.idle ? prefs.idle + ' s' : 'off') + '</b></span><span class="st-item" style="margin-left:auto">v' + APP_VERSION + '</span>';
}
function updateClocks() {
  var d = new Date(), pt = ptParts(d), t = pt.hour + ':' + pt.minute + ':' + pt.second;
  ['clock', 'wClock'].forEach(function (i) { var e = $(i); if (e) e.innerHTML = pt.timeZoneName + ' <b>' + t + '</b>'; });
  var age = Math.floor((Date.now() - vault.started) / 1000), a = $('hudAge');
  if (a) a.textContent = 'session ' + ('0' + Math.floor(age / 3600)).slice(-2) + ':' + ('0' + Math.floor(age / 60) % 60).slice(-2) + ':' + ('0' + age % 60).slice(-2) + ' · ' + pt.year + '-' + pt.month + '-' + pt.day;
  if (S.hidden && !S.hidden.sources) renderSources(); renderStatus(); idleTick();
}

/* ---------- walkthrough ---------- */
var WT_STEPS = [
  { id: 'enter', t: 'Enter the existing password', go: 'fortify', x: 'In Fortify, type or paste the password the user already has. It stays in this tab only — never stored, logged or sent.' },
  { id: 'analyze', t: 'Read the weakness report', go: 'weakness', x: 'The offline model tokenises the password and names what makes it guessable: common-list hits, keyboard walks, years, predictable leet.' },
  { id: 'mode', t: 'Choose how similar to stay', go: 'fortify', x: 'Echo keeps the recognisable words, Shape keeps only the layout, Fresh keeps nothing. More similarity means fewer trusted bits per character.' },
  { id: 'mix', t: 'Mix in your own entropy', go: 'sources', x: 'Move the pointer over the entropy pad. Timing jitter is hashed into the pool and XORed with the CSPRNG — it can add, never subtract.' },
  { id: 'run', t: 'Fortify', go: 'fortify', x: 'Press FORTIFY. The vault builds the new password, rejection-samples every choice, and extends it until the trusted-bit floor is met.' },
  { id: 'review', t: 'Review the trusted bits', go: 'model', x: 'Compare original vs fortified against three stated attacker models. Only CSPRNG-drawn bits count.' },
  { id: 'deliver', t: 'Copy or show as QR', go: 'airgap', x: 'Copy (with timed clipboard clearing) or move it to a phone via the Airgap QR. Then actually change the password on the real system.' },
  { id: 'purge', t: 'Purge memory', go: 'fortify', x: 'Wipe the typed password, results and QR from the tab. It also happens automatically when idle or when the tab is hidden.' },
  { id: 'verify', t: 'Verify the audit ledger', go: 'ledger', x: 'Every action is a hash-chained block of metadata. Verify walks the chain and names the first broken block, if any.' }
];
var WT_TOTAL_STEPS = WT_STEPS.length, wtIdx = 0, wtTimer = null;
function wtDoneCount() { return Object.keys(S.wtDone || {}).filter(function (k) { return S.wtDone[k]; }).length; }
function toggleDone(id) { S.wtDone[id] = !S.wtDone[id]; save(); playBeep(S.wtDone[id] ? 760 : 420, 'sine', .04, .03); if (wtDoneCount() === WT_TOTAL_STEPS) fireConfetti(); renderWalkthrough(); renderHud(); }
function wtScene(i) {
  var A = 'var(--accent)', V = 'var(--guide-violet)', G = 'var(--guide-gold)', L = 'var(--line-2)', sc = '<svg viewBox="0 0 280 170" role="img" aria-label="Step ' + (i + 1) + ' illustration">' + '<rect x="2" y="2" width="276" height="166" rx="12" fill="none" stroke="' + L + '"/>', e = '</svg>';
  var scenes = [
    sc + '<rect x="40" y="62" width="200" height="38" rx="8" fill="none" stroke="' + A + '" stroke-width="2"/><text x="56" y="87" font-family="monospace" font-size="16" fill="' + G + '">Summer2024!</text><rect class="scn-pulse" x="168" y="72" width="3" height="18" fill="' + A + '"/><text x="40" y="130" font-family="monospace" font-size="10" fill="var(--muted)">stays in this tab only</text>' + e,
    sc + '<g font-family="monospace" font-size="12"><rect x="30" y="40" width="70" height="26" rx="6" fill="none" stroke="' + G + '"/><text x="40" y="58" fill="' + G + '">Summer</text><rect x="108" y="40" width="50" height="26" rx="6" fill="none" stroke="' + A + '"/><text x="118" y="58" fill="' + A + '">2024</text><rect x="166" y="40" width="26" height="26" rx="6" fill="none" stroke="' + V + '"/><text x="173" y="58" fill="' + V + '">!</text></g><path class="scn-dash" d="M60 78v30M133 78v30M179 78v30" stroke="var(--danger)" stroke-width="2" fill="none"/><text x="30" y="132" font-family="monospace" font-size="10" fill="var(--danger)">season + year = first guess</text>' + e,
    sc + '<g font-family="monospace" font-size="11" text-anchor="middle"><rect x="26" y="50" width="68" height="50" rx="8" fill="none" stroke="' + A + '" stroke-width="2"/><text x="60" y="80" fill="' + A + '">ECHO</text><rect x="106" y="50" width="68" height="50" rx="8" fill="none" stroke="' + V + '"/><text x="140" y="80" fill="' + V + '">SHAPE</text><rect x="186" y="50" width="68" height="50" rx="8" fill="none" stroke="' + G + '"/><text x="220" y="80" fill="' + G + '">FRESH</text></g><rect x="26" y="118" width="228" height="6" rx="3" fill="var(--raise)"/><rect class="scn-pulse" x="26" y="118" width="120" height="6" rx="3" fill="' + A + '"/>' + e,
    sc + '<circle cx="140" cy="85" r="34" fill="none" stroke="' + A + '" stroke-width="2"/><g stroke="' + G + '" stroke-width="2" fill="none"><path class="scn-dash" d="M30 40Q80 20 110 70"/><path class="scn-dash" d="M250 130Q200 150 170 100"/><path class="scn-dash" d="M30 140Q70 120 108 98"/></g><text x="140" y="90" text-anchor="middle" font-family="monospace" font-size="14" fill="' + A + '">⊕</text>' + e,
    sc + '<rect x="50" y="56" width="180" height="40" rx="8" fill="rgba(47,230,208,.08)" stroke="' + A + '" stroke-width="2"/><text x="64" y="82" font-family="monospace" font-size="13" fill="var(--accent-2)">k7#Mq2•••••••••</text><circle class="scn-pulse" cx="140" cy="130" r="8" fill="' + A + '"/>' + e,
    sc + '<g stroke="' + L + '"><path d="M36 130h208M36 100h208M36 70h208"/></g><rect x="60" y="116" width="40" height="14" fill="var(--danger)"/><rect x="140" y="50" width="40" height="80" fill="' + A + '"/><text x="60" y="146" font-family="monospace" font-size="9" fill="var(--muted)">before</text><text x="140" y="146" font-family="monospace" font-size="9" fill="var(--muted)">after</text>' + e,
    sc + '<rect x="96" y="30" width="88" height="88" rx="6" fill="#fff"/><g fill="#000"><rect x="104" y="38" width="22" height="22"/><rect x="154" y="38" width="22" height="22"/><rect x="104" y="88" width="22" height="22"/><rect x="132" y="66" width="10" height="10"/><rect x="148" y="82" width="12" height="12"/><rect x="164" y="98" width="10" height="10"/></g><text x="140" y="146" text-anchor="middle" font-family="monospace" font-size="10" fill="var(--muted)">scan, don’t copy</text>' + e,
    sc + '<rect x="70" y="40" width="140" height="70" rx="10" fill="none" stroke="var(--danger)" stroke-width="2"/><path class="scn-dash" d="M96 62l88 26M184 62l-88 26" stroke="var(--danger)" stroke-width="3"/><text x="140" y="138" text-anchor="middle" font-family="monospace" font-size="10" fill="var(--muted)">memory wiped</text>' + e,
    sc + '<g fill="none" stroke="' + A + '" stroke-width="2"><rect x="24" y="62" width="44" height="40" rx="6"/><rect x="118" y="62" width="44" height="40" rx="6"/><rect x="212" y="62" width="44" height="40" rx="6"/></g><path class="scn-dash" d="M68 82h50M162 82h50" stroke="' + G + '" stroke-width="2"/><text x="140" y="138" text-anchor="middle" font-family="monospace" font-size="10" fill="var(--accent-2)">hash → hash → hash</text>' + e
  ];
  return scenes[i];
}
function wtAuto() {
  var ch = false; function m(k, c) { if (c && !S.wtDone[k]) { S.wtDone[k] = true; ch = true; } }
  var fi = $('fzIn'); m('enter', fi && fi.value.length > 0); m('analyze', !!vault.analysis); m('mix', R.stats.pointer >= 20); m('run', !!vault.result); m('review', !!vault.result && !S.hidden.model); m('deliver', vault.delivered);
  if (ch) save();
}
function renderWalkthrough() {
  var c = $('wtCard'); if (!c) return; wtAuto(); var s = WT_STEPS[wtIdx], done = !!S.wtDone[s.id], n = wtDoneCount();
  $('wtScene').innerHTML = wtScene(wtIdx);
  c.innerHTML = '<div class="wtn">STEP ' + (wtIdx + 1) + ' OF ' + WT_TOTAL_STEPS + (done ? ' · ✓ DONE' : '') + '</div><h4>' + esc(s.t) + '</h4><p>' + esc(s.x) + '</p><div class="btnrow"><button class="btn sm" data-on-click="wtGo(-1)">← Prev</button><button class="btn sm" data-on-click="wtGo(1)">Next →</button><button class="btn sm primary" data-on-click="openPanel(\'' + s.go + '\')">Open panel</button><button class="btn sm" data-on-click="toggleDone(\'' + s.id + '\')">' + (done ? 'Mark not done' : 'Mark done') + '</button></div>';
  $('wtBar').style.width = (n / WT_TOTAL_STEPS * 100) + '%'; $('wtSub').textContent = n + ' / ' + WT_TOTAL_STEPS + ' complete';
  $('wtDots').innerHTML = WT_STEPS.map(function (x, i) { return '<button class="' + (i === wtIdx ? 'cur ' : '') + (S.wtDone[x.id] ? 'done' : '') + '" title="' + esc(x.t) + '" data-on-click="wtSet(' + i + ')" aria-label="Step ' + (i + 1) + '"></button>'; }).join('');
  $('wtList').innerHTML = WT_STEPS.map(function (x, i) { return '<label class="' + (i === wtIdx ? 'cur' : '') + '"><input type="checkbox" ' + (S.wtDone[x.id] ? 'checked' : '') + ' data-on-change="toggleDone(\'' + x.id + '\')"> ' + (i + 1) + '. ' + esc(x.t) + '</label>'; }).join('');
}
function wtSet(i) { wtIdx = (i + WT_TOTAL_STEPS) % WT_TOTAL_STEPS; if (wtTimer) wtStop(); renderWalkthrough(); playBeep(600 + wtIdx * 40, 'sine', .04, .025); }
function wtGo(d) { wtSet(wtIdx + d); }
function wtStop() { clearInterval(wtTimer); wtTimer = null; var b = $('wtPlayBtn'); if (b) b.innerHTML = '▶'; }
function wtPlay() {
  if (wtTimer) { wtStop(); return; } $('wtPlayBtn').innerHTML = '⏸';
  wtTimer = setInterval(function () { wtIdx = (wtIdx + 1) % WT_TOTAL_STEPS; renderWalkthrough(); playBeep(600 + wtIdx * 40, 'sine', .04, .02); }, 5200);
}
function hideHud() { $('heroHud').setAttribute('data-hidden', '1'); playBeep(420, 'sine', .05, .03); }
var sbTimer = null, sbPinned = false;
function showSubbar() { clearTimeout(sbTimer); $('subbar').classList.add('show'); }
function hideSubbarSoon() {
  clearTimeout(sbTimer);
  sbTimer = setTimeout(function () { var sb = $('subbar'); if (sbPinned || $('chipDrawer').classList.contains('open') || sb.matches(':focus-within')) return; sb.classList.remove('show'); }, 700);
}
function toggleSubbarPin() { sbPinned = !sbPinned; $('btnNav').style.color = sbPinned ? 'var(--accent)' : ''; if (sbPinned) showSubbar(); else hideSubbarSoon(); playBeep(sbPinned ? 760 : 520, 'sine', .04, .025); }
function wireSubbar() {
  var tb = $('topbar'), sb = $('subbar');
  tb.addEventListener('mouseenter', showSubbar); tb.addEventListener('mouseleave', hideSubbarSoon);
  sb.addEventListener('mouseenter', showSubbar); sb.addEventListener('mouseleave', hideSubbarSoon);
  sb.addEventListener('focusin', showSubbar); sb.addEventListener('focusout', hideSubbarSoon);
  document.addEventListener('mousemove', function (e) {
    if (e.clientY <= 4) showSubbar();
    else if (sb.classList.contains('show') && e.clientY > sb.getBoundingClientRect().bottom + 6) hideSubbarSoon();
  }, { passive: true });
}
function hideWalkthrough() { wtStop(); $('panel-walkthrough').setAttribute('data-hidden', '1'); playBeep(420, 'sine', .05, .03); }
function startTour() { var el = $('panel-walkthrough'); if (el.getAttribute('data-collapsed') === '1') toggleCollapse('walkthrough'); wtIdx = 0; renderWalkthrough(); jumpTo('panel-walkthrough'); if (!wtTimer) wtPlay(); audit('Walkthrough', 'Guided tour started'); }

/* ---------- welcome splash (6 stages, 18/38/56/74/90/100) ---------- */
var bootTimer = null;
function playSplash(force) {
  var w = $('welcome'); if (!w) return; w.classList.remove('hide'); var fill = $('bootfill'), step = $('bootstep'); if (fill) fill.style.width = '0%';
  var stages = [
    { pct: 18, text: 'Probing CSPRNG & WebCrypto — getRandomValues ' + (R.ok ? 'OK' : 'MISSING') + ', subtle ' + (HAS_SUBTLE ? 'available' : 'unavailable (using built-in SHA-256)') + '…' },
    { pct: 38, text: 'Verifying the audit ledger hash chain — ' + (vault.verified === true ? 'intact' : vault.verified === false ? 'BROKEN, see Ledger' : S.audit.length + ' blocks') + '…' },
    { pct: 56, text: 'Decoding embedded lists — ' + DICT.words.length.toLocaleString('en-US') + ' words · ' + DICT.common.length.toLocaleString('en-US') + ' common passwords…' },
    { pct: 74, text: 'Seeding the entropy pool — ' + R.stats.timing + ' timing samples folded…' },
    { pct: 90, text: 'Composing ' + PANELS.length + ' panels…' },
    { pct: 100, text: 'Vault ready · nothing stored · Ready!' }
  ];
  var i = 0; if (bootTimer) clearInterval(bootTimer);
  bootTimer = setInterval(function () { if (i >= stages.length) { clearInterval(bootTimer); bootTimer = null; return; } if (fill) fill.style.width = stages[i].pct + '%'; if (step) step.textContent = stages[i].text; playBeep(600 + i * 90, 'sine', .04, .02); i++; }, 260);
  audit('Welcome', force ? 'Replayed the welcome splash' : 'Initial boot splash');
}
function dismissWelcome() { var w = $('welcome'); if (w) w.classList.add('hide'); if (bootTimer) { clearInterval(bootTimer); bootTimer = null; } S.welcomeSeen = true; save(); audit('Welcome', 'Entered'); }
function showWelcome() { playSplash(true); }
function checkWelcomeOnLoad() { if (S.welcomeSeen) { var w = $('welcome'); if (w) { w.style.transition = 'none'; w.classList.add('hide'); setTimeout(function () { w.style.transition = ''; }, 60); } } else playSplash(false); }

/* ---------- theme / sound ---------- */
function toggleTheme() { S.theme = S.theme === 'light' ? 'dark' : 'light'; save(); applyFx(); playBeep(S.theme === 'light' ? 760 : 520, 'sine', .05, .03); audit('Theme', S.theme); renderActivity(); }
function toggleSound() { ui.soundEnabled = ui.soundEnabled === false; saveUI(); if (ui.soundEnabled) playBeep(880, 'sine', .06, .04); toast('ok', 'SOUND', ui.soundEnabled ? 'On' : 'Off'); }
function toggleFx() { ui.fxAnim = ui.fxAnim === false; saveUI(); }
function toggleCrt() { ui.crt = !ui.crt; saveUI(); }

/* ---------- command palette ---------- */
var CMDS = [], palList = [], palSel = 0;
function buildCmds() {
  CMDS = PANELS.map(function (p) { return { ic: '▦', t: 'Jump to panel: ' + stripTags(p.name), k: 'PANEL', run: function () { openPanel(p.id); } }; }).concat([
    { ic: '🔐', t: 'Jump to Home banner', k: 'COMPONENT', run: function () { jumpTo('homeBanner'); } },
    { ic: '📡', t: 'Jump to Telemetry HUD', k: 'COMPONENT', run: function () { jumpTo('heroHud'); } },
    { ic: '🧭', t: 'Jump to Guided Walkthrough', k: 'COMPONENT', run: function () { jumpTo('panel-walkthrough'); } },
    { ic: '▥', t: 'Default view (your opening page)', k: 'LAYOUT', run: defaultView },
    { ic: '🏠', t: 'Opening page: Fortify a password', k: 'START', run: function () { setStartPage('fortify'); } },
    { ic: '🏠', t: 'Opening page: Key generator', k: 'START', run: function () { setStartPage('generator'); } },
    { ic: '🏠', t: 'Opening page: Entropy sources', k: 'START', run: function () { setStartPage('sources'); } },
    { ic: '🏠', t: 'Opening page: Guided tour', k: 'START', run: function () { setStartPage('tour'); } },
    { ic: '🏠', t: 'Opening page: Home banner only', k: 'START', run: function () { setStartPage('home'); } },
    { ic: '▤', t: 'Show all panels', k: 'LAYOUT', run: showAll },
    { ic: '▦', t: 'Open chip drawer', k: 'LAYOUT', run: toggleChipDrawer },
    { ic: '▦', t: 'View: Grid', k: '1', run: function () { setView('grid'); } },
    { ic: '▤', t: 'View: Report (print-ready column)', k: '2', run: function () { setView('report'); } },
    { ic: '🔐', t: 'View: Ledger', k: '3', run: function () { setView('ledger'); } },
    { ic: '🔒', t: 'Fortify the typed password', k: 'ACTION', run: function () { openPanel('fortify'); setTimeout(runFortify, 450); } },
    { ic: '⚙', t: 'Fortify mode: Echo (keep words, harden)', k: 'MODE', run: function () { setFzMode('echo'); toast('ok', 'MODE', 'Echo'); } },
    { ic: '⚙', t: 'Fortify mode: Shape (keep layout only)', k: 'MODE', run: function () { setFzMode('shape'); toast('ok', 'MODE', 'Shape'); } },
    { ic: '⚙', t: 'Fortify mode: Fresh (nothing carried over)', k: 'MODE', run: function () { setFzMode('fresh'); toast('ok', 'MODE', 'Fresh'); } },
    { ic: '⚡', t: 'Deploy entropy batch (10)', k: 'ACTION', run: runBatch },
    { ic: '🧬', t: 'Text mixing: Isolated (my text not in the key)', k: 'MIX', run: function () { openPanel('generator'); setTimeout(function () { setGnComb('isolated'); }, 380); } },
    { ic: '🧬', t: 'Text mixing: Append (my text, then random)', k: 'MIX', run: function () { openPanel('generator'); setTimeout(function () { setGnComb('append'); }, 380); } },
    { ic: '🧬', t: 'Text mixing: Prepend (random, then my text)', k: 'MIX', run: function () { openPanel('generator'); setTimeout(function () { setGnComb('prepend'); }, 380); } },
    { ic: '🧬', t: 'Text mixing: Fisher-Yates Mix (shuffled together)', k: 'MIX', run: function () { openPanel('generator'); setTimeout(function () { setGnComb('mix'); }, 380); } },
    { ic: '🧬', t: 'Text mixing: Embed (my text hidden inside random)', k: 'MIX', run: function () { openPanel('generator'); setTimeout(function () { setGnComb('embed'); }, 380); } },
    { ic: '🧬', t: 'Text mixing: Omni-Mix (text + random + passphrase)', k: 'MIX', run: function () { openPanel('generator'); setTimeout(function () { setGnComb('omni'); }, 380); } },
    { ic: '🧬', t: 'Text mixing: Omni-Mix Shuffle', k: 'MIX', run: function () { openPanel('generator'); setTimeout(function () { setGnComb('omnishuffle'); }, 380); } },
    { ic: '🧂', t: 'Toggle: fold my text into the entropy pool (0 trusted bits)', k: 'MIX', run: function () { openPanel('generator'); setTimeout(function () { $('gnFold').checked = !$('gnFold').checked; onGnCfg(); saveUI(); toast('ok', 'FOLD TEXT INTO POOL', prefs.gnFold ? 'On. Applies when you press DEPLOY with text in the base field.' : 'Off'); }, 380); } },
    { ic: '🗑', t: 'Purge memory', k: 'ACTION', run: function () { purgeMemory(); } },
    { ic: '📋', t: 'Copy fortified password', k: 'ACTION', run: function () { if (vault.result) copyResult(); else toast('warn', 'NOTHING TO COPY', 'Fortify a password first.'); } },
    { ic: '📱', t: 'Show fortified password as QR', k: 'ACTION', run: function () { if (vault.result) showQr(vault.result.text, 'Fortified password'); else toast('warn', 'NOTHING TO SHOW', 'Fortify a password first.'); } },
    { ic: '🔬', t: 'Run randomness sanity check', k: 'ENTROPY', run: function () { openPanel('sources'); setTimeout(runSelfTest, 300); } },
    { ic: '🔑', t: 'Fold WebCrypto digest into pool', k: 'ENTROPY', run: foldSubtle },
    { ic: '📋', t: 'Policy preset: Basic (64 bits)', k: 'POLICY', run: function () { applyPolicy('basic'); } },
    { ic: '📋', t: 'Policy preset: Standard (80 bits)', k: 'POLICY', run: function () { applyPolicy('standard'); } },
    { ic: '📋', t: 'Policy preset: High (96 bits)', k: 'POLICY', run: function () { applyPolicy('high'); } },
    { ic: '📋', t: 'Policy preset: Vault (128 bits)', k: 'POLICY', run: function () { applyPolicy('vault'); } },
    { ic: '✓', t: 'Verify the audit ledger hash chain', k: 'V', run: function () { openPanel('ledger'); setTimeout(verifyLedger, 200); } },
    { ic: '✎', t: 'Add a note to the audit ledger', k: 'N', run: addNote },
    { ic: '⬇', t: 'Export full state JSON', k: 'E', run: exportJSON },
    { ic: '⬇', t: 'Export ledger JSON', k: 'EXPORT', run: function () { exportLedger('json'); } },
    { ic: '⬇', t: 'Export ledger CSV', k: 'EXPORT', run: function () { exportLedger('csv'); } },
    { ic: '🖨', t: 'Print / Save as PDF', k: 'EXPORT', run: function () { window.print(); } },
    { ic: '⚙', t: 'Open Settings & Control Center', k: 'P', run: openSettings },
    { ic: '🌓', t: 'Toggle light / dark theme', k: 'T', run: toggleTheme },
    { ic: '🔊', t: 'Toggle sound', k: 'AUDIO', run: toggleSound },
    { ic: '✨', t: 'Toggle FX animation', k: 'FX', run: toggleFx },
    { ic: '📺', t: 'Toggle CRT scanlines', k: 'FX', run: toggleCrt },
    { ic: '✦', t: 'Replay welcome splash', k: 'W', run: showWelcome },
    { ic: '🧭', t: 'Start guided tour', k: 'G', run: startTour },
    { ic: '▶', t: 'Play / pause the walkthrough', k: '⌥P', run: wtPlay },
    { ic: '⌨', t: 'Keyboard shortcuts', k: '?', run: openShortcuts },
    { ic: '✉', t: 'Contact Admin', k: 'SUPPORT', run: openContactAdmin },
    { ic: '↻', t: 'Refresh / re-render all panels', k: 'R', run: function () { render(); toast('ok', 'REFRESHED', 'All panels re-rendered.'); } },
    { ic: '☰', t: 'Collapse all panels', k: 'LAYOUT', run: function () { PANELS.forEach(function (p) { S.collapsed[p.id] = true; }); save(); render(); } },
    { ic: '☰', t: 'Expand all panels', k: 'LAYOUT', run: function () { PANELS.forEach(function (p) { S.collapsed[p.id] = false; }); save(); render(); } }
  ]);
}
function openPal() { $('palOvl').classList.add('open'); var i = $('palIn'); i.value = ''; palSel = 0; palList = CMDS; drawPal(); i.focus(); playBeep(900, 'sine', .05, .03); }
function closePal() { $('palOvl').classList.remove('open'); }
function drawPal() {
  $('palList').innerHTML = palList.map(function (c, i) { return '<div class="pcmd ' + (i === palSel ? 'on' : '') + '" data-on-click="runPal(' + i + ')"><span class="ic">' + (c.ic || '▸') + '</span><span class="lb">' + esc(c.t) + '</span><span class="kb">' + c.k + '</span></div>'; }).join('') || '<div class="pcmd"><span class="ic">∅</span><span class="lb">No match</span></div>';
  var sel = document.querySelector('.pcmd.on'); if (sel && sel.scrollIntoView) sel.scrollIntoView({ block: 'nearest' });
}
function runPal(i) { var c = palList[i]; if (!c) return; closePal(); c.run(); }
function addNote() { var t = prompt('Add a note to the audit ledger (metadata only — never type a password here):'); if (t) { audit('Note', t.slice(0, 200)); toast('ok', 'NOTE', 'Added to the ledger.'); } }

/* ---------- overlays / shortcuts ---------- */
var SHORTCUTS = [['⌘K / Ctrl+K', 'Command palette'], ['F', 'Open Fortify'], ['1 / 2 / 3', 'View: Grid · Report · Ledger'], ['W', 'Welcome splash & boot bar'], ['G', 'Guided tour'], ['⌥P', 'Play / pause the walkthrough'], ['← / →', 'Walkthrough steps'], ['E', 'Export full state JSON'], ['V', 'Verify the audit ledger'], ['N', 'Add a note to the ledger'], ['R', 'Refresh all panels'], ['P', 'Settings & Control Center'], ['T', 'Toggle theme'], ['Shift+X', 'Purge memory now'], ['?', 'This list'], ['Esc', 'Close overlay / drawer']];
function openShortcuts() { $('scList').innerHTML = SHORTCUTS.map(function (s) { return '<kbd>' + s[0] + '</kbd><span>' + s[1] + '</span>'; }).join(''); $('shortcutsModal').classList.add('open'); }
function closeOvl(id) { $(id).classList.remove('open'); }
function anyOverlayOpen() { return document.querySelector('.modal-overlay.open'); }

/* ---------- settings (FX edits preview live; CANCEL reverts) ---------- */
var FX_DIALS = [
  { k: 'fx', l: 'Aurora intensity', min: 0, max: 100 }, { k: 'tilt', l: '3D tilt (deg)', min: 0, max: 10 }, { k: 'fxAnim', l: 'FX animation', bool: 1 }, { k: 'glow', l: 'Toolbar glow', min: 0, max: 100 },
  { k: 'iconSize', l: 'Icon scale %', min: 70, max: 130 }, { k: 'crt', l: 'CRT scanlines', bool: 1 }, { k: 'blur', l: 'Glass blur (px)', min: 0, max: 30 }, { k: 'fill', l: 'Panel fill %', min: 20, max: 95 }, { k: 'depth', l: 'Depth (shadow) %', min: 0, max: 90 },
  { k: 'soundEnabled', l: 'Sound effects', bool: 1 }, { k: 'soundVolume', l: 'Sound volume', min: 0, max: 100 }
];
var stSnap = null;
function buildDials() {
  $('fxDials').innerHTML = FX_DIALS.map(function (d) {
    return d.bool ? '<label class="switch"><input type="checkbox" data-fx="' + d.k + '" ' + (ui[d.k] !== false && ui[d.k] ? 'checked' : '') + '> ' + d.l + '</label>'
      : '<div class="dial"><span>' + d.l + '</span><input type="range" data-fx="' + d.k + '" min="' + d.min + '" max="' + d.max + '" value="' + ui[d.k] + '"><output>' + ui[d.k] + '</output></div>';
  }).join('');
  document.querySelectorAll('#fxDials [data-fx]').forEach(function (el) {
    el.addEventListener('input', function () { var k = el.getAttribute('data-fx'); ui[k] = el.type === 'checkbox' ? el.checked : +el.value; if (el.nextElementSibling && el.nextElementSibling.tagName === 'OUTPUT') el.nextElementSibling.textContent = el.value; applyFx(); });
  });
}
function openSettings() {
  stSnap = { ui: Object.assign({}, ui), prefs: Object.assign({}, prefs) };
  $('stStart').innerHTML = START_PAGES.map(function (x) { return '<option value="' + x[0] + '">' + x[2] + ' ' + x[1] + '</option>'; }).join(''); $('stStart').value = startPageId(); $('stStartWt').checked = !!prefs.startWt;
  $('stMode').value = prefs.mode; $('stFloor').value = String(prefs.floor); $('stClip').value = String(prefs.clip); $('stIdle').value = String(prefs.idle); $('stHide').checked = !!prefs.wipeHide;
  buildDials(); renderAbout(); $('settingsModal').classList.add('open'); playBeep(760, 'sine', .05, .03);
}
function saveSettings() {
  prefs.startPage = $('stStart').value; prefs.startWt = $('stStartWt').checked; prefs.mode = $('stMode').value; prefs.floor = +$('stFloor').value; prefs.clip = +$('stClip').value; prefs.idle = +$('stIdle').value; prefs.wipeHide = $('stHide').checked;
  saveUI(); syncFortifyUI(); audit('Settings', 'Saved (opening page=' + startPageId() + ', walkthrough on load=' + (prefs.startWt ? 'yes' : 'no') + ', mode=' + prefs.mode + ', floor=' + prefs.floor + ', idle=' + prefs.idle + 's, clip=' + prefs.clip + 's)'); closeOvl('settingsModal'); toast('ok', 'SAVED', 'Settings stored in this browser.'); renderStatus(); playBeep(880, 'sine', .06, .04);
}
function cancelSettings() { if (stSnap) { ui = stSnap.ui; prefs = stSnap.prefs; applyFx(); syncFortifyUI(); } closeOvl('settingsModal'); }
function resetFx() { ui = Object.assign({}, UI_DEFAULTS); applyFx(); buildDials(); playBeep(440, 'sine', .15, .08); }
$('stTabs') && $('stTabs').addEventListener('click', function (e) { var t = e.target.getAttribute && e.target.getAttribute('data-t'); if (!t) return; document.querySelectorAll('#stTabs button').forEach(function (b) { b.classList.toggle('on', b === e.target); }); document.querySelectorAll('.tabpane').forEach(function (p) { p.classList.toggle('on', p.id === 'tab_' + t); }); });

/* ---------- backup / restore (never includes secrets) ---------- */
function exportJSON() {
  var st = Object.assign({}, S); delete st.audit;
  dl('SystemVault_state.json', JSON.stringify({ app: APP_NAME, version: APP_VERSION, exported: new Date().toISOString(), ledger: { algo: LEDGER_ALGO, genesis: GENESIS, blocks: S.audit.slice().reverse() }, ui: ui, prefs: prefs, state: st }, null, 2), 'application/json');
  toast('ok', 'EXPORT', 'State JSON downloaded (no passwords or keys inside).');
}
function importJSON(file) {
  if (!file) return; var fr = new FileReader();
  fr.onload = function () {
    try {
      var o = JSON.parse(fr.result); if (o.app !== APP_NAME) throw new Error('Not a System Vault export.'); if (String(o.version).split('.')[0] !== APP_VERSION.split('.')[0]) throw new Error('Unsupported version ' + o.version + '.');
      if (o.ui) ui = Object.assign({}, UI_DEFAULTS, o.ui); if (o.prefs) prefs = Object.assign({}, PREF_DEFAULTS, o.prefs);
      if (o.state) ['hidden', 'tray', 'collapsed', 'order', 'wtDone', 'rotDone', 'theme', 'view'].forEach(function (k) { if (o.state[k] !== undefined) S[k] = o.state[k]; });
      if (o.ledger && Array.isArray(o.ledger.blocks)) ledgerQueue(function () { S.audit = o.ledger.blocks.slice().reverse(); });
      ledgerSettled().then(function () { saveUI(); applyOrder(); render(); syncFortifyUI(); syncGenUI(); audit('Import', 'State restored from JSON'); toast('ok', 'IMPORTED', 'State restored. Run VERIFY CHAIN to check the ledger.'); });
    } catch (e) { toast('err', 'IMPORT FAILED', e.message); }
  }; fr.readAsText(file);
}
function resetAll() { if (!confirm('Reset ALL System Vault data in this browser?')) return; try { localStorage.removeItem(STORE_KEY); } catch (e) {} location.reload(); }

/* ---------- Contact Admin (blueprint PART 10) ---------- */
var caTimer = null;
function openContactAdmin() { var m = $('contactAdminModal'); if (!m) return; m.classList.add('open'); playBeep(760, 'sine', .05, .03); setTimeout(function () { var s = $('caSubject'); if (s) s.focus(); }, 60); audit('Contact Admin', 'Opened the contact form'); }
function closeContactAdmin() { var m = $('contactAdminModal'); if (!m) return; m.classList.remove('open'); if (caTimer) { clearTimeout(caTimer); caTimer = null; } var b = $('caSubmit'); if (b) { b.disabled = false; b.textContent = 'SEND'; } }
function heldSecrets() { var s = []; if ($('fzIn') && $('fzIn').value.length >= 6) s.push($('fzIn').value); if ($('gnBase') && $('gnBase').value.length >= 6) s.push($('gnBase').value); if (vault.result) s.push(vault.result.text); vault.batch.forEach(function (b) { s.push(b.text); }); return s; }
function sendContactAdmin(ev) {
  ev.preventDefault(); var form = $('caForm'), btn = $('caSubmit'); if (!form || !btn) return false;
  var body = ($('caName').value + ' ' + $('caSubject').value + ' ' + $('caMessage').value);
  if (heldSecrets().some(function (s) { return body.indexOf(s) >= 0; })) { toast('err', 'BLOCKED', 'The message contains a password or key currently held in this tab. Remove it before sending.'); return false; }
  btn.disabled = true; btn.textContent = 'Sending…';
  var fd = new FormData(form); fd.append('email', CONTACT_EMAIL);
  fetch(CONTACT_ENDPOINT, { method: 'POST', body: fd }).then(function () {
    btn.textContent = 'Message Sent ✓'; form.reset(); audit('Contact Admin', 'Message sent to the administrator'); caTimer = setTimeout(closeContactAdmin, 2000);
  })['catch'](function () { btn.textContent = 'Error Sending'; audit('Contact Admin', 'Send failed'); caTimer = setTimeout(function () { btn.disabled = false; btn.textContent = 'SEND'; }, 3000); });
  return false;
}

/* ---------- version: every on-page version string is filled from APP_VERSION / CHANGELOG (00_version.js), never typed in markup ---------- */
function fillVersions() {
  var v = 'v' + APP_VERSION, full = 'System Vault ' + v + ' \u00B7 ' + CHANGELOG[0].d;
  document.querySelectorAll('[data-ver]').forEach(function (e) { e.textContent = v; e.title = full; });
  document.querySelectorAll('[data-ver-full]').forEach(function (e) { e.textContent = full; });
}
/* audit trail: one block per session open, and one per version change (the previous version is remembered in S.lastVer) */
function versionAudit() {
  if (!S.lastVer) audit('Version', 'First run on v' + APP_VERSION);
  else if (S.lastVer !== APP_VERSION) audit('Version', 'Updated v' + S.lastVer + ' to v' + APP_VERSION + ': ' + (CHANGELOG[0].n[0] || '').slice(0, 120));
  audit('Session', 'System Vault v' + APP_VERSION + ' opened');
  S.lastVer = APP_VERSION; save();
}

/* ---------- boot ---------- */
function bootChecks() {
  /* real startup work: cross-check built-in SHA-256 against WebCrypto, fold its digest, start ledger verification */
  if (HAS_SUBTLE) { var probe = new TextEncoder().encode('systemvault-selfcheck'); crypto.subtle.digest('SHA-256', probe).then(function (d) { var ok = toHex(new Uint8Array(d)) === sha256hex(probe); if (!ok) toast('err', 'SHA-256 MISMATCH', 'Built-in SHA-256 disagrees with WebCrypto.'); R.addBytes('subtle', new Uint8Array(d)); renderPanel('sources'); }); }
  ledgerSettled().then(verifyChain).then(function (r) { vault.verified = r.ok; if (!r.ok) toast('err', 'LEDGER BROKEN', 'Block #' + r.brokenAt + ' failed verification.'); });
}
function wireGlobal() {
  wireSubbar();
  var lastPtr = 0;
  document.addEventListener('pointermove', function (e) { var n = performance.now(); if (n - lastPtr < 25) return; lastPtr = n; R.jitter('pointer', [(e.clientX * 31 + e.clientY) & 0xffff, Math.floor(e.timeStamp * 1000) & 0xffff]); }, { passive: true });
  var lastKey = 0; document.addEventListener('keydown', function (e) { var n = e.timeStamp; R.jitter('key', [Math.floor((n - lastKey) * 1000) & 0xffff]); lastKey = n; touch(); });
  document.addEventListener('visibilitychange', function () {
    if (document.hidden && prefs.wipeHide && holdingSecrets()) { purgeMemory('tab hidden'); vault.wipedOnHide = true; }
    else if (!document.hidden && vault.wipedOnHide) { vault.wipedOnHide = false; toast('warn', 'MEMORY WIPED', 'The tab was hidden, so typed passwords and results were wiped. Anything you copied stays on the clipboard until the timer clears it.'); }
  });
  window.addEventListener('beforeprint', maskAllSecrets); window.addEventListener('afterprint', unmaskSecrets);
  window.addEventListener('resize', function () { measureTopbar(); initConfetti(); renderActivity(); });
  var pad = $('entPad'); if (pad) pad.addEventListener('pointermove', function (e) { pad.textContent = 'entropy samples: ' + R.stats.pointer; });
  $('fzIn').addEventListener('input', onFzInput); $('fzIn').addEventListener('keydown', function (e) { if (e.key === 'Enter') runFortify(); });
  ['palOvl', 'shortcutsModal', 'contactAdminModal'].forEach(function (id) { $(id).addEventListener('click', function (e) { if (e.target === this) { if (id === 'contactAdminModal') closeContactAdmin(); else closeOvl(id); } }); });
  $('settingsModal').addEventListener('click', function (e) { if (e.target === this) cancelSettings(); });
  $('palIn').addEventListener('input', function () { var q = this.value.toLowerCase(); palList = CMDS.filter(function (c) { return (c.t + ' ' + c.k).toLowerCase().indexOf(q) >= 0; }); palSel = 0; drawPal(); });
  $('palIn').addEventListener('keydown', function (e) { if (e.key === 'ArrowDown') { palSel = Math.min(palList.length - 1, palSel + 1); drawPal(); e.preventDefault(); } else if (e.key === 'ArrowUp') { palSel = Math.max(0, palSel - 1); drawPal(); e.preventDefault(); } else if (e.key === 'Enter') { runPal(palSel); e.preventDefault(); } });
  var dz = $('dropzone'); if (dz) { dz.addEventListener('dragover', function (e) { e.preventDefault(); dz.classList.add('over'); }); dz.addEventListener('dragleave', function () { dz.classList.remove('over'); }); dz.addEventListener('drop', function (e) { e.preventDefault(); dz.classList.remove('over'); importJSON(e.dataTransfer.files[0]); }); }
  $('mascot').addEventListener('click', function (e) { fireConfetti(e.clientX, e.clientY); });
  document.addEventListener('keydown', function (e) {
    var typing = /^(INPUT|TEXTAREA|SELECT)$/.test((e.target.tagName || '')), mod = e.ctrlKey || e.metaKey;
    if (mod && e.key.toLowerCase() === 'k') { e.preventDefault(); if ($('palOvl').classList.contains('open')) closePal(); else openPal(); return; }
    if (e.key === 'Escape') { if (!$('welcome').classList.contains('hide')) { dismissWelcome(); return; } if ($('palOvl').classList.contains('open')) closePal(); else if ($('settingsModal').classList.contains('open')) cancelSettings(); else if ($('contactAdminModal').classList.contains('open')) closeContactAdmin(); else if ($('shortcutsModal').classList.contains('open')) closeOvl('shortcutsModal'); else if ($('chipDrawer').classList.contains('open')) toggleChipDrawer(); return; }
    if (e.key === 'Enter' && !$('welcome').classList.contains('hide') && !typing) { dismissWelcome(); return; }
    if (typing || mod || anyOverlayOpen()) return;
    if (e.altKey && e.key.toLowerCase() === 'p') { wtPlay(); e.preventDefault(); return; }
    if (e.altKey) return;
    var k = e.key, K = k.length === 1 ? k.toLowerCase() : k;
    if (k === '1') setView('grid'); else if (k === '2') setView('report'); else if (k === '3') setView('ledger');
    else if (K === 'w') showWelcome(); else if (K === 'g') startTour(); else if (K === 'f') { e.preventDefault(); openPanel('fortify'); }
    else if (K === 'e') exportJSON(); else if (K === 'v') { openPanel('ledger'); verifyLedger(); } else if (K === 'n') addNote();
    else if (K === 'r') { render(); toast('ok', 'REFRESHED', 'All panels re-rendered.'); } else if (K === 'p') openSettings(); else if (K === 't') toggleTheme();
    else if (k === 'X') purgeMemory(); else if (k === '?') openShortcuts();
    else if (k === 'ArrowRight') wtGo(1); else if (k === 'ArrowLeft') wtGo(-1);
  });
}
function boot() {
  load(); loadUI(); buildPanelHeads(); applyOrder(); buildCmds(); CMDS.push({ ic: '\u270D', t: 'Fortify: draw a pattern instead of typing', k: 'PATTERN', run: function () { openPanel('fortify'); setTimeout(function () { setFzSrc('pattern'); }, 380); } }, { ic: '\u2328', t: 'Fortify: type the password', k: 'PATTERN', run: function () { openPanel('fortify'); setTimeout(function () { setFzSrc('type'); }, 380); } }); POLICIES.slice(4).forEach(function (p) { CMDS.push({ ic: '\uD83D\uDCCB', t: 'Policy preset: ' + p.name + ' (' + p.floor + ' bits)', k: 'POLICY', run: function () { applyPolicy(p.id); } }); }); wireGlobal();
  $('fzFloor').value = String(prefs.floor); syncFortifyUI(); syncGenUI(); renderAbout();
  mountPatternPads(); applyDefaultView(); render(); measureTopbar(); initConfetti(); wireTilt('.gpanel'); updateClocks(); setInterval(updateClocks, 1000);
  bootChecks(); checkWelcomeOnLoad(); migrateLedger(); fillVersions(); versionAudit(); onFzInput();
  if (!R.ok) toast('err', 'NO CSPRNG', 'crypto.getRandomValues is unavailable. Generation is disabled.');
}
document.addEventListener('DOMContentLoaded', boot);

