/* ==========================================================================
   ulyOS · js/tour.js — welcome screen + guided tour
   • Welcome splash after sign-in (first time, or every time if switched on).
   • Spotlight tour: highlights real parts of the desktop and explains them.
   • Reopen any time: Help → Guided tour / Welcome screen, logo menu, About.
   ========================================================================== */
(function () {
  'use strict';
  const { h, icon } = ulyOS.util;
  const { bus } = ulyOS;
  const T = (ulyOS.tour = {});
  const overlay = () => document.getElementById('overlay-root') || document.body;
  const SEEN = 'ulyos.tour.seen';
  const q = (sel) => { const el = document.querySelector(sel); return el && el.getBoundingClientRect().width ? el : null; };
  const API = () => ulyOS.desktopApi;
  const off = () => !!ulyOS.config.OFFLINE;

  /* target: selector (or function) of what to highlight; null → centred card */
  const dockItem = (id) => q('#taskbar .tb-item[data-app="' + id + '"]') || q('.desk-icon[data-id="' + id + '"]');
  const appsFolder = () => ulyOS.Desktop.icons.find((i) => i.id === 'apps' && i.kind === 'folder');
  const STEPS = () => [
    { title: 'Welcome to ulyOS', text: 'ulyOS is a private workspace that lives in your browser. Your files, passwords, notes and tools sit behind one password and are encrypted on this device — there is no account to create and no server that holds your data. This short tour shows where everything is.', icon: 'home' },
    { title: 'Why it is better', text: 'Cloud workspaces keep your documents on someone else’s servers and ask you to trust them. ulyOS reverses that: everything is encrypted at rest with a key only you hold (password, or fingerprint / passkey), nothing is uploaded unless you choose to sync, and the source code and audit log are open for inspection. You get the convenience of a desktop without handing over your data.', icon: 'shield' },
    { title: 'Who it is for', text: 'Professionals who handle sensitive documents, people who share or borrow computers (every profile is separately encrypted), travellers who need an offline copy, and anyone who wants one tidy place for files, generators, voice tools and quick links — on a laptop, tablet or phone, with nothing to install.', icon: 'key' },
    { target: () => q('.desk-icon'), title: 'A calm desktop', text: 'Four tools sit on the desktop — Gemini Live, Speak, Beam and the App Store — plus the Apps folder that holds everything else. Double-click (or tap once on a phone) to open. Right-click the desktop for shortcuts, widgets and wallpapers; drag icons onto the Apps folder to tidy them away.', icon: 'grid' },
    { target: () => q('#menubar'), title: 'Menu bar', text: 'The ulyOS logo opens system actions (settings, lock, switch profile). File, View, Window and Help work on the focused window. On the right: memory use, the sun / moon button (dark ↔ light theme), your profile (lock or switch) and the clock.', icon: 'list' },
    { target: () => q('#taskbar'), before: () => document.getElementById('taskbar')?.classList.add('reveal'), after: () => document.getElementById('taskbar')?.classList.remove('reveal'), title: 'Taskbar', text: 'Start menu, your pinned tools (Settings, Beam, Files, Task Manager) and every open window. Right-click any app to pin or unpin it. Prefer a floating dock or auto-hide? Settings → Dock & Menu bar.', icon: 'desktop' },
    { target: () => q('.desk-icon[data-id="apps"]'), title: 'The Apps folder', text: 'Files, Task Manager, Settings, QR Seal, System Vault, Crypto Compass and your shortcuts live here. Open it, search it, and right-click an app to move it back to the desktop or pin it to the taskbar. Apps you add from the App Store land here too.', icon: 'folder', action: { label: 'Open Apps folder', run: () => ulyOS.desktopApi.launch(appsFolder()) } },
    { target: () => dockItem('files'), title: 'Files', text: 'Your private sandbox: documents, pictures and downloads, stored encrypted in this browser. Create, rename, drag-and-drop and upload files, or mount a real folder from your computer with “Open folder…”. Right-click a file for Encrypt…, Download and more.', icon: 'folder' },
    { target: () => q('.wgt') || q('#desktop'), title: 'Widgets', text: 'Clock, calendar, notes, system monitor, crypto prices, scoreboards, headlines and prediction markets. Right-click the desktop → Add widget (weather, to-do, world clocks, moon and more). Drag to move, pull the corner to resize, press the pin to lock one in place, and right-click → Theme to recolor it. Widgets stay against the screen edge you put them on and re-pack when the window changes size.', icon: 'layers' },
    { target: () => q('.desk-icon[data-id="speak"]'), title: 'Speak', text: 'Type or paste text and ulyOS reads it aloud. Pick a voice engine — browser voices, natural Gemini voices (whisper, calm, storyteller…) or a built-in offline voice — and save the speech as a .wav or .mp3 file.', icon: 'volume' },
    { target: () => q('.desk-icon[data-id="live"]'), title: 'Gemini Live', text: 'Have a spoken conversation with Google’s Gemini: press Start talking, speak, and it answers out loud while showing the transcript. You bring your own free API key; it stays encrypted in your profile and is never synced or exported.', icon: 'mic', action: { label: 'Open Gemini Live', run: () => ulyOS.Gemini.openLive() } },
    { target: () => q('.desk-icon[data-id="beam"]'), title: 'Beam', text: 'Send files, pictures, text or your settings between your PC and phone. Start on one device, Join on the other by scanning a QR code, check the same number shows on both, then drag files across. Direct and end-to-end encrypted — no server.', icon: 'send', action: { label: 'Open Beam', run: () => ulyOS.Beam.open() } },
    { target: () => q('.desk-icon[data-id="store"]'), title: 'App Store', text: 'Browse around 45 apps — the built-in ones and well-known web apps (drawing, office, coding, learning, media). Add puts a shortcut in your Apps folder; nothing is installed. Sites that refuse to be embedded open in a browser tab.', icon: 'store', action: { label: 'Open App Store', run: () => ulyOS.Store.open() } },
    { target: () => dockItem('settings'), title: 'Make it yours', text: 'Settings → Appearance: wallpapers (including nature scenes), accent color, dark / light theme, font and text size, widget style. Effects: animations, glass, sounds. Pointer: style, size and color. “Surprise me” randomizes the whole look.', icon: 'palette', action: { label: 'Open Appearance', run: () => API().openSettings('appearance') } },
    { target: () => dockItem('settings'), title: 'Security you control', text: 'Every profile has a password and everything is encrypted at rest. Add a fingerprint / passkey for quick, un-guessable unlock, set auto-lock, and export an encrypted backup. There is no password recovery by design — keep a backup.', icon: 'shield', action: { label: 'Open Security', run: () => API().openSettings('security') } },
    { target: () => dockItem('settings'), title: 'Sync and backup', text: 'Settings → Sync keeps your look and data identical on all your devices through an encrypted file, a secret GitHub gist, or a folder your cloud drive already syncs (Google Drive, iCloud, OneDrive, Dropbox, Nextcloud, a network share). Only encrypted data ever leaves the device.', icon: 'refresh', action: { label: 'Open Sync', run: () => API().openSettings('sync') } },
    { title: off() ? 'Offline build' : 'Take it offline', text: off() ? 'You are running the offline build. Nothing is sent anywhere. When you are done use your profile menu → “Quit ulyOS (stop server)” so the local Python server shuts down.' : 'Help → Download offline version builds a .zip with the whole OS and a tiny local server. It never contacts anyone and quits cleanly when you press Quit.', icon: 'download' },
    { title: 'You are all set', text: 'Replay this tour or the welcome screen any time from Help, the ulyOS logo menu, or Settings → About. Your workspace, your data, your rules.', icon: 'check' },
  ];

  let active = null;
  function stop() {
    if (!active) return;
    try { active.step?.after?.(); } catch { /* ignore */ }
    active.nodes.forEach((n) => n.remove());
    document.removeEventListener('keydown', active.key, true);
    window.removeEventListener('resize', active.place);
    active = null;
  }

  T.start = function (from = 0) {
    stop(); closeWelcome();
    ulyOS.ui.closeMenu?.();
    const steps = STEPS();
    const hole = h('div', { class: 'tour-hole' });
    const card = h('div', { class: 'tour-card', role: 'dialog', 'aria-live': 'polite' });
    const shield = h('div', { class: 'tour-shield' });
    overlay().append(shield, hole, card);
    let i = Math.max(0, Math.min(from, steps.length - 1));
    const st = { nodes: [shield, hole, card], step: null };
    const place = () => {
      const s = steps[i]; const el = s.target ? s.target() : null;
      const pad = 8;
      if (el) {
        const r = el.getBoundingClientRect();
        Object.assign(hole.style, { display: 'block', left: r.left - pad + 'px', top: r.top - pad + 'px', width: r.width + pad * 2 + 'px', height: r.height + pad * 2 + 'px' });
        const cw = Math.min(360, window.innerWidth - 24), ch = card.offsetHeight || 220;
        let x = r.right + 18, y = r.top + r.height / 2 - ch / 2;
        if (x + cw > window.innerWidth - 12) x = r.left - cw - 18;                       // no room on the right → left
        if (x < 12) { x = clamp(r.left + r.width / 2 - cw / 2, 12, window.innerWidth - cw - 12); y = r.bottom + 18; if (y + ch > window.innerHeight - 12) y = r.top - ch - 18; }
        card.style.left = clamp(x, 12, window.innerWidth - cw - 12) + 'px'; card.style.top = clamp(y, 12, Math.max(12, window.innerHeight - ch - 12)) + 'px'; card.style.transform = 'none';
      } else {
        hole.style.display = 'none';
        card.style.left = '50%'; card.style.top = '50%'; card.style.transform = 'translate(-50%,-50%)';
      }
    };
    const clamp = (v, a, b) => Math.min(Math.max(v, a), b);
    const show = () => {
      try { st.step?.after?.(); } catch { /* ignore */ }
      const s = steps[i]; st.step = s;
      try { s.before?.(); } catch { /* ignore */ }
      const last = i === steps.length - 1;
      card.replaceChildren(...[
        h('div', { class: 'tour-head' }, h('span', { class: 'tour-ico', html: icon(s.icon || 'info', 18) }), h('b', { text: s.title }), h('span', { class: 'tour-n', text: i + 1 + ' / ' + steps.length })),
        h('p', { class: 'tour-text', text: s.text }),
        s.action ? h('button', { class: 'btn sm tour-try', text: s.action.label, onclick: () => { s.action.run(); } }) : null,
        h('div', { class: 'tour-dots' }, steps.map((_, k) => h('i', { class: k === i ? 'on' : '', onclick: () => { i = k; show(); } }))),
        h('div', { class: 'tour-nav' },
          h('button', { class: 'btn sm', text: 'Skip tour', onclick: finish }),
          h('span', { class: 'grow' }),
          i > 0 ? h('button', { class: 'btn sm', text: '← Back', onclick: () => { i--; show(); } }) : null,
          h('button', { class: 'btn sm primary', text: last ? 'Finish' : 'Next →', onclick: () => { if (last) finish(); else { i++; show(); } } }))].filter(Boolean));
      requestAnimationFrame(() => { place(); card.querySelector('.primary')?.focus(); });
    };
    const finish = () => { stop(); ulyOS.vault.set(SEEN, '1'); };
    st.key = (e) => {
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); finish(); }
      else if (e.key === 'ArrowRight' || e.key === 'Enter') { if (e.target.closest?.('.tour-card button:not(.primary)') && e.key === 'Enter') return; e.preventDefault(); if (i < steps.length - 1) { i++; show(); } else finish(); }
      else if (e.key === 'ArrowLeft' && i > 0) { e.preventDefault(); i--; show(); }
    };
    st.place = place;
    document.addEventListener('keydown', st.key, true);
    window.addEventListener('resize', place);
    active = st;
    show();
  };

  /* ---------------- welcome splash ---------------- */
  let welcomeEl = null;
  function closeWelcome() { if (!welcomeEl) return; document.removeEventListener('keydown', welcomeEl._key, true); welcomeEl.classList.add('out'); const el = welcomeEl; welcomeEl = null; setTimeout(() => el.remove(), 260); }
  T.welcome = function (force) {
    if (welcomeEl || active) return;
    ulyOS.ui.closeMenu?.();
    const always = h('input', { type: 'checkbox', checked: !!API().Settings.get?.('welcomeAlways'), onchange: () => API().Settings.set('welcomeAlways', always.checked) });
    const enter = () => { ulyOS.vault.set(SEEN, '1'); closeWelcome(); };
    const rich = (id) => (ulyOS.richIcons && ulyOS.richIcons.has(id) ? ulyOS.richIcons.svg(id) : '');
    const FLOAT = [['live', 7, 4, 0], ['speak', 62, 3, 0.6], ['beam', 36, 22, 1.2], ['store', 5, 33, 0.3], ['files', 67, 31, 0.9], ['systemvault', 36, 44, 1.5]];   // all in the upper part so the title stays clear
    const feat = (ico, c1, c2, t, d) => h('div', { class: 'wl-feat' }, h('div', { class: 'wl-fi', style: { background: 'linear-gradient(145deg,' + c1 + ',' + c2 + ')' }, html: icon(ico, 20) }), h('div', {}, h('b', { text: t }), h('p', { text: d })));
    const name = (ulyOS.security.profile() && ulyOS.security.profile().name) || 'there';
    const el = h('div', { class: 'welcome', role: 'dialog', 'aria-label': 'Welcome to ulyOS' },
      h('div', { class: 'wl-card' },
        h('div', { class: 'wl-hero' },
          h('div', { class: 'wl-orb o1' }), h('div', { class: 'wl-orb o2' }),
          h('div', { class: 'wl-float' }, FLOAT.map(([id, x, y, d]) => h('span', { class: 'wl-ico', style: { left: x + '%', top: y + '%', animationDelay: d + 's' }, html: rich(id) }))),
          h('div', { class: 'wl-brand' },
            h('div', { class: 'wl-logo', html: '<svg viewBox="0 0 80 80" width="46" height="46"><circle cx="40" cy="40" r="28" fill="none" stroke="currentColor" stroke-width="3.2"/><circle cx="40" cy="40" r="5.5" fill="currentColor"/></svg>' }),
            h('h1', { html: 'Welcome to uly<span>OS</span>' }),
            h('p', { class: 'wl-tag', text: 'Your private workspace — in the browser.' }),
            h('span', { class: 'wl-ver mono', text: 'v' + ulyOS.version + ' · ' + (off() ? 'offline build' : 'online build') }))),
        h('div', { class: 'wl-side' },
          h('p', { class: 'wl-hello', html: 'Hello, <b></b>. Everything you keep here is locked behind your password and stays on this device.' }),
          feat('shield', '#34d399', '#0ea5e9', 'Private by design', 'Encrypted at rest. No account, no server holding your data.'),
          feat('globe', '#6366f1', '#a855f7', 'Nothing to install', 'Any browser, any device — and it works offline.'),
          feat('layers', '#f59e0b', '#ef4444', 'One workspace', 'Files, generators, Speak, Gemini Live and Beam, together.'),
          h('div', { class: 'wl-stats' }, [['AES-256', 'encrypted'], ['0', 'accounts'], ['100%', 'on-device']].map(([a, b]) => h('div', {}, h('b', { text: a }), h('span', { text: b })))),
          h('div', { class: 'wl-actions' },
            h('button', { class: 'btn wl-go welcome-go', html: 'Enter ulyOS ' + icon('arrowRight', 16), onclick: enter }),
            h('button', { class: 'btn wl-tour', html: icon('compass', 15) + ' Take the tour', onclick: () => { ulyOS.vault.set(SEEN, '1'); T.start(); } }),
            h('button', { class: 'btn wl-ghost', text: 'Make it yours', onclick: () => { enter(); API().openSettings('appearance'); } })),
          h('label', { class: 'welcome-opt' }, always, 'Show this welcome screen on every sign-in'),
          h('div', { class: 'welcome-hint', text: 'Press Enter to start · Esc to close · Help → Guided tour to replay' }))));
    el.querySelector('.wl-hello b').textContent = name;
    el._key = (e) => { if (e.key === 'Escape' || (e.key === 'Enter' && !e.target.closest?.('button,label,input'))) { e.preventDefault(); enter(); } };
    document.addEventListener('keydown', el._key, true);
    overlay().append(el); welcomeEl = el;
    requestAnimationFrame(() => el.classList.add('in'));
    setTimeout(() => el.querySelector('.welcome-go')?.focus(), 80);
  };

  bus.on('session:start', () => {
    let tries = 0;
    const when = () => {   // wait for the boot animation to finish, then a beat
      if (document.body.classList.contains('booting') && tries++ < 60) { setTimeout(when, 300); return; }
      setTimeout(() => {
        if (document.body.classList.contains('locked') || !ulyOS.security.profileId()) return;
        const always = API() && API().Settings.get?.('welcomeAlways');
        if (always || ulyOS.vault.get(SEEN) !== '1') T.welcome();
      }, 900);
    };
    setTimeout(when, 600);
  });
  bus.on('session:lock', () => { stop(); closeWelcome(); });
})();
